package sefaz.gtribapi.controller;

import org.springdoc.core.annotations.ParameterObject;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import sefaz.gtribapi.controller.dto.FinalizarProcessoDto;
import sefaz.gtribapi.controller.dto.ProcessoDto;
import sefaz.gtribapi.controller.mapper.ProcessoMapper;
import sefaz.gtribapi.model.EConclusao;
import sefaz.gtribapi.model.EMotivoDiligencia;
import sefaz.gtribapi.model.ESituacao;
import sefaz.gtribapi.model.Movimentacao;
import sefaz.gtribapi.model.Processo;
import sefaz.gtribapi.model.Usuario;
import sefaz.gtribapi.service.ProcessoService;
import sefaz.gtribapi.service.UsuarioService;
import java.util.Optional;

@RestController
// STATELESS -> a cada nova requisição eu recebo todas as informações que eu preciso para fazer a funcionalidade que o cliente pediu;
//STATEFULL -> o estado de cada cliente é mantido no servidor;
@Controller
@ResponseBody
@RequestMapping("/processos")
@Tag(
    name = "Processos",
    description = "Endpoints para gerenciar processos"
)

public class ProcessoController implements IController<Processo> {
    private final ProcessoService servico;
    
    private final ProcessoMapper mapper;

    public ProcessoController(ProcessoService servico, ProcessoMapper mapper){
        this.servico = servico;
        this.mapper = mapper;
        
    }


    @GetMapping("/")
    public ResponseEntity<Page<ProcessoDto>> get(
        @RequestParam(required = false) String termoBusca,
        @RequestParam(required = false, defaultValue = "false") boolean unpaged,
        @ParameterObject Pageable pageable) {

        if (unpaged) {
            pageable = Pageable.unpaged();
        }

        Page<Processo> registros = servico.get(termoBusca, pageable);
        Page<ProcessoDto> dtos = registros.map(mapper::toDto);
        return ResponseEntity.ok(dtos);
    }

  
    @GetMapping("/{id}")
    public ResponseEntity<ProcessoDto> get(@PathVariable("id") Long id) {
        Processo registro = servico.get(id);
        if (registro == null){
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        }

        ProcessoDto dto = mapper.toDto(registro);
        return ResponseEntity.ok(dto);
    }

    @PutMapping("/editar/{id}")
    public ResponseEntity<Processo> update(@PathVariable Long id, @RequestBody Processo processoAtualizado) {
        Processo processo = servico.updateProcesso(id, processoAtualizado);
        return ResponseEntity.ok(processo);
    }
    

    @DeleteMapping("/{id}")
    public ResponseEntity<?> delete(@PathVariable("id") Long id) {
        servico.delete(id);
        return ResponseEntity.status(HttpStatus.OK).body(null);
    }

    @PutMapping("/status/{id}")
    public ResponseEntity<Processo> updateStatus(@PathVariable("id") Long id) {
        Processo registro = servico.updateStatus(id);
        return ResponseEntity.ok(registro);
    }

    //Fiz uma alteração aqui para deixar o código mais limpo.
    //A documentação que havia aqui, pode ser encontrada no arquivo openapi.yaml.
    //Caso queira alterar algo, altere por lá. Acho interessante continuarmos seguindo 
    //essa abordagem, o código fica mais limpo. By: Thalisson.
    @Operation(summary = "Cadastrar novo processo", description = "Cadastra um novo processo no sistema.")
    @PostMapping(value="/",consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Processo> insert(@Valid @RequestBody Processo processo) {
        Processo processoSalvo = servico.save(processo);
        return ResponseEntity.ok(processoSalvo);
    }


    @Override
    public ResponseEntity<?> update(Processo objeto) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'update'");
    }

    
    @PatchMapping("/designar/{idProcesso}/{idUsuario}") //Patch de cabra macho
    public ResponseEntity<ProcessoDto> designarProcesso(@PathVariable("idProcesso") Long idProcesso, @PathVariable("idUsuario") Long idUsuario, @RequestParam(value = "idAssessor", required = false) Long idAssessor){ // Achei mais conveniente retornar o registro da movimentação do que o processo em si
                // Lógica para designar o processo
            Movimentacao movimentacao;
            if (idAssessor != null) {
                // Se idAssessor for passado, inclua-o na movimentação
                movimentacao = servico.designarComAssessor(idProcesso, idUsuario,idAssessor);
            } else {
                // Caso contrário, execute a designação padrão
                movimentacao = servico.designar(idProcesso,idUsuario);
            }
        Processo processoAtualizado = servico.get(idProcesso);
        return ResponseEntity.ok(mapper.toDto(processoAtualizado));
    }

    @PatchMapping("/diligencia/{idProcesso}/")
    public ResponseEntity<ProcessoDto> diligirProcesso(@PathVariable("idProcesso") Long idProcesso,
                                                        @RequestParam(value= "idSetorDestino", required= false) Long idSetorDestino,
                                                        @RequestParam(name = "caminhamento", required = true) Boolean idaOuVinda, 
                                                        @RequestParam(name = "motivo",required = false)EMotivoDiligencia motivo){
        
        //True para quando o processo sai do setor;
        //False para quando o processo retorna para o setor.
        if (idaOuVinda == true && motivo != null && idSetorDestino != null){
            Processo registro = servico.diligirProcesso(idProcesso, motivo,idSetorDestino);
            return ResponseEntity.ok(mapper.toDto(registro));
        }else{
            if (idaOuVinda == false){
                Processo processo = servico.get(idProcesso);
                if (processo.getSituacao() != ESituacao.DILIGENCIA){
                    return ResponseEntity.badRequest().body(null);
                }
                Processo registro = servico.retornoDiligencia(processo);
                return ResponseEntity.ok(mapper.toDto(registro));
            }
        }
        return ResponseEntity.badRequest().body(null);
    }

    @PatchMapping("iniciar-processo/{id}")
    public ResponseEntity<ProcessoDto> iniciarProcesso(@PathVariable Long id){
        Processo registro = servico.get(id);
        servico.iniciarProcesso(registro);
        return ResponseEntity.ok(mapper.toDto(registro));
    }

    @PatchMapping("finalizar-processo/{id}")
    public ResponseEntity<ProcessoDto> finalizarProcesso(@PathVariable Long id, @RequestBody FinalizarProcessoDto dto){
        Processo registro = servico.get(id);
      
        registro.setNumeroParecer(dto.getParecerNumero());
        
        if (dto.getNivelDificuldade() != null) {
            registro.setDificuldade(dto.getNivelDificuldade());
        }
        if (dto.getPalavraChave() != null) {
            registro.setPalavrasChave(dto.getPalavraChave());
        }
        if (dto.getObservacao() != null) {
            registro.setObservacoes(dto.getObservacao());
        }

        servico.finalizarProcesso(registro);
        return ResponseEntity.ok(mapper.toDto(registro));
    }

    @PatchMapping("/concluir-processo/{id}")
    public ResponseEntity<ProcessoDto> concluirProcesso(
            @PathVariable Long id,
            @RequestParam EConclusao conclusao) {
        
        Processo registro = servico.get(id);
        registro.setConclusao(conclusao);
        registro =servico.concluirProcesso(registro);
        return ResponseEntity.ok(mapper.toDto(registro));
    }
}
