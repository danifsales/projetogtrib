package sefaz.gtribapi.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import sefaz.gtribapi.model.EMotivoDiligencia;
import sefaz.gtribapi.model.EMovimentacao;
import sefaz.gtribapi.model.ESituacao;
import sefaz.gtribapi.model.Interessado;
import sefaz.gtribapi.model.Movimentacao;
import sefaz.gtribapi.model.Processo;
import sefaz.gtribapi.model.Setor;
import sefaz.gtribapi.model.Usuario;
import sefaz.gtribapi.repository.InteressadoRepository;
import sefaz.gtribapi.repository.ProcessoRepository;
import sefaz.gtribapi.repository.SetorRepository;

@Service
public class ProcessoService {

    private final ProcessoRepository processoRepository;
    private final MovimentacaoService movimentacaoService;
    private final InteressadoRepository interessadoRepository;
    private final UsuarioService usuarioService;
    private final SetorRepository setorRepository;

    public ProcessoService(ProcessoRepository processoRepository,
                           MovimentacaoService movimentacaoService,
                           InteressadoRepository interessadoRepository,
                           UsuarioService usuarioService,
                           SetorRepository setorRepository){

    this.processoRepository = processoRepository;
    this.movimentacaoService = movimentacaoService;
    this.interessadoRepository = interessadoRepository;
    this.usuarioService = usuarioService;
    this.setorRepository = setorRepository;
                            }

    @Transactional
    public Processo save(Processo processo) {
        // Obter ou criar o interessado
        Interessado interessado = processo.getInteressado();
        
        Interessado interessadoExistente = interessadoRepository.findByCpfCnpj(interessado.getCpfCnpj())
            .orElseGet(() -> interessadoRepository.save(interessado));

        // Atualizar o processo com o interessado (existente ou novo)
        processo.setInteressado(interessadoExistente);
    
        // Salvar o processo
        Processo processoSalvo = processoRepository.save(processo);
    
        // Obter o usuário atual e criar movimentação
        Usuario usuarioAtual = obterUsuarioAtual();
        movimentacaoService.criarMovimentacaoAberturaProcesso(processoSalvo, usuarioAtual);

        return processoSalvo;
    }

    private Usuario obterUsuarioAtual() {
        return usuarioService.getUsuarioAutenticado();
    }

    // Método paginado para obter processos
    public Page<Processo> get(String termoBusca, Pageable pageable) {
        if (termoBusca == null || termoBusca.isBlank()) {
            return processoRepository.findAll(pageable);
        } else {
            return processoRepository.buscaPorVariosAtributos(termoBusca, pageable);
        }
    }

    // Método paginado com termo de busca
    // public Page<Processo> get(String termoBusca, Pageable pageable) {
    //     if (termoBusca == null || termoBusca.isBlank()) {
    //         return processoRepository.findAll(pageable);
    //     } else {
    //         return processoRepository.busca(termoBusca, pageable);
    //     }
    // }

    public void delete(Long id) {
        // Implementação do método de deleção
        processoRepository.deleteById(id);
    }

    public Processo get(Long id){
        return processoRepository.findById(id).orElse(null);
    }

    public Processo iniciarProcesso(Processo processo){
        Usuario usuario = obterUsuarioAtual();
        processo.setSituacao(ESituacao.EM_PROGRESSO);
        movimentacaoService.criarMovimentacaoInicioAnalise(processo, usuario);
        return processoRepository.save(processo);
    }
    
    public Processo updateStatus(Long id) {
        // Implementação para atualizar o status de um processo
        Processo processo = processoRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Processo não encontrado"));
        // Lógica para alterar o status do processo
        return processoRepository.save(processo);
    }
    @Transactional
    public Processo updateProcesso(Long id, Processo processoAtualizado) {
        // Busca o processo pelo ID
        Processo processoExistente = processoRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Processo não encontrado"));
    
        // Atualiza os campos do processo existente com os valores do processo atualizado
        processoExistente.setNumeroProcesso(processoAtualizado.getNumeroProcesso());
        processoExistente.setDataCapa(processoAtualizado.getDataCapa());
        processoExistente.setSituacao(processoAtualizado.getSituacao());
        processoExistente.setConclusao(processoAtualizado.getConclusao());
        processoExistente.setNumeroParecer(processoAtualizado.getNumeroParecer());  
        processoExistente.setResponsavel(processoAtualizado.getResponsavel());
        processoExistente.setAuditor(processoAtualizado.getAuditor());
        processoExistente.setSetorDestino(processoAtualizado.getSetorDestino());
    
        // Salva o processo atualizado no banco de dados
        return processoRepository.save(processoExistente);
    }

    public Movimentacao designar(Long idProcesso, Long idUsuario){
        Usuario pessoaDesignada = this.usuarioService.getById(idUsuario); //Fiquei tao loco com node que percebi agora que tava usando this.
        Processo processoDesignado = this.processoRepository.findById(idProcesso).orElse(null);
        processoDesignado.setResponsavel(pessoaDesignada);
        processoDesignado.setAuditor(pessoaDesignada); // Precisa ajeitar isso aqui, precisamos adaptar esse metódo para ser mais conciso. 
        processoDesignado.setSituacao(ESituacao.A_FAZER);
        Movimentacao registro = this.movimentacaoService.criarMovimentacaoDesignacaoProcesso(processoDesignado, 
                                                                                             this.obterUsuarioAtual(),
                                                                                             pessoaDesignada);
        this.processoRepository.save(processoDesignado); 
        return registro;
    }
    public Movimentacao designarComAssessor(Long idProcesso, Long idUsuario, Long idAssessor){
        Usuario auditor = this.usuarioService.getById(idUsuario); //Fiquei tao loco com node que percebi agora que tava usando this.
        Usuario assessor = usuarioService.getById(idAssessor);
        Processo processoDesignado = this.processoRepository.findById(idProcesso).orElse(null);
        processoDesignado.setResponsavel(assessor);
        processoDesignado.setAuditor(auditor); // Precisa ajeitar isso aqui, precisamos adaptar esse metódo para ser mais conciso. 
        processoDesignado.setSituacao(ESituacao.A_FAZER);
        Movimentacao registro = this.movimentacaoService.criarMovimentacaoDesignacaoProcesso(processoDesignado, 
                                                                                             this.obterUsuarioAtual(),
                                                                                             assessor);
        this.processoRepository.save(processoDesignado); 
        return registro;
    }
    public Processo diligirProcesso(Long idProcesso, EMotivoDiligencia motivo, Long idSetorDestino){
        Usuario usuario = obterUsuarioAtual();
        Processo processoParaDiligir = processoRepository.findById(idProcesso).orElse(null);
        Setor setorDestino = setorRepository.findById(idSetorDestino).orElse(null);
        processoParaDiligir.setSituacao(ESituacao.DILIGENCIA);
        processoParaDiligir.setSetorDestino(setorDestino);
        movimentacaoService.criarMovimentacaoDiligenciaProcesso(processoParaDiligir, usuario,motivo,setorDestino);
        return processoRepository.findById(idProcesso).orElse(null);
    }

    public Processo retornoDiligencia(Processo processoRetornadoDaDiligencia){
        Usuario usuario = obterUsuarioAtual();    
        processoRetornadoDaDiligencia.setSituacao(ESituacao.A_DISTRIBUIR); //um processo pode passar anos na diligência.. 
        processoRetornadoDaDiligencia.setAuditor(null); //a pessoa que cuidava dele pode não tratar mais o tipo de assunto.
        processoRetornadoDaDiligencia.setSetorDestino(null);
        processoRetornadoDaDiligencia.setResponsavel(usuario);
        movimentacaoService.criarMovimentacaoRetornoDiligencia(processoRetornadoDaDiligencia, usuario);
        return processoRetornadoDaDiligencia;
    }

    public Processo finalizarProcesso(Processo processoParaFinalizar){
        Usuario usuario = obterUsuarioAtual();
        processoParaFinalizar.setSituacao(ESituacao.A_FINALIZAR);
        processoParaFinalizar.setResponsavel(usuario);
        movimentacaoService.criarMovimentacaoFinalizar(processoParaFinalizar,usuario);
        processoRepository.save(processoParaFinalizar);
        return processoParaFinalizar;

    }

    public Processo concluirProcesso(Processo processo){
        Usuario usuario = obterUsuarioAtual();
        processo.setSituacao(ESituacao.CONCLUIDO);
        processo.setResponsavel(usuario);
        movimentacaoService.criarMovimentacaoConcluir(processo, usuario);
        
        return processoRepository.save(processo);
    }
}
