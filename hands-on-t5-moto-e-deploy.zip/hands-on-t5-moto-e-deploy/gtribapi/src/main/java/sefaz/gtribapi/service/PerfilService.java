// package sefaz.gtribapi.service;

// import org.springframework.data.domain.Page;
// import org.springframework.data.domain.Pageable;
// import org.springframework.stereotype.Service;

// import sefaz.gtribapi.model.Perfil;
// import sefaz.gtribapi.model.PerfilPermissao;
// import sefaz.gtribapi.repository.PerfilPermissaoRepository;
// import sefaz.gtribapi.repository.PerfilRepository;
// import java.util.List;

// @Service
// public class PerfilService implements IService<Perfil>{
//     private final PerfilRepository repo;
//     private PerfilPermissaoRepository perfilPermissaoRepo;

//     public PerfilService(PerfilRepository repo, PerfilPermissaoRepository perfilPermissaoRepo){
//         this.repo = repo;
//         this.perfilPermissaoRepo = perfilPermissaoRepo;

//     }

//     @Override
//     public Page<Perfil> get(String termoBusca,Pageable pageable) {
//         if (termoBusca == null || termoBusca.isBlank()){
//             return repo.findAll(pageable);
//         }else{
//             return repo.busca(termoBusca, pageable);
//         }
       
//     }

//     @Override
//     public Perfil get(Long id) {
//         return repo.findById(id).orElse(null);
//     }

//     @Override
//     public Perfil save(Perfil objeto) {
//         objeto.setId(null); //Não consegui retirar o id da requisição
//         // objeto.setAtivo(true);
//         return repo.save(objeto);
//     }

//     public Perfil update(Long id, Perfil perfil) {
//         Perfil perfilExistente = repo.findById(id).orElse(null);
//         if (perfilExistente != null) {
//             perfilExistente.setNome(perfil.getNome());
    
//             // Atualizando as permissões
//             if (perfil.getPerfilPermissoes() != null) {
//                 // Remover permissões antigas da tabela
//                 List<PerfilPermissao> permissoesAntigas = perfilExistente.getPerfilPermissoes();
//                 for (PerfilPermissao pp : permissoesAntigas) {
//                     // Remover a referência do perfil para evitar problemas de integridade referencial
//                     pp.setPerfil(null);
//                     perfilPermissaoRepo.delete(pp); // Certifique-se de ter um repositório para PerfilPermissao
//                 }
//                 permissoesAntigas.clear();
    
//                 // Adicionar permissões novas, garantindo a referência bidirecional
//                 for (PerfilPermissao permissao : perfil.getPerfilPermissoes()) {
//                     permissao.setPerfil(perfilExistente); // Atualiza a referência bidirecional
//                     perfilPermissaoRepo.save(permissao); // Salva as novas permissões
//                     perfilExistente.getPerfilPermissoes().add(permissao);
//                 }
//             }
    
//             return repo.save(perfilExistente); // Atualiza o perfil existente
//         }
//         return null; // Ou lançar uma exceção se preferir
//     }
    


    
//     // public Perfil deletarPerfil(Long id,Boolean ativo) {
//     //     Perfil perfil = get(id);
        
//     //     if (ativo == false) {
//     //         perfil.setAtivo(ativo);
//     //         return repo.save(setor);
//     //     }
//     //     perfil.setAtivo(ativo);
//     //     return repo.save(setor);
//     // }

//     @Override
//     public void delete(Long id) {
//         // TODO Auto-generated method stub
//         throw new UnsupportedOperationException("Unimplemented method 'delete'");
//     }


// }
