// package sefaz.gtribapi.controller.mapper;

// import org.mapstruct.InheritInverseConfiguration;
// import org.mapstruct.Mapper;

// import sefaz.gtribapi.controller.dto.PermissaoDto;
// import sefaz.gtribapi.model.Perfil;
// import sefaz.gtribapi.model.Permissao;

// @Mapper(componentModel = "spring")
// public interface PermissaoMapper {
    
//     PermissaoDto toDto(Permissao perfil);

//     @InheritInverseConfiguration
//     Permissao toEntity(PermissaoDto dto);
// }
