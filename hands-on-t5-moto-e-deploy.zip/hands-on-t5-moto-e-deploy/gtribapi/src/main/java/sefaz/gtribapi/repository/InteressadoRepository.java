package sefaz.gtribapi.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import sefaz.gtribapi.model.Interessado;

import java.util.Optional;

@Repository
public interface InteressadoRepository extends JpaRepository<Interessado, Long> {
    Optional<Interessado> findByCpfCnpj(String cpfCnpj);

    @Query("SELECT i from Interessado i WHERE i.nome LIKE %?1%" +
    " OR i.cpfCnpj LIKE %?1%")
    Page<Interessado> busca(String termo, Pageable page);
}
