package sefaz.gtribapi.model;

public enum EMotivoDiligencia {
   PENDENTE_DE_DOCUMENTACAO 
}
