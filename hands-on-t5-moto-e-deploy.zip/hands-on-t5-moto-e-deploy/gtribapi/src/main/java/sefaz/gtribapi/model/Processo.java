package sefaz.gtribapi.model;

import java.io.Serializable;
import java.time.LocalDate;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.validation.constraints.NotNull;


import java.util.List; 
import java.util.ArrayList;


@Entity
public class Processo implements Serializable{

    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    private Long id;

    @NotNull(message = "O número do processo é obrigatório.")
    @Column(nullable = false)
    private Long numeroProcesso;

    @NotNull(message = "A data da capa é obrigatória.")
    @Column(nullable = false)
    private LocalDate dataCapa;

    @NotNull(message = "A situação é obrigatória.")
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private ESituacao situacao = ESituacao.A_DISTRIBUIR;

    @Enumerated(EnumType.STRING)
    private EConclusao conclusao;
    
    @Column(nullable = true) //Não acontece no momento de criação do processo.
    private Long numeroParecer;

    @NotNull(message = "O interessado e obrigatorio.")
    @ManyToOne(optional = false)
    private Interessado interessado;


    @NotNull(message = "O assunto é obrigatório.")
    @ManyToOne(optional = false)
    private Assunto assunto;

    @ManyToOne
    private Usuario responsavel;

    @ManyToOne(optional = true) //Deve ser opcional pois no momento que ele é criado não tem auditor.
    private Usuario auditor;

    @ManyToOne(optional = true) //Deve ser opcional pois no momento que ele é criado não tem acessor.
    private Usuario acessor;

    @ManyToOne(optional = true) //Deve ser opcional pois não sabemos se ele vai ter diligências.
    private Setor setorDestino;

    @Column(nullable = true)
    private String observacoes;

    @Enumerated(EnumType.STRING)
    @Column(nullable = true)
    private EDificuldade dificuldade;

    @Column(nullable = true)
    private String palavrasChave;
     // Relação com Movimentacao
     @OneToMany(mappedBy = "processo", cascade = CascadeType.ALL, orphanRemoval = true)
     private List<Movimentacao> movimentacoes = new ArrayList<>();
 
     public List<Movimentacao> getMovimentacoes() {
         return movimentacoes;
     }

     
    public String getObservacoes() {
        return observacoes;
    }

    public void setObservacoes(String observacoes) {
        this.observacoes = observacoes;
    }

    public EDificuldade getDificuldade() {
        return dificuldade;
    }

    public void setDificuldade(EDificuldade dificuldade) {
        this.dificuldade = dificuldade;
    }

    public String getPalavrasChave() {
        return palavrasChave;
    }

    public void setPalavrasChave(String palavrasChave) {
        this.palavrasChave = palavrasChave;
    }
 
     public void setMovimentacoes(List<Movimentacao> movimentacoes) {
         this.movimentacoes = movimentacoes;
     }
     
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getNumeroProcesso() {
        return numeroProcesso;
    }

    public void setNumeroProcesso(Long numeroProcesso) {
        this.numeroProcesso = numeroProcesso;
    }

    public LocalDate getDataCapa() {
        return dataCapa;
    }

    public void setDataCapa(LocalDate dataCapa) {
        this.dataCapa = dataCapa;
    }

    public ESituacao getSituacao() {
        return situacao;
    }

    public void setSituacao(ESituacao situacao) {
        this.situacao = situacao;
    }

    public EConclusao getConclusao() {
        return conclusao;
    }

    public void setConclusao(EConclusao conclusao) {
        this.conclusao = conclusao;
    }

    public Long getNumeroParecer() {
        return numeroParecer;
    }

    public void setNumeroParecer(Long numeroParecer) {
        this.numeroParecer = numeroParecer;
    }


    public Interessado getInteressado() {
        return interessado;
    }


    public void setInteressado(Interessado interessado) {
        this.interessado = interessado;
    }

    public Assunto getAssunto() {
        return assunto;
    }

    public void setAssunto(Assunto assunto) {
        this.assunto = assunto;
    }

    public Usuario getResponsavel() {
        return responsavel;
    }

    public void setResponsavel(Usuario responsavel) {
        this.responsavel = responsavel;
    }

    public Usuario getAuditor() {
        return auditor;
    }

    public void setAuditor(Usuario auditor) {
        this.auditor = auditor;
    }

    public Usuario getAcessor() {
        return acessor;
    }

    public void setAcessor(Usuario acessor) {
        this.acessor = acessor;
    }

    public Setor getSetorDestino() {
        return setorDestino;
    }

    public void setSetorDestino(Setor setorDestino) {
        this.setorDestino = setorDestino;
    }
}
