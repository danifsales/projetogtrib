package sefaz.gtribapi.controller.dto;

import java.util.Date;

import sefaz.gtribapi.model.Setor;

public record MovimentacaoDto(
    Long id,
    Date data,
    String movimentacao,
    String usuarioNome,
    Long usuarioId,
    String designadoNome,
    Setor idSetorDestino,
    Long processo,
    String setorNome
) {}
