package sefaz.gtribapi.model;

public enum EUTipo {
    AUDITOR,
    ASSESSOR,
    SECRETARIA;
}
