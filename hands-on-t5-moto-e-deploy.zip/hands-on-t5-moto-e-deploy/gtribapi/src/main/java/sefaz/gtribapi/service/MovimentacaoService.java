package sefaz.gtribapi.service;

import java.util.Date;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import sefaz.gtribapi.model.EMotivoDiligencia;
import sefaz.gtribapi.model.EMovimentacao;
import sefaz.gtribapi.model.Movimentacao;
import sefaz.gtribapi.model.Processo;
import sefaz.gtribapi.model.Setor;
import sefaz.gtribapi.model.Usuario;
import sefaz.gtribapi.repository.MovimentacaoRepository;


@Service

public class MovimentacaoService {

    private final MovimentacaoRepository movimentacaoRepository;

    public MovimentacaoService(MovimentacaoRepository movimentacaoRepository){
        this.movimentacaoRepository = movimentacaoRepository;
    }

    private Movimentacao criarMovimentacaoSimples(EMovimentacao tipoDaMovimentacao, Processo processo, Usuario usuarioQueRealizouMovimentacao){ 
        //Percebi redundância na codificação de movimentação.
        //Essa simples função cria o básico que tem que ter em todo tipo de movimentação do sistema.
        Movimentacao movimentacao = new Movimentacao();
        movimentacao.setData(new Date());
        movimentacao.setMovimentacao(tipoDaMovimentacao);
        movimentacao.setProcesso(processo);
        movimentacao.setUsuario(usuarioQueRealizouMovimentacao);
        return movimentacao;
    }
    @Transactional
    public Movimentacao criarMovimentacaoAberturaProcesso(Processo processo, Usuario usuario) {
        Movimentacao movimentacao = criarMovimentacaoSimples(EMovimentacao.ABERTURA_PROCESSO, processo, usuario); 
        return movimentacaoRepository.save(movimentacao);
    }

    public Movimentacao criarMovimentacaoDesignacaoProcesso(Processo processo, Usuario usuarioDesignador, Usuario usuarioDesignado){
        Movimentacao movimentacao = criarMovimentacaoSimples(EMovimentacao.DESIGNACAO,processo,usuarioDesignador);
        movimentacao.setDesignado(usuarioDesignado);
        return movimentacaoRepository.save(movimentacao);
    }

    public Movimentacao criarMovimentacaoInicioAnalise(Processo processo, Usuario usuarioQueRealizou){
        Movimentacao movimentacao = criarMovimentacaoSimples(EMovimentacao.INICIO_ANALISE, processo, usuarioQueRealizou);
        return movimentacaoRepository.save(movimentacao);
    }
    // Método paginado
    public Page<Movimentacao> buscarMovimentacoesPaginadas(Pageable pageable) {
        return movimentacaoRepository.findAll(pageable);
    }
    
    public Movimentacao criarMovimentacaoDiligenciaProcesso(Processo processo, Usuario usuario, EMotivoDiligencia motivo, Setor setor){
        Movimentacao movimentacao = criarMovimentacaoSimples(EMovimentacao.DILIGENCIA, processo, usuario);
        movimentacao.setMotivoDiligencia(motivo);
        movimentacao.setIdSetorDestino(setor);
        return movimentacaoRepository.save(movimentacao);
    }

    public Movimentacao criarMovimentacaoRetornoDiligencia(Processo processo, Usuario usuario){
        Movimentacao movimentacao = criarMovimentacaoSimples(EMovimentacao.RETORNO_DILIGENCIA, processo, usuario);
        return movimentacaoRepository.save(movimentacao);
    }

    public Movimentacao criarMovimentacaoFinalizar(Processo processo, Usuario usuario){
        Movimentacao movimentacao = criarMovimentacaoSimples(EMovimentacao.FINALIZACAO_ANALISE, processo, usuario);
        return movimentacaoRepository.save(movimentacao);
    }

    public Movimentacao criarMovimentacaoConcluir(Processo processo, Usuario usuario){
        Movimentacao movimentacao = criarMovimentacaoSimples(EMovimentacao.CONCLUSAO, processo, usuario);
        return movimentacaoRepository.save(movimentacao);
    }

    public Page<Movimentacao> get(String termoBusca, Pageable pageable) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'get'");
    }

}
