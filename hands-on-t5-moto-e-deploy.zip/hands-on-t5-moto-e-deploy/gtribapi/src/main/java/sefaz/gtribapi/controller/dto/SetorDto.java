package sefaz.gtribapi.controller.dto;

public record SetorDto (
    Long id,
    String nome,
    Long codigo,
    Boolean ativo
){}


