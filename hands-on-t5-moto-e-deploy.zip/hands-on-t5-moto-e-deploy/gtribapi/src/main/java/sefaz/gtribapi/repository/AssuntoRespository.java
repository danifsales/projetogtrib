package sefaz.gtribapi.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import sefaz.gtribapi.model.Assunto;



@Repository
public interface AssuntoRespository extends JpaRepository<Assunto,Long>{
    @Query("SELECT a FROM Assunto a WHERE a.sigla LIKE %?1% OR a.descricao LIKE %?1%")
    Page<Assunto> busca(String termo, Pageable pageable);

    @Query("SELECT a FROM Assunto a")
    Page<Assunto> assuntos(Pageable pageable);

    @Query("SELECT a FROM Assunto a WHERE a.ativo = true")
    Page<Assunto> findByAtivoTrue(Pageable pageable);
}
