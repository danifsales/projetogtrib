// package sefaz.gtribapi.repository;

// import org.apache.el.stream.Optional;
// import org.springframework.data.jpa.repository.JpaRepository;
// import sefaz.gtribapi.model.PerfilPermissao;
// import java.util.List;

// public interface PerfilPermissaoRepository extends JpaRepository<PerfilPermissao, Long> {
//     List<PerfilPermissao> findByPerfilId(Long perfilId);
//     List<PerfilPermissao> findByPerfilIdAndPermissaoId(Long perfilId, Long permissaoId);

// }