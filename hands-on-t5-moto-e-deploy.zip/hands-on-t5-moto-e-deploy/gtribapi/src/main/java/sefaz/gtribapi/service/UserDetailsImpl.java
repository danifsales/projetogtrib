package sefaz.gtribapi.service;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import sefaz.gtribapi.model.EUTipo;
import sefaz.gtribapi.model.Usuario;

import java.util.Collection;
import java.util.Collections;

public class UserDetailsImpl implements UserDetails {

    private Long id;
    private String name;
    private String username;
    private String password;
    private EUTipo tipoUsuario;

    public UserDetailsImpl(Long id, String name, String username, String password, EUTipo tipoUsuario) {
        this.id = id;
        this.name = name;
        this.username = username;
        this.password = password;
        this.tipoUsuario = tipoUsuario;
    }

    // Método build para construir a partir de um objeto Usuario
    public static UserDetailsImpl build(Usuario usuario) {
        return new UserDetailsImpl(
            usuario.getId(),
            usuario.getNomeCompleto(),
            usuario.getLogin(),
            usuario.getSenha(),
            usuario.getTipoUsuario()
        );
    }

	public Long getId() {
        return id;
    }
	
	public String getName() {
        return name;
    }

    public String getLogin(){
        return username;
    }

    public EUTipo getTipoUsuario() {
        return tipoUsuario;
    }

    @Override
    public String getPassword() {
        return password;
    }

    @Override
    public String getUsername() {
        return username;
    }

    // Implementação de getAuthorities() retornando uma coleção vazia
    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return Collections.emptyList(); // Retorna uma lista vazia de authorities
    }

    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    @Override
    public boolean isEnabled() {
        return true;
    }
}
