package sefaz.gtribapi.controller.dto;

public class PerfilPermissaoDTO {

    private String nomePerfil;
    private String nomePermissao;
    private String nivelAcesso;

    public PerfilPermissaoDTO(String nomePerfil, String nomePermissao, String nivelAcesso) {
        this.nomePerfil = nomePerfil;
        this.nomePermissao = nomePermissao;
        this.nivelAcesso = nivelAcesso;
    }

    public String getNomePerfil() {
        return nomePerfil;
    }

    public void setNomePerfil(String nomePerfil) {
        this.nomePerfil = nomePerfil;
    }

    public String getNomePermissao() {
        return nomePermissao;
    }

    public void setNomePermissao(String nomePermissao) {
        this.nomePermissao = nomePermissao;
    }

    public String getNivelAcesso() {
        return nivelAcesso;
    }

    public void setNivelAcesso(String nivelAcesso) {
        this.nivelAcesso = nivelAcesso;
    }
}
