package sefaz.gtribapi.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;


import sefaz.gtribapi.model.Interessado;
import sefaz.gtribapi.repository.InteressadoRepository;

@Service
public class InteressadoService implements IService<Interessado>{
        private final InteressadoRepository repo;

        public InteressadoService(InteressadoRepository repo){
            this.repo = repo;
        }
    @Override
    public Page<Interessado> get(String termoBusca, Pageable pageable) {
        if (termoBusca == null || termoBusca.isBlank()){
            return repo.findAll(pageable);
        }else{
            return repo.busca(termoBusca, pageable);
        }
       
    }


    @Override
    public Interessado get(Long id) {
        return repo.findById(id).orElse(null);
    }

    @Override
    public Interessado save(Interessado objeto) {
        return repo.save(objeto);
    }

    @Override
    public void delete(Long id) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'delete'");
    }
    
}
