// package sefaz.gtribapi.controller;


// import org.springdoc.core.annotations.ParameterObject;
// import org.springframework.data.domain.Pageable;
// import org.springframework.http.HttpStatus;
// import org.springframework.http.ResponseEntity;
// import org.springframework.web.bind.annotation.DeleteMapping;
// import org.springframework.web.bind.annotation.GetMapping;
// import org.springframework.web.bind.annotation.PathVariable;
// import org.springframework.web.bind.annotation.PostMapping;
// import org.springframework.web.bind.annotation.RequestBody;
// import org.springframework.web.bind.annotation.RequestMapping;
// import org.springframework.web.bind.annotation.RequestParam;
// import org.springframework.web.bind.annotation.RestController;


// import org.springframework.data.domain.Page;

// import sefaz.gtribapi.controller.dto.PermissaoDto;
// import sefaz.gtribapi.controller.mapper.PermissaoMapper;
// import sefaz.gtribapi.model.Permissao;
// import sefaz.gtribapi.service.PermissaoService;
// @RestController
// @RequestMapping("/permissao")
// public class PermissaoController {
//     private final PermissaoService servico;
//     private final PermissaoMapper mapper;

//     public PermissaoController(PermissaoService service, PermissaoMapper mapper){
//         this.servico = service;
//         this.mapper = mapper;
//     }

//     @GetMapping("/")
//     public ResponseEntity<Page<PermissaoDto>> get(
//         @RequestParam(required = false) String termoBusca,
//         @RequestParam(required = false, defaultValue = "false") boolean unpaged,
//         @ParameterObject Pageable pageable) {

//         if (unpaged) {
//             pageable = Pageable.unpaged();
//         }

//         Page<Permissao> registros = servico.get(termoBusca, pageable);
//         Page<PermissaoDto> dtos = registros.map(mapper::toDto);
//         return ResponseEntity.ok(dtos);
//     }

//     @GetMapping("/{id}")
//     public ResponseEntity<PermissaoDto> get(@PathVariable("id") Long id){
//         Permissao registro = servico.get(id);
//         if (registro == null){
//             return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
//         }
//         PermissaoDto dto = mapper.toDto(registro);
//         return ResponseEntity.ok(dto);
//     }

//     @PostMapping("/")
//     public ResponseEntity<PermissaoDto> insert(@RequestBody PermissaoDto objeto){
//         Permissao objetoConvertido = mapper.toEntity(objeto);
//         Permissao registro = servico.save(objetoConvertido);
//         PermissaoDto dto = mapper.toDto(registro);
//         return ResponseEntity.status(HttpStatus.CREATED).body(dto);
//     }

//     // @DeleteMapping("/{id}")
//     // public ResponseEntity<SetorDto> delete(@PathVariable("id") Long id,
//     //                                         @RequestParam(name = "ativo",required = true)Boolean ativo) {
//     //     Setor registro = servico.deletarSetor(id,ativo);
//     //     SetorDto dto =  mapper.toDto(registro);
//     //     return ResponseEntity.ok(dto);                                    
//     // }
// }
