package sefaz.gtribapi.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import sefaz.gtribapi.model.Usuario;
import sefaz.gtribapi.repository.UsuarioRepository;


@Service
public class UsuarioService {
    @Autowired
	private UsuarioRepository UsuarioRepository;
	
	@Autowired
	private PasswordEncoder passwordEncoder;
    private final UsuarioRepository usuarioRepository;

    public UsuarioService(UsuarioRepository usuarioRepository){
        this.passwordEncoder = passwordEncoder;
        this.usuarioRepository = usuarioRepository;
    }

        public Page<Usuario> get(String termoBusca, Pageable pageable) {
        if (termoBusca == null || termoBusca.isBlank()) {
            return usuarioRepository.findAll(pageable);
        } else {
            return usuarioRepository.busca(termoBusca, pageable);
        }
    }
        
    public Usuario getById(Long id){
        return this.usuarioRepository.findById(id).orElse(null);
    }

    public Usuario salvarUsuario(Usuario usuario) {
        usuario.setSenha(passwordEncoder.encode(usuario.getSenha()));
        return usuarioRepository.save(usuario);
    }


public Usuario getUsuarioAutenticado() {
    Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();

    if (principal instanceof UserDetailsImpl) {
        UserDetailsImpl username = (UserDetailsImpl) principal;
        String login = username.getLogin();
        // Use o repositório para buscar o usuário completo pelo nome de usuário
        return usuarioRepository.findByLogin(login).orElse(null);
    } else {
        return null;
    }
}
}
	

