// package sefaz.gtribapi.model;

// import java.io.Serializable;
// import java.util.List;
// import jakarta.persistence.Column;
// import jakarta.persistence.Entity;
// import jakarta.persistence.GeneratedValue;
// import jakarta.persistence.GenerationType;
// import jakarta.persistence.Id;
// import jakarta.persistence.OneToMany;

// @Entity
// public class Permissao implements Serializable {

//     @Id
//     @GeneratedValue(strategy = GenerationType.IDENTITY)
//     private Long id;

//     @Column(nullable = false)
//     private String descricao;

//     @Column(nullable = false)
//     private boolean tipoCrud;

//     @OneToMany(mappedBy = "permissao")
//     private List<PerfilPermissao> perfilPermissoes;

//     // Getters e Setters
//     public Long getId() {
//         return id;
//     }

//     public void setId(Long id) {
//         this.id = id;
//     }

//     public String getDescricao() {
//         return descricao;
//     }

//     public void setDescricao(String descricao) {
//         this.descricao = descricao;
//     }

//     public boolean isTipoCrud() {
//         return tipoCrud;
//     }

//     public boolean getTipoCrud() {
//         return tipoCrud;
//     }

//     public void setTipoCrud(boolean tipoCrud) {
//         this.tipoCrud = tipoCrud;
//     }

//     public List<PerfilPermissao> getPerfilPermissoes() {
//         return perfilPermissoes;
//     }

//     public void setPerfilPermissoes(List<PerfilPermissao> perfilPermissoes) {
//         this.perfilPermissoes = perfilPermissoes;
//     }
// }
