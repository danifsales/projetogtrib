package sefaz.gtribapi.model;

public enum ENivelAcesso {
    NONE,
    READ,
    WRITE,
    READ_WRITE,
    FULL,
}
