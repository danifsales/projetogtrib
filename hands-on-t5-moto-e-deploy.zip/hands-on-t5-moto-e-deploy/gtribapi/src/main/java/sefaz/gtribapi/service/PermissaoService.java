// package sefaz.gtribapi.service;

// import org.springframework.data.domain.Page;
// import org.springframework.data.domain.Pageable;
// import org.springframework.stereotype.Service;

// import sefaz.gtribapi.model.Permissao;
// import sefaz.gtribapi.repository.PermissaoRepository;

// @Service
// public class PermissaoService implements IService<Permissao>{
//     private final PermissaoRepository repo;

//     public PermissaoService(PermissaoRepository repo){
//         this.repo = repo;
//     }

//     @Override
//     public Page<Permissao> get(String termoBusca,Pageable pageable) {
//         if (termoBusca == null || termoBusca.isBlank()){
//             return repo.findAll(pageable);
//         }else{
//             return repo.busca(termoBusca, pageable);
//         }
       
//     }

//     @Override
//     public Permissao get(Long id) {
//         return repo.findById(id).orElse(null);
//     }

//     @Override
//     public Permissao save(Permissao objeto) {
//         objeto.setId(null); //Não consegui retirar o id da requisição
//         // objeto.setAtivo(true);
//         return repo.save(objeto);
//     }

    
//     // public Perfil deletarPerfil(Long id,Boolean ativo) {
//     //     Perfil perfil = get(id);
        
//     //     if (ativo == false) {
//     //         perfil.setAtivo(ativo);
//     //         return repo.save(setor);
//     //     }
//     //     perfil.setAtivo(ativo);
//     //     return repo.save(setor);
//     // }

//     @Override
//     public void delete(Long id) {
//         // TODO Auto-generated method stub
//         throw new UnsupportedOperationException("Unimplemented method 'delete'");
//     }


// }
