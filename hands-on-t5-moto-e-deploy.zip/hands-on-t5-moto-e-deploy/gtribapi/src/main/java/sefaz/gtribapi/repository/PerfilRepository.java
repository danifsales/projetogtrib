// package sefaz.gtribapi.repository;

// import org.springframework.data.domain.Page;
// import org.springframework.data.domain.Pageable;
// import org.springframework.data.jpa.repository.JpaRepository;
// import org.springframework.data.jpa.repository.Query;
// import org.springframework.stereotype.Repository;

// import sefaz.gtribapi.model.Perfil;


// @Repository
// public interface PerfilRepository extends JpaRepository<Perfil,Long>{
//     @Query("SELECT p FROM Perfil p WHERE p.nome LIKE %?1%")
//     Page<Perfil> busca(String termo, Pageable page);
// }

