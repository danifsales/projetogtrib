package sefaz.gtribapi.controller.dto;

import jakarta.validation.constraints.NotNull;
import sefaz.gtribapi.model.EDificuldade;

public class FinalizarProcessoDto {

    @NotNull
    private Long parecerNumero;
    
    private EDificuldade nivelDificuldade;
    private String palavraChave;
    private String observacao;

    // Getters
    public Long getParecerNumero() {
        return parecerNumero;
    }

    public EDificuldade getNivelDificuldade() {
        return nivelDificuldade;
    }

    public String getPalavraChave() {
        return palavraChave;
    }

    public String getObservacao() {
        return observacao;
    }

    // Setters
    public void setParecerNumero(Long parecerNumero) {
        this.parecerNumero = parecerNumero;
    }

    public void setNivelDificuldade(EDificuldade nivelDificuldade) {
        this.nivelDificuldade = nivelDificuldade;
    }

    public void setPalavraChave(String palavraChave) {
        this.palavraChave = palavraChave;
    }

    public void setObservacao(String observacao) {
        this.observacao = observacao;
    }
}
