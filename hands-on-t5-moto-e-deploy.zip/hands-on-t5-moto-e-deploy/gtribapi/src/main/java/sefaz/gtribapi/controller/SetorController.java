package sefaz.gtribapi.controller;

import org.springdoc.core.annotations.ParameterObject;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import sefaz.gtribapi.controller.dto.SetorDto;
import sefaz.gtribapi.controller.mapper.SetorMapper;
import sefaz.gtribapi.model.Setor;
import sefaz.gtribapi.service.SetorService;

@RestController
@RequestMapping("/setores")
public class SetorController {
    private final SetorService servico;
    private final SetorMapper mapper;

    public SetorController(SetorService service, SetorMapper mapper) {
        this.servico = service;
        this.mapper = mapper;
    }

    @GetMapping("/")
    public ResponseEntity<Page<SetorDto>> get(
        @RequestParam(required = false) String termoBusca,
        @RequestParam(required = false, defaultValue = "false") boolean unpaged,
        @ParameterObject Pageable pageable) {

        if (unpaged) {
            pageable = Pageable.unpaged();
        }

        Page<Setor> registros = servico.get(termoBusca, pageable);
        Page<SetorDto> dtos = registros.map(mapper::toDto);
        return ResponseEntity.ok(dtos);
    }

    @GetMapping("/{id}")
    public ResponseEntity<SetorDto> get(@PathVariable("id") Long id) {
        Setor registro = servico.get(id);
        if (registro == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        }
        SetorDto dto = mapper.toDto(registro);
        return ResponseEntity.ok(dto);
    }

    @PostMapping("/")
    public ResponseEntity<?> insert(@RequestBody SetorDto objeto) {
        Setor objetoConvertido = mapper.toEntity(objeto);
        try {
            Setor registro = servico.save(objetoConvertido);
            SetorDto dto = mapper.toDto(registro);
            return ResponseEntity.status(HttpStatus.CREATED).body(dto);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> update(@PathVariable("id") Long id, @RequestBody SetorDto objeto) {
        Setor setorExistente = servico.get(id);
        if (setorExistente == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Setor não encontrado.");
        }

        Setor objetoConvertido = mapper.toEntity(objeto);
        objetoConvertido.setId(id); // Garantir que o ID é o mesmo

        try {
            Setor setorAtualizado = servico.update(id, objetoConvertido);
            SetorDto dto = mapper.toDto(setorAtualizado);
            return ResponseEntity.ok(dto);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<SetorDto> delete(@PathVariable("id") Long id,
                                           @RequestParam(name = "ativo", required = true) Boolean ativo) {
        Setor registro = servico.deletarSetor(id, ativo);
        SetorDto dto = mapper.toDto(registro);
        return ResponseEntity.ok(dto);
    }
    @GetMapping("/ativos")
    public ResponseEntity<Page<SetorDto>> getAtivos(
        @RequestParam(required = false, defaultValue = "false") boolean unpaged,
        @ParameterObject Pageable pageable) {

        if (unpaged) {
            pageable = Pageable.unpaged();
        }

        Page<Setor> setoresAtivos = servico.getAtivo(pageable);
        Page<SetorDto> dtos = setoresAtivos.map(mapper::toDto);
        return ResponseEntity.ok(dtos);
    }
}
