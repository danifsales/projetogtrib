// package sefaz.gtribapi.controller;

// import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.http.ResponseEntity;
// import org.springframework.web.bind.annotation.*;
// import sefaz.gtribapi.model.PerfilPermissao;
// import sefaz.gtribapi.model.Perfil;
// import sefaz.gtribapi.model.Permissao;
// import sefaz.gtribapi.controller.dto.PerfilPermissaoDTO;
// import sefaz.gtribapi.model.ENivelAcesso;
// import sefaz.gtribapi.repository.PerfilPermissaoRepository;
// import sefaz.gtribapi.repository.PerfilRepository;
// import sefaz.gtribapi.repository.PermissaoRepository;

// import java.util.List;
// import java.util.Optional;
// import java.util.stream.Collectors;

// @RestController
// @RequestMapping("/perfil-permissao")
// public class PerfilPermissaoController {

//     @Autowired
//     private PerfilPermissaoRepository perfilPermissaoRepository;

//     @Autowired
//     private PerfilRepository perfilRepository;

//     @Autowired
//     private PermissaoRepository permissaoRepository;

//     // Endpoint para listar as permissões de um perfil
//     @GetMapping("/permissoes/{perfilId}")
//     public ResponseEntity<List<PerfilPermissaoDTO>> listarPermissoesPorPerfil(@PathVariable Long perfilId) {
//         Optional<Perfil> perfilOptional = perfilRepository.findById(perfilId);
//         if (perfilOptional.isEmpty()) {
//             return ResponseEntity.notFound().build();
//         }

//         List<PerfilPermissao> permissoes = perfilPermissaoRepository.findByPerfilId(perfilId);

//         List<PerfilPermissaoDTO> permissoesDTO = permissoes.stream()
//                 .map(perfilPermissao -> new PerfilPermissaoDTO(
//                         perfilPermissao.getPerfil().getNome(),
//                         perfilPermissao.getPermissao().getDescricao(),
//                         perfilPermissao.getNivelAcesso().toString()
//                 ))
//                 .collect(Collectors.toList());

//         return ResponseEntity.ok(permissoesDTO);
//     }

//     // Endpoint para adicionar uma permissão a um perfil
//     @PostMapping("/adicionar-permissao/{perfilId}/{permissaoId}")
//     public ResponseEntity<PerfilPermissaoDTO> adicionarPermissaoAoPerfil(
//             @PathVariable Long perfilId,
//             @PathVariable Long permissaoId,
//             @RequestParam ENivelAcesso nivelAcesso) {

//         Optional<Perfil> perfilOptional = perfilRepository.findById(perfilId);
//         if (perfilOptional.isEmpty()) {
//             return ResponseEntity.notFound().build();
//         }

//         Optional<Permissao> permissaoOptional = permissaoRepository.findById(permissaoId);
//         if (permissaoOptional.isEmpty()) {
//             return ResponseEntity.notFound().build();
//         }

//         PerfilPermissao perfilPermissao = new PerfilPermissao();
//         perfilPermissao.setPerfil(perfilOptional.get());
//         perfilPermissao.setPermissao(permissaoOptional.get());
//         perfilPermissao.setNivelAcesso(nivelAcesso);

//         PerfilPermissao novaPermissao = perfilPermissaoRepository.save(perfilPermissao);

//         // Converte o objeto salvo para DTO
//         PerfilPermissaoDTO perfilPermissaoDTO = new PerfilPermissaoDTO(
//                 novaPermissao.getPerfil().getNome(),
//                 novaPermissao.getPermissao().getDescricao(),
//                 novaPermissao.getNivelAcesso().toString()
//         );

//         return ResponseEntity.ok(perfilPermissaoDTO);
//     }

//     // Endpoint para remover uma permissão de um perfil
//     @DeleteMapping("/remover-permissao/{perfilId}/{permissaoId}")
//     public ResponseEntity<Void> removerPermissaoDoPerfil(
//             @PathVariable Long perfilId,
//             @PathVariable Long permissaoId) {

//         List<PerfilPermissao> perfilPermissaoOptional = perfilPermissaoRepository.findByPerfilIdAndPermissaoId(perfilId, permissaoId);
//         if (perfilPermissaoOptional.isEmpty()) {
//             return ResponseEntity.notFound().build();
//         }

//         perfilPermissaoRepository.delete(perfilPermissaoOptional.get(0));
//         return ResponseEntity.noContent().build();
//     }

//     // Endpoint para editar o nível de acesso de uma permissão de um perfil
//     @PutMapping("/editar-nivel-acesso/{perfilId}/{permissaoId}")
//     public ResponseEntity<PerfilPermissaoDTO> editarNivelAcesso(
//             @PathVariable Long perfilId,
//             @PathVariable Long permissaoId,
//             @RequestParam ENivelAcesso novoNivelAcesso) {

//         List<PerfilPermissao> perfilPermissaoOptional = perfilPermissaoRepository.findByPerfilIdAndPermissaoId(perfilId, permissaoId);
//         if (perfilPermissaoOptional.isEmpty()) {
//             return ResponseEntity.notFound().build();
//         }

//         PerfilPermissao perfilPermissao = perfilPermissaoOptional.get(0);
//         perfilPermissao.setNivelAcesso(novoNivelAcesso);

//         PerfilPermissao permissaoAtualizada = perfilPermissaoRepository.save(perfilPermissao);

//         PerfilPermissaoDTO perfilPermissaoDTO = new PerfilPermissaoDTO(
//                 permissaoAtualizada.getPerfil().getNome(),
//                 permissaoAtualizada.getPermissao().getDescricao(),
//                 permissaoAtualizada.getNivelAcesso().toString()
//         );

//         return ResponseEntity.ok(perfilPermissaoDTO);
//     }
// }
