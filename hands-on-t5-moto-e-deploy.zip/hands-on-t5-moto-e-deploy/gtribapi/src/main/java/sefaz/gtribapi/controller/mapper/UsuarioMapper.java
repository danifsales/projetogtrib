package sefaz.gtribapi.controller.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import sefaz.gtribapi.controller.dto.UsuarioDto;
import sefaz.gtribapi.model.Usuario;

@Mapper(componentModel = "spring")
public interface UsuarioMapper {
    @Mapping(target="id",source="usuario.id")
    @Mapping(target="nomeCompleto",source="usuario.nomeCompleto")
    @Mapping(target="login",source="usuario.login")
    @Mapping(target="perfil",source="usuario.tipoUsuario")

    UsuarioDto toDto(Usuario usuario);
}
