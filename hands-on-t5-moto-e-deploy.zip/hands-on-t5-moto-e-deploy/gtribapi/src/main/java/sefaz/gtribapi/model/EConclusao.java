package sefaz.gtribapi.model;

public enum EConclusao {
    DEFERIDO,
    INDEFERIDO;
}
