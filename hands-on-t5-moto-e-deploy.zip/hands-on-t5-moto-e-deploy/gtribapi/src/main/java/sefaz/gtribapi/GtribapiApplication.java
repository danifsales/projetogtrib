package sefaz.gtribapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import io.swagger.v3.oas.annotations.Hidden;
import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Info;
import io.swagger.v3.oas.annotations.servers.Server;

@SpringBootApplication
@Hidden
@Configuration
@EnableAutoConfiguration
@ComponentScan
@OpenAPIDefinition(
	info = @Info(
		title = "GTRIB API",
		version = "1.0",
		description = "API do Sistema de Gestão do Setor de Tributação da SEFAZ"),
	servers = {
		@Server(
			url = "http://localhost:9000",
			description = "Ambiente de desenvolvimento"
		)
	}
)
public class GtribapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(GtribapiApplication.class, args);
	}

}
