package sefaz.gtribapi.controller.dto;

public record PermissaoDto (
    Long id,
    String descricao,
    Boolean tipoCrud,
    String nivelAcesso
){}


