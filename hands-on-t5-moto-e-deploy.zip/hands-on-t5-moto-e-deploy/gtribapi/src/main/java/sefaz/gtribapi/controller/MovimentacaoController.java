package sefaz.gtribapi.controller;

import org.springdoc.core.annotations.ParameterObject;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import sefaz.gtribapi.controller.dto.MovimentacaoDto;
import sefaz.gtribapi.controller.dto.ProcessoDto;
import sefaz.gtribapi.controller.mapper.MovimentacaoMapper;
import sefaz.gtribapi.controller.mapper.ProcessoMapper;
import sefaz.gtribapi.model.EMotivoDiligencia;
import sefaz.gtribapi.model.ESituacao;
import sefaz.gtribapi.model.Movimentacao;
import sefaz.gtribapi.model.Processo;
import sefaz.gtribapi.model.Usuario;
import sefaz.gtribapi.service.MovimentacaoService;
import sefaz.gtribapi.service.ProcessoService;
import sefaz.gtribapi.service.UsuarioService;
import java.util.Optional;

@RestController
// STATELESS -> a cada nova requisição eu recebo todas as informações que eu preciso para fazer a funcionalidade que o cliente pediu;
//STATEFULL -> o estado de cada cliente é mantido no servidor;
@Controller
@ResponseBody
@RequestMapping("/movimentacoes")
@Tag(
    name = "Movimentacoes",
    description = "Endpoints para gerenciar movimentacoes"
)

public class MovimentacaoController implements IController<Processo> {
    private final MovimentacaoService servico;
    
    private final MovimentacaoMapper mapper;

    public MovimentacaoController(MovimentacaoService servico, MovimentacaoMapper mapper){
        this.servico = servico;
        this.mapper = mapper;
        
    }


    @GetMapping("/")
    public ResponseEntity<Page<MovimentacaoDto>> get(
        @RequestParam(required = false) String termoBusca,
        @RequestParam(required = false, defaultValue = "false") boolean unpaged,
        @ParameterObject Pageable pageable) {

        if (unpaged) {
            pageable = Pageable.unpaged();
        }

        Page<Movimentacao> registros = servico.buscarMovimentacoesPaginadas(pageable);
        Page<MovimentacaoDto> dtos = registros.map(mapper::toDto);
        return ResponseEntity.ok(dtos);
    }


    @Override
    public ResponseEntity<?> get(Long id) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'get'");
    }


    @Override
    public ResponseEntity<?> insert(Processo objeto) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'insert'");
    }


    @Override
    public ResponseEntity<?> update(Processo objeto) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'update'");
    }


    @Override
    public ResponseEntity<?> delete(Long id) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'delete'");
    }

}
