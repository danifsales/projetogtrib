package sefaz.gtribapi.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface IService<T> {
    // Método paginado
    Page<T> get(String termoBusca,Pageable pageable);

    // Métodos existentes
    T get(Long id);
    T save(T objeto);
    void delete(Long id);
}

