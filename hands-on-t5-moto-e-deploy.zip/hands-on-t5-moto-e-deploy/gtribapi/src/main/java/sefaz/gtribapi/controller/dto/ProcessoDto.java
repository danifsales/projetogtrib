package sefaz.gtribapi.controller.dto;

import java.time.LocalDate;
import java.util.List;

import sefaz.gtribapi.model.Setor;

public record ProcessoDto(
    Long id,
    Long numeroProcesso,
    LocalDate dataCapa,
    String situacao,
    String conclusao,
    Long numeroParecer,
    Long numeroDespacho,
    String interessadoNome,
    String interessadoCpfCnpj,
    String assuntoSigla,
    String assuntoNome,
    String responsavel,
    Long responsavelId,
    String auditor,
    Long auditorId,
    Long acessorId,
    String dificuldade,
    List<MovimentacaoDto> movimentacoes, // Adicionando a lista de movimentações
    Setor setorDestino,
    String palavrasChave,
    String observacoes
) {}
