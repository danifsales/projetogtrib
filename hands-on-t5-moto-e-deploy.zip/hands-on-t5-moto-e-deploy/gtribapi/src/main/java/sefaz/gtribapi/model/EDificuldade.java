package sefaz.gtribapi.model;

public enum EDificuldade {
    FACIL,
    NORMAL,
    DIFICIL,
    MUITO_DIFICIL
}
