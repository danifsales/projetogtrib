package sefaz.gtribapi.model;

public enum ESituacao {
    A_DISTRIBUIR,
    A_FAZER,
    EM_PROGRESSO,
    DILIGENCIA,
    CONCLUIDO,
    A_FINALIZAR;
}
