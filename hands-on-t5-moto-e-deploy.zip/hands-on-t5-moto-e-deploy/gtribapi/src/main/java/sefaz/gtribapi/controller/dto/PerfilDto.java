package sefaz.gtribapi.controller.dto;
import java.util.List;

public record PerfilDto (
    Long id,
    String nome,
    List<PermissaoDto> permissoes

){}


