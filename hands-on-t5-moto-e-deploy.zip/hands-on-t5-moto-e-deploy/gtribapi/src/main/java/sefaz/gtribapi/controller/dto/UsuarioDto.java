package sefaz.gtribapi.controller.dto;

public record UsuarioDto(
    Long id,
    String nomeCompleto,
    String login,
    String perfil
){}
    


