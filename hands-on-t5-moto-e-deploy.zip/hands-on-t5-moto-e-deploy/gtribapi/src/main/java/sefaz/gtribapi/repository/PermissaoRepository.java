// package sefaz.gtribapi.repository;

// import org.springframework.data.domain.Page;
// import org.springframework.data.domain.Pageable;
// import org.springframework.data.jpa.repository.JpaRepository;
// import org.springframework.data.jpa.repository.Query;
// import org.springframework.stereotype.Repository;

// import sefaz.gtribapi.model.Permissao;

// @Repository
// public interface PermissaoRepository extends JpaRepository<Permissao,Long>{
//     @Query("SELECT p FROM Permissao p WHERE p.descricao LIKE %?1%")
//     Page<Permissao> busca(String termo, Pageable page);
// }

