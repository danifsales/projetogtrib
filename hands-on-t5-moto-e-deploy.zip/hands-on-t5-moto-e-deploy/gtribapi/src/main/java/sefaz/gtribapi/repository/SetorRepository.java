package sefaz.gtribapi.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import sefaz.gtribapi.model.Setor;

public interface SetorRepository extends JpaRepository<Setor, Long>{
    @Query("SELECT s FROM Setor s WHERE s.nome LIKE %?1%")
    Page<Setor> findByNome(String nome, Pageable page);

    @Query("SELECT s FROM Setor s WHERE s.codigo = ?1")
    Page<Setor> findByCodigo(Long codigo, Pageable page);

    @Query("SELECT s FROM Setor s WHERE s.ativo = true")
    Page<Setor> findByAtivoTrue(Pageable pageable);
}
