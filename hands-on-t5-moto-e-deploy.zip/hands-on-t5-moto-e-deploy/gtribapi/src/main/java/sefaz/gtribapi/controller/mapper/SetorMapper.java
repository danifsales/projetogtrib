package sefaz.gtribapi.controller.mapper;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import sefaz.gtribapi.controller.dto.SetorDto;
import sefaz.gtribapi.model.Setor;

@Mapper(componentModel = "spring")
public interface SetorMapper {
    
    SetorDto toDto(Setor setor);

    @InheritInverseConfiguration
    Setor toEntity(SetorDto dto);
}
