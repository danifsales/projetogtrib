package sefaz.gtribapi.controller.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import sefaz.gtribapi.controller.dto.MovimentacaoDto;
import sefaz.gtribapi.model.Movimentacao;

@Mapper(componentModel = "spring")
public interface MovimentacaoMapper {

    @Mapping(target = "id", source = "id")
    @Mapping(target = "data", source = "data")
    @Mapping(target = "movimentacao", source = "movimentacao")
    @Mapping(target = "usuarioNome", source = "usuario.nomeCompleto")
    @Mapping(target = "usuarioId", source = "usuario.id")
    @Mapping(target = "designadoNome", source = "designado.nomeCompleto", defaultValue = "")
    @Mapping(target = "idSetorDestino", source = "idSetorDestino")
    @Mapping(target = "processo", source = "processo.numeroProcesso")
    @Mapping(target = "setorNome", source = "idSetorDestino.nome")
    MovimentacaoDto toDto(Movimentacao movimentacao);
}
