package sefaz.gtribapi.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import sefaz.gtribapi.model.Movimentacao;
import sefaz.gtribapi.model.Processo;

@Repository
public interface MovimentacaoRepository extends JpaRepository<Movimentacao, Long> {
    
    // @Query(
    //     "SELECT m FROM Movimentacao m WHERE m.* LIKE %?1%" 
    // )
    // Page<Processo> busca(String termoBusca, Pageable page);
}
