package sefaz.gtribapi.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;


import sefaz.gtribapi.model.Assunto;
import sefaz.gtribapi.model.Setor;
import sefaz.gtribapi.repository.AssuntoRespository;


@Service
public class AssuntoService implements IService<Assunto>{
    private final AssuntoRespository repo;

    public AssuntoService(AssuntoRespository repo){
        this.repo = repo;
    }

    @Override
    public Page<Assunto> get(String termoBusca,Pageable pageable) {
        if (termoBusca == null || termoBusca.isBlank()){
            return repo.assuntos(pageable);
        }else{
            return repo.busca(termoBusca, pageable);
        }
       
    }

    @Override
    public Assunto get(Long id) {
        return repo.findById(id).orElse(null);
    }

    @Override
    public Assunto save(Assunto objeto) {
        return repo.save(objeto);
    }

    // Método para ativar um Assunto
    public Assunto ativar(Long id) {
        Assunto assunto = get(id);
        if (assunto != null) {
            assunto.setAtivo(true);
                return repo.save(assunto);
        }
        return null;
    }
    
    // Método para desativar um Assunto
    public Assunto desativar(Long id) {
        Assunto assunto = get(id);
        if (assunto != null) {
            assunto.setAtivo(false);
            return repo.save(assunto);
        }
        return null;
    }

    @Override
    public void delete(Long id) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'delete'");
    }

    public Page<Assunto> getAtivo(Pageable pageable) {
        return repo.findByAtivoTrue(pageable);
    }
}
