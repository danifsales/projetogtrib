package sefaz.gtribapi.controller;

import org.springdoc.core.annotations.ParameterObject;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.tags.Tag;
import sefaz.gtribapi.model.Interessado;
import sefaz.gtribapi.service.InteressadoService;


@RestController
@RequestMapping("/interessados")
@Tag(
    name = "Interessados",
    description = "Endpoints para gerenciar interessados"
)
public class InteressadoController implements IController<Interessado>{
    private final InteressadoService servico;

    public InteressadoController(InteressadoService servico){
        this.servico = servico;
    }

    
    @Override
    @GetMapping("/")
    public ResponseEntity<Page<Interessado>> get(
        @RequestParam(required = false) String termoBusca,
        @RequestParam(required = false, defaultValue = "false") boolean unpaged,
        @ParameterObject Pageable page) {

        if (unpaged){
            page = Pageable.unpaged();
        }
        Page<Interessado> registros = servico.get(termoBusca,page);
        return ResponseEntity.ok(registros);
    }

    @Override
    @GetMapping("/{id}")
    public ResponseEntity<Interessado> get(@PathVariable("id") Long id) {
        Interessado registro = servico.get(id);
        if (registro == null){
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        }
        
        return ResponseEntity.ok(registro);
    }

    @Override
    @PostMapping("/")
    public ResponseEntity<Interessado> insert(@RequestBody Interessado objeto) {
        Interessado registro = servico.save(objeto);
        return ResponseEntity.ok(registro);
    }

    @Override
    public ResponseEntity<?> update(Interessado objeto) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'update'");
    }

    @Override
    public ResponseEntity<?> delete(Long id) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'delete'");
    }
    
}
