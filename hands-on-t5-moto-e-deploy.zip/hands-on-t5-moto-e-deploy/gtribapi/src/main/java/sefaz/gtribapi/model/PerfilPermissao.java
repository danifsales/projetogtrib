// package sefaz.gtribapi.model;

// import java.io.Serializable;
// import jakarta.persistence.Column;
// import jakarta.persistence.Entity;
// import jakarta.persistence.Enumerated;
// import jakarta.persistence.EnumType;
// import jakarta.persistence.GeneratedValue;
// import jakarta.persistence.GenerationType;
// import jakarta.persistence.Id;
// import jakarta.persistence.JoinColumn;
// import jakarta.persistence.ManyToOne;

// @Entity
// public class PerfilPermissao implements Serializable {

//     @Id
//     @GeneratedValue(strategy = GenerationType.IDENTITY)
//     private Long id;

//     @ManyToOne
//     @JoinColumn(name = "perfil_id")
//     private Perfil perfil;

//     @ManyToOne
//     @JoinColumn(name = "permissao_id")
//     private Permissao permissao;

//     @Enumerated(EnumType.STRING)
//     @Column(nullable = false)
//     private ENivelAcesso nivelAcesso;

//     // Getters e Setters
//     public Long getId() {
//         return id;
//     }

//     public void setId(Long id) {
//         this.id = id;
//     }

//     public Perfil getPerfil() {
//         return perfil;
//     }

//     public void setPerfil(Perfil perfil) {
//         this.perfil = perfil;
//     }

//     public Permissao getPermissao() {
//         return permissao;
//     }

//     public void setPermissao(Permissao permissao) {
//         this.permissao = permissao;
//     }

//     public ENivelAcesso getNivelAcesso() {
//         return nivelAcesso;
//     }

//     public void setNivelAcesso(ENivelAcesso nivelAcesso) {
//         this.nivelAcesso = nivelAcesso;
//     }
// }
