package sefaz.gtribapi.model;

public enum EMovimentacao {
    DESIGNACAO("Designação"),
    ABERTURA_PROCESSO("AberturaProcesso"),
    FINALIZACAO_PROCESSO("FinalizacaoProcesso"), // Quando a secretaria conclui o processo
    INICIO_ANALISE("InicioAnalise"),
    DILIGENCIA("Diligência"), // Quando o processo for encaminhado para diligência
    RETORNO_DILIGENCIA("RetornouDaDiligência"),
    FINALIZACAO_ANALISE("FinalizacaoAnalise"), // Quando o auditor redesigna o processo para a secretaria e ela conclui
    CONCLUSAO("ConcluiuProcesso");
    private String descricao;

    EMovimentacao(String descricao) {
        this.descricao = descricao;
    }

    public String getDescricao() {
        return descricao;
    }
}
