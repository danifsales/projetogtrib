// package sefaz.gtribapi.controller;

// import org.springdoc.core.annotations.ParameterObject;
// import org.springframework.data.domain.Pageable;
// import org.springframework.http.HttpStatus;
// import org.springframework.http.ResponseEntity;
// import org.springframework.web.bind.annotation.DeleteMapping;
// import org.springframework.web.bind.annotation.GetMapping;
// import org.springframework.web.bind.annotation.PathVariable;
// import org.springframework.web.bind.annotation.PostMapping;
// import org.springframework.web.bind.annotation.PutMapping;
// import org.springframework.web.bind.annotation.RequestBody;
// import org.springframework.web.bind.annotation.RequestMapping;
// import org.springframework.web.bind.annotation.RequestParam;
// import org.springframework.web.bind.annotation.RestController;

// import org.springframework.data.domain.Page;

// import sefaz.gtribapi.controller.dto.PerfilDto;
// import sefaz.gtribapi.controller.mapper.PerfilMapper;
// import sefaz.gtribapi.model.Perfil;
// import sefaz.gtribapi.service.PerfilService;

// @RestController
// @RequestMapping("/perfil")
// public class PerfilController {
//     private final PerfilService servico;
//     private final PerfilMapper mapper;

//     public PerfilController(PerfilService service, PerfilMapper mapper) {
//         this.servico = service;
//         this.mapper = mapper;
//     }

//     @GetMapping("/")
//     public ResponseEntity<Page<PerfilDto>> get(
//             @RequestParam(required = false) String termoBusca,
//             @RequestParam(required = false, defaultValue = "false") boolean unpaged,
//             @ParameterObject Pageable pageable) {

//         if (unpaged) {
//             pageable = Pageable.unpaged();
//         }

//         Page<Perfil> registros = servico.get(termoBusca, pageable);
//         Page<PerfilDto> dtos = registros.map(mapper::toDto);
//         return ResponseEntity.ok(dtos);
//     }

//     @GetMapping("/{id}")
//     public ResponseEntity<PerfilDto> get(@PathVariable("id") Long id) {
//         Perfil registro = servico.get(id);
//         if (registro == null) {
//             return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
//         }
//         PerfilDto dto = mapper.toDto(registro);
//         return ResponseEntity.ok(dto);
//     }

//     @PostMapping("/")
//     public ResponseEntity<PerfilDto> insert(@RequestBody PerfilDto objeto) {
//         Perfil objetoConvertido = mapper.toEntity(objeto);
//         Perfil registro = servico.save(objetoConvertido);
//         PerfilDto dto = mapper.toDto(registro);
//         return ResponseEntity.status(HttpStatus.CREATED).body(dto);
//     }

//     @PutMapping("/{id}")
//     public ResponseEntity<PerfilDto> update(@PathVariable("id") Long id, @RequestBody PerfilDto objeto) {
//         Perfil perfilAtualizado = mapper.toEntity(objeto); // Converte DTO para entidade

//         Perfil registro = servico.update(id, perfilAtualizado);
//         if (registro == null) {
//             return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
//         }

//         PerfilDto dto = mapper.toDto(registro);
//         return ResponseEntity.ok(dto);
//     }

//     // @DeleteMapping("/{id}")
//     // public ResponseEntity<SetorDto> delete(@PathVariable("id") Long id,
//     // @RequestParam(name = "ativo",required = true)Boolean ativo) {
//     // Setor registro = servico.deletarSetor(id,ativo);
//     // SetorDto dto = mapper.toDto(registro);
//     // return ResponseEntity.ok(dto);
//     // }
// }
