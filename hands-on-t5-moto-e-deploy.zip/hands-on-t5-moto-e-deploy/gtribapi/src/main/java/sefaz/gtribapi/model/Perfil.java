// package sefaz.gtribapi.model;

// import java.io.Serializable;
// import java.util.List;
// import jakarta.persistence.Column;
// import jakarta.persistence.Entity;
// import jakarta.persistence.GeneratedValue;
// import jakarta.persistence.GenerationType;
// import jakarta.persistence.Id;
// import jakarta.persistence.OneToMany;

// @Entity
// public class Perfil implements Serializable {

//     @Id
//     @GeneratedValue(strategy = GenerationType.IDENTITY)
//     private Long id;

//     @Column(nullable = false)
//     private String nome;

//     @OneToMany(mappedBy = "perfil")
//     private List<Usuario> usuarios;

//     @OneToMany(mappedBy = "perfil")
//     private List<PerfilPermissao> perfilPermissoes;

//     // Getters e Setters
//     public Long getId() {
//         return id;
//     }

//     public void setId(Long id) {
//         this.id = id;
//     }

//     public String getNome() {
//         return nome;
//     }

//     public void setNome(String nome) {
//         this.nome = nome;
//     }

//     public List<Usuario> getUsuarios() {
//         return usuarios;
//     }

//     public void setUsuarios(List<Usuario> usuarios) {
//         this.usuarios = usuarios;
//     }

//     public List<PerfilPermissao> getPerfilPermissoes() {
//         return perfilPermissoes;
//     }

//     public void setPerfilPermissoes(List<PerfilPermissao> perfilPermissoes) {
//         this.perfilPermissoes = perfilPermissoes;
//     }
// }
