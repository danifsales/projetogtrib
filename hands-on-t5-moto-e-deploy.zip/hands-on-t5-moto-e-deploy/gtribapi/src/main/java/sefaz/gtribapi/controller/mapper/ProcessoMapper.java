package sefaz.gtribapi.controller.mapper;

import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import sefaz.gtribapi.controller.dto.ProcessoDto;
import sefaz.gtribapi.model.Processo;

@Mapper(componentModel = "spring", uses = MovimentacaoMapper.class)
public interface ProcessoMapper {

    @Mapping(target = "id", source = "processo.id")
    @Mapping(target = "interessadoNome", source = "interessado.nome")
    @Mapping(target = "interessadoCpfCnpj", source = "interessado.cpfCnpj")
    @Mapping(target = "assuntoNome", source = "assunto.descricao")
    @Mapping(target = "assuntoSigla", source = "assunto.sigla")
    @Mapping(target = "numeroParecer", source = "processo.numeroParecer")
    @Mapping(target = "responsavel", source = "responsavel.nomeCompleto")
    @Mapping(target = "responsavelId", source = "responsavel.id")
    @Mapping(target = "auditor", source = "auditor.nomeCompleto")
    @Mapping(target = "auditorId", source = "auditor.id")
    @Mapping(target = "acessorId", source = "acessor.id")
    @Mapping(target = "situacao", source = "processo.situacao")
    @Mapping(target = "movimentacoes", source = "processo.movimentacoes") // Mapear movimentações para o DTO
    ProcessoDto toDto(Processo processo);

    // Caso seja necessário, você também pode definir um método para mapear uma lista de processos
    List<ProcessoDto> toDtoList(List<Processo> processos);
}
