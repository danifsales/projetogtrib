package sefaz.gtribapi.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import sefaz.gtribapi.model.Setor;
import sefaz.gtribapi.repository.SetorRepository;

@Service
public class SetorService implements IService<Setor> {
    private final SetorRepository repo;

    public SetorService(SetorRepository repo) {
        this.repo = repo;
    }

    @Override
    public Page<Setor> get(String termoBusca, Pageable pageable) {
        if (termoBusca == null || termoBusca.isBlank()) {
            return repo.findAll(pageable);
        } else {
            if (isNumeric(termoBusca)) {
                return repo.findByCodigo(Long.parseLong(termoBusca), pageable);
            }
            return repo.findByNome(termoBusca, pageable);
        }
    }

    private boolean isNumeric(String str) {
        try {
            Long.parseLong(str);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    @Override
    public Setor get(Long id) {
        return repo.findById(id).orElse(null);
    }

    @Override
    public Setor save(Setor objeto) {
        // Verificar se o objeto já tem um ID (caso de atualização)
        if (objeto.getId() != null) {
            Setor setorExistente = get(objeto.getId());
            if (setorExistente != null) {
                objeto.setAtivo(objeto.getAtivo()); // Preserva o estado ativo, se necessário
            }
        } else {
            // Definir ID como null para criação de novo registro
            objeto.setId(null);
            objeto.setAtivo(true); // Novo registro sempre ativo
        }

        return repo.save(objeto);
    }

    public Setor update(Long id, Setor objeto) {
        Setor setorExistente = get(id);
        if (setorExistente == null) {
            return null; // Retorna null se o setor não existir
        }
        objeto.setId(id); // Define o ID para garantir a atualização
        return repo.save(objeto);
    }

    public Setor deletarSetor(Long id, Boolean ativo) {
        Setor setor = get(id);
        if (setor != null) {
            setor.setAtivo(ativo);
            return repo.save(setor);
        }
        return null;
    }

    @Override
    public void delete(Long id) {
        Setor setor = get(id);
        if (setor != null) {
            repo.delete(setor);
        }
    }
    public Page<Setor> getAtivo(Pageable pageable) {
        return repo.findByAtivoTrue(pageable);
    }

}

