package sefaz.gtribapi.model;

import java.io.Serializable;
import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

@Entity
@Table(name = "movimentacoes")
public class Movimentacao implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_movimentacoes", nullable = false, unique = true)
    private Long id;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "data", nullable = false)
    private Date data;

    @Enumerated(EnumType.STRING)
    @Column(name = "movimentacao", nullable = false, length = 255)
    private EMovimentacao movimentacao;

    @ManyToOne
    @JoinColumn(name = "id_usuario", nullable = false)
    private Usuario usuario;

    @ManyToOne
    @JoinColumn(name = "id_processo", nullable = false)
    private Processo processo;

    @ManyToOne
    @JoinColumn(name = "id_setor_destino", nullable =  true)
    private Setor idSetorDestino;

    @ManyToOne
    @JoinColumn(name = "id_usuario_designado", nullable = true)
    private Usuario designado;

    // @ManyToOne
    // @JoinColumn(name = "id_parecer")

    @Enumerated(EnumType.STRING)
    @Column(name= "motivo_saida_diligencia", nullable = true)
    private EMotivoDiligencia motivoDiligencia;

    public EMotivoDiligencia getMotivoDiligencia() {
        return motivoDiligencia;
    }

    public void setMotivoDiligencia(EMotivoDiligencia motivoDiligencia) {
        this.motivoDiligencia = motivoDiligencia;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Date getData() {
        return data;
    }

    public void setData(Date data) {
        this.data = data;
    }

    public EMovimentacao getMovimentacao() {
        return movimentacao;
    }

    public void setMovimentacao(EMovimentacao movimentacao) {
        this.movimentacao = movimentacao;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public Processo getProcesso() {
        return processo;
    }

    public void setProcesso(Processo processo) {
        this.processo = processo;
    }

    public Setor getIdSetorDestino() {
        return idSetorDestino;
    }

    public void setIdSetorDestino(Setor idSetorDestino) {
        this.idSetorDestino = idSetorDestino;
    }

    public Usuario getDesignado() {
        return designado;
    }

    public void setDesignado(Usuario designado) {
        this.designado = designado;
    }

    public void setMovimentacao(String string) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'setMovimentacao'");
    }
}
