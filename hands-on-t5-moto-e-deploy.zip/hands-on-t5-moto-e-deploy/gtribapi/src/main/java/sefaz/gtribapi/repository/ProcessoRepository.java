package sefaz.gtribapi.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import sefaz.gtribapi.model.Processo;

@Repository
public interface ProcessoRepository extends JpaRepository<Processo, Long> {
    @Query("""
        SELECT p FROM Processo p 
        JOIN p.interessado i
        WHERE (
            (p.numeroProcesso IS NOT NULL AND CAST(p.numeroProcesso AS string) LIKE %:termoBusca%) OR
            (p.numeroParecer IS NOT NULL AND CAST(p.numeroParecer AS string) LIKE %:termoBusca%) OR
            (i.cpfCnpj IS NOT NULL AND i.cpfCnpj LIKE %:termoBusca%) OR (p.palavrasChave LIKE %:termoBusca%)
        )
    """)
    Page<Processo> buscaPorVariosAtributos(@Param("termoBusca") String termoBusca, Pageable pageable);
}

