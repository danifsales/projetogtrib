// package sefaz.gtribapi.controller.mapper;

// import org.mapstruct.Mapper;
// import org.mapstruct.Mapping;
// import org.mapstruct.factory.Mappers;

// import sefaz.gtribapi.controller.dto.PerfilDto;
// import sefaz.gtribapi.controller.dto.PermissaoDto;
// import sefaz.gtribapi.model.Perfil;
// import sefaz.gtribapi.model.PerfilPermissao;

// @Mapper(componentModel = "spring")
// public interface PerfilMapper {

//     PerfilMapper INSTANCE = Mappers.getMapper(PerfilMapper.class);

//     @Mapping(target="permissoes", source="perfil.perfilPermissoes")
//     PerfilDto toDto(Perfil perfil);

//     // Mapeamento para PermissaoDto
//     default PermissaoDto toPermissaoDto(PerfilPermissao perfilPermissao) {
//         return new PermissaoDto(perfilPermissao.getPermissao().getId(), perfilPermissao.getPermissao().getDescricao(), 
//         perfilPermissao.getPermissao().getTipoCrud(),perfilPermissao.getNivelAcesso().name());
//     };
//     Perfil toEntity(PerfilDto objeto);
// }
