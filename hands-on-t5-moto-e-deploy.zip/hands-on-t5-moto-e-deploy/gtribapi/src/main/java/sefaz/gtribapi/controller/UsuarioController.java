package sefaz.gtribapi.controller;

import org.springdoc.core.annotations.ParameterObject;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import sefaz.gtribapi.controller.mapper.UsuarioMapper;

import sefaz.gtribapi.controller.dto.UsuarioDto;
import sefaz.gtribapi.model.Usuario;
import sefaz.gtribapi.service.UsuarioService;


@RestController
@RequestMapping("/usuarios")
public class UsuarioController implements IController<Usuario> {
    private final UsuarioService service;
    private final UsuarioMapper mapper;

    public UsuarioController(UsuarioService service, UsuarioMapper mapper){
        this.service = service;
        this.mapper = mapper;
    }

    @Override
    @GetMapping("/")
    public ResponseEntity<Page<UsuarioDto>> get(
        @RequestParam(required = false) String termoBusca,
        @RequestParam(required = false, defaultValue = "false") boolean unpaged,
        @ParameterObject Pageable pageable) {

        if (unpaged) {
            pageable = Pageable.unpaged();
        }

        Page<Usuario> registros = service.get(termoBusca, pageable);
        Page<UsuarioDto> dtos = registros.map(mapper::toDto);
        return ResponseEntity.ok(dtos);
    }

    @Override
    @GetMapping("/{id}")
    public ResponseEntity<Usuario> get(@PathVariable Long id) {
        Usuario registro = this.service.getById(id);
        return ResponseEntity.ok(registro);
    }

    @Override
    @PostMapping("/")
    public ResponseEntity<Usuario> insert(@RequestBody Usuario objeto) {
        Usuario registro = service.salvarUsuario(objeto);
        return ResponseEntity.ok(registro);
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> update(@PathVariable("id") Long id, @RequestBody UsuarioDto usuarioDto) {
        // Obter o usuário existente no banco de dados pelo ID
        Usuario usuarioExistente = service.getById(id);
        if (usuarioExistente == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Usuário não encontrado.");
        }
    
        // Atualizar os campos do usuário existente com as informações do DTO
        usuarioExistente.setNomeCompleto(usuarioDto.nomeCompleto());
        usuarioExistente.setLogin(usuarioDto.login());
        
    
        // Salvar as atualizações no banco de dados
        Usuario usuarioAtualizado = service.salvarUsuario(usuarioExistente);
    
        // Retornar o usuário atualizado como DTO na resposta
        return ResponseEntity.ok(mapper.toDto(usuarioAtualizado));
    }

    @Override
    public ResponseEntity<?> delete(Long id) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'delete'");
    }

    @Override
    public ResponseEntity<?> update(Usuario objeto) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'update'");
    }

}
