INSERT INTO assunto (sigla, descricao, ativo) VALUES ('ACESD', 'ACESSO AOS SERVIÇOS ONLINE/DESATIVAÇÃO', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('ACESS', 'ACESSO AOS SERVIÇOS ONLINE', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('ACOEX', 'APRESENTAÇÃO DE COMPROVANTE DE EXPORTAÇÃO', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('ACRIM', 'ALTERAÇÃO DE CREDENCIAL/INTERVIR E PDV''S E ECF''S', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('ALTOU', 'ALTERAÇÕES CADASTRAIS', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('ALTPS', 'ALTERAÇÃO CONTRATUAL DE PREST DE SERVICO', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('ANTPA', 'SOLIC. DE ANTECIPAÇÃO DAS PARC. DE PARCELAMENTO', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('APAF ', 'AUTORIZAÇÃO DE USO DO PROG. APLIC. FISCAL  PAF-ECF', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('APIC ', 'AUTORIZAÇÃO PARA IMPRESSÃO CONJUNTA', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('APIND', 'APURAÇÃO DO ÍNDICE DE PARTICIPAÇÃO DOS MUNICÍPIOS', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('APUIR', 'APURAÇÃO DE IRREGULARIDADES PELA SEFAZ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('AUTCF', 'AUTORIZAÇÃO PARA USO OU CESSAÇÃO DO ECF', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('AUTIN', 'AUTO DE INFRAÇÃO', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('BAIDF', 'BAIXA DE DEBITOS FISCAIS', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('BIPVA', 'BAIXA DE DÉBITOS DE IPVA', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('BSRIE', 'BAIXA DA INSCRIÇÃO ESTADUAL', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('BXPFI', 'BAIXA DE PASSE FISCAL INTERESTADUAL', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('C115 ', 'COMUNIC. DE RESP. P/ ENVIO DE CONV. 115/2003', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('CACEX', 'CANCELAMENTO EXTEMPORANEO DE NFA-E', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('CADPF', 'CADASTRO DE CREDORES - PESSOA FISICA', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('CADPJ', 'CADASTRO DE CREDORES - PESSOA JURIDICA', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('CAIDF', 'AUTORIZAÇÃO PARA CONFECÇÃO DE DOCUMENTOS FISCAIS', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('CCREC', 'CRIAÇÃO DE CÓDIGO DE RECEITA', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('CENIE', 'CENTRALIZAÇÃO DE INSCRIÇÃO ESTADUAL', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('CERDA', 'CERTIDÃO DA DIVIDA ATIVA', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('CERTI', 'CERTIDÃO NEGATIVA', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('CIECF', 'COMUNICAÇÃO DE INTERVENÇÃO EM ECF', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('CLICM', 'CALCULO DE ICMS/ST VEICULO PCD/TAXI', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('CMNUC', 'COMUNICAÇÃO DE NÃO UTILIZAÇÃO DE CRÉDITO FISCAL', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('CNDAE', 'CANCELAMENTO DE DAE-2', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('CNFCE', 'CREDENCIAMENTO PARA EMISSÃO DE NFC-E', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('CNITA', 'IMPUGNAÇÃO DE NOT. DE ICMS E TERMO A. E DEPOSITO', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('COBAD', 'COBRANCA ADMINISTRATIVA', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('COBDI', 'COBRANÇA DE ICMS - DIFAL', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('COBST', 'COBRANÇA  ADMINISTRATIVA ST', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('COEXP', 'COMPROVANTE DE EXPORTAÇÃO', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('COMDB', 'COMPENSAÇÃO DE DÉBITOS - DECRETO 11.077/2022', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('COMDE', 'COMPENSAÇÃO DE DEBITOS', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('COMPF', 'COMPARTILHAMENTO DE POSTO FISCAL', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('COMUN', 'COMUNICADO DE UTILIZAÇÃO DE SÉRIE E SUBSÉRIE', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('CONCM', 'CONCILIAÇÃO MANUAL GIA-ST X GNRE', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('CONIF', 'CONVALIDAÇÃO DE INCENTIVO FISCAL', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('COPIA', 'COPIAI', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('COPNF', 'SOLICITAÇÃO DE CÓPIA DE NOTAS FISCAIS', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('CORNE', 'CORREÇÃO DE NOTIFICAÇÃO ESPECIAL', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('COTEC', 'CONSULTA', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('CRCTE', 'CREDENCIAMENTO PARA EMISSÃO DE CT-E', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('CREFI', 'SOLICITAÇÃO CRÉDITOS FISCAIS', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('CREIS', 'CREDENCIAL PARA IMPRESSÃO E SELAGEM', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('CRIMR', 'CREDENCIAL P/ INTERVIR EM PDV''S E ECF', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('CSCNC', 'CREDENCIAMENTO DO DIST. COMB. OU TRR NO SCANC     ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('CSDAM', 'RETIFICAÇÃO DO DAM                                ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('CSN  ', 'CONSULTA AO SIMPLES NACIONAL                      ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('CTDAC', 'CANCELAMENTO DE TERMO DE ACORDO                   ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('CTRC ', 'AUTORIZAÇÃO DE CONH. DE TRANSP RODOVIARIO DE CARGA', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('DAME ', 'RETIFICAÇÃO - DAME                                ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('DEBDA', 'REVISÃO DE DEBITO INSCRITO EM DA                  ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('DECIM', 'DECLARAÇÃO DE INTERNAMENTO DE NOTAS FISCAIS       ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('DECL ', 'DECLARAÇÃO DE DESOBRIG.  DE INSCRIÇÃO ESTADUAL    ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('DECLA', 'DECLARAÇÃO                                        ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('DECTX', 'ISENÇÃO DE ICMS P/ TAXI                           ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('DEESP', 'DENÚNCIA ESPONTÂNEA                               ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('DEIRR', 'DENÚNCIA DE IRREGULARIDADE ADMINISTRATIVA         ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('DENUN', 'DENÚNCIA                                          ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('DESLA', 'DESLACRE                                          ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('DEVPG', 'DEVOLUÇÃO DE VALORES PAGOS NÃO TRIBUTARIOS        ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('DILIG', 'DILIGÊNCIA FISCAL                                 ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('DIPRA', 'PRORROGAÇÃO DE PRAZO                              ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('DIPVA', 'DESVINCULAÇÃO DE DÉBITO DE IPVA                   ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('DLFUN', 'DESLACRE FORA DA UNIDADE FISCAL                   ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('DLPRZ', 'DILAÇÃO DE PRAZO                                  ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('DNF-E', 'DESCREDENCIAMENTO DA NF-E/NFC-E                   ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('EBNTF', 'COMUNICADO DE EXTRAVIO DE DOCUMENTOS FISCAIS      ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('ECF  ', 'CONSULTA TÉC. REL AO ECF/AUTOMAÇÃO COMERCIAL      ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('EFD  ', 'CREDENCIAMENTO DE ESCRITURAÇÃO FISCAL DIGITAL     ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('ENCTA', 'ENCONTRO DE CONTAS                                ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('ENSN ', 'REENQUADRAMENTO NO SIMPLES NACIONAL               ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('ESTOR', 'ESTORNO                                           ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('EXCSN', 'EXCLUSÃO DO SIMPLES NACIONAL                      ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('EXTIN', 'EXTINÇÃO - LEI 1.807/2007                         ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('FISCA', 'VERIFICAÇÃO FISCAL - AUDITORIA                    ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('FUSIN', 'FUSÃO E INCORPORAÇÃO                              ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('ICPCD', 'ISENÇÃO ICMS P/ PESSOA COM DEFICIÊNCIA            ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('IICMS', 'ISENÇÃO DE ICMS                                   ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('IIMT ', 'ISENÇÃO DE ICMS PARA MOTOTAXI                     ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('IIPVA', 'ISENÇÃO DE IPVA                                   ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('IISN ', 'IMPUGNAÇÃO AO INDEFERIMENTO DO SIMPLES NACIONAL   ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('IMDSN', 'IMPUGNAÇÃO DE DESENQUADRAMENTO DO SIMPLES NACIONAL', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('IMIPM', 'IMPUGNAÇÃO DO IPM                                ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('IMPGC', 'IMPUGNAÇÃO DA COBRANÇA ADMINISTRATIVA             ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('IMPO ', 'IMPORTAÇÕES                                       ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('INCDF', 'INCINERAÇÃO DE DOCUMENTOS FISCAIS                 ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('INCFI', 'INCENTIVOS FISCAIS                                ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('INSAC', 'INSCRIÇÃO ESTADUAL P/ ASSOC. E COOP               ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('INSET', 'INSCRIÇÃO ESTADUAL                                ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('INSN ', 'IMPUGNAÇÃO DA EXCLUSÃO DO SIMPLES NACIONAL        ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('INSPR', 'INSCRIÇÃO ESTADUAL DE PRODUTOR RURAL              ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('IPPCD', 'ISENÇÃO IPVA P/ PESSOAS COM DEFICIÊNCIA           ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('IPVAC', 'CANCELAMENTO DE DEBITO DE IPVA                    ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('ISENÇ', 'ISENÇÃO DE IPVA PARA TÁXI OU MOTO-TÁXI            ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('ITCMD', 'IMPOSTO SOBRE A TRANSMISSÃO CAUSA MORTIS E DOAÇÃO ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('ITRIB', 'IMUNIDADE TRIBUTARIA                              ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('LC302', 'CONVALIDAÇÃO DA LEI COMPLEMENTAR N° 302/2015      ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('LCTE ', 'LANÇAMENTO EXTEMP. DE CONHECIMENTO DE TRANSPORTE  ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('LEVFI', 'LEVANTAMENTO FISCAL                               ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('LEXNF', 'LANCAMENTO EXTEMPORANEO DE NF                     ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('LGPAS', 'PROPOSTA DE AJUSTE SINIEF                         ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('LGPCI', 'PROPOSTA DE CONVÊNIO ICMS                         ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('LGPDC', 'PROPOSTA DE DECRETO                               ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('LGPIN', 'PROPOSTA DE INSTRUÇÃO NORMATIVA                   ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('LGPLC', 'PROPOSTA DE LEI COMPLEMENTAR                      ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('LGPLO', 'PROPOSTA DE LEI ORDINÁRIA                         ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('LGPPI', 'PROPOSTA DE PROTOCOLO ICMS                        ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('LGPPO', 'PROPOSTA DE PORTARIA                              ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('LIND ', 'REGISTRO DE LIVROS INDEVIDOS                      ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('LIPVA', 'LANÇAMENTO DE IPVA                                ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('MONIT', 'MONITORAMENTO FISCAL                              ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('NFAE ', 'NOTA FISCAL AVULSA ELETRÔNICA                     ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('NF-E ', 'CREDENCIAMENTO PARA EMISSÃO DE NF-E               ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('NTSTN', 'NOTA TÉCNICA - STN                                ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('OUTRO', 'OUTROS - PROCURADORIA FISCAL                      ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('PACT ', 'PROPOSTA DE ACORDO DE COOPERAÇÃO TECNICA          ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('PARCD', 'PARCELAMENTO DE DEBITO                            ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('PCSOF', 'PROVA DE CONCEITO DE SOFTWARE                     ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('PDINF', 'PEDIDO DE INFORMAÇÃO                              ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('PEDEQ', 'PEDIDO DE ENQUADRAMENTO                           ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('PEDUS', 'PEDIDO DE USO/CESSAÇÃO  DO SIST. ELETR. DE DADOS  ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('PEFSE', 'PEDIDO DE FORMULARIO DE SEGURANCA - PAFS          ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('PMPF ', 'LEVANTAMENTO DE PMPF                              ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('PPEF ', 'PROPOSTA DE PROGRAMA DE EDUCAÇÃO FISCAL           ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('PRAPF', 'PROCESSO ADMINISTRATIVO (PROCURADORIA FISCAL)     ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('PRCSF', 'PRESTAÇÃO DE CONTA DE SUPRIMENTO DE FUNDO         ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('PRDEC', 'PRESCRIÇÃO E DECADENCIA                           ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('PROR ', 'PRORROGAÇÃO DE PRAZO - ALAGAÇÃO                   ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('PSCNE', 'PROCESSO SUMÁRIO DE COR. DA NOTIFICAÇÃO ESPECIAL  ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('PSCNP', 'PROCESSO SUMÁRIO DA NOTIFICAÇÃO PENDENTE          ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('PSTAD', 'PROCESSO SUMARIO DE ALTERAÇÃO DE TAD              ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('PVFUF', 'PEDIDO VERIFICAÇÃO FISCAL DE OUTRA UF             ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('RBCIV', 'REVISÃO DA BASE DE CALCULO DE ICMS  VEICULOS AUT  ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('RCDE ', 'RECEBIMENTO DE DOCUMENTOS ELETRONICOS             ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('RCRDG', 'RENOVAÇÃO DE CREDENCIAMENTO DE GRAFICA            ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('REATI', 'REATIVAÇÃO DA INSCRIÇÃO ESTADUAL                  ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('REDAM', 'RECOLHIMENTO POR DAM                              ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('REGEX', 'REGISTRO EXTEMPORANEO DE NOTA FISCAL              ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('REGIS', 'REGISTRO DE PASSAGEM NO POSTO                     ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('RELAT', 'SOLICITAÇÃO DE RELATÓRIOS                         ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('REMET', 'RELATORIO DE ESTABELECIMENTO DA META              ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('REREC', 'ESTIMATIVA DE RENUNCIA DE RECEITA                 ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('RESSA', 'RESSARCIMENTO                                     ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('RESTI', 'RESTITUIÇÃO DE ICMS                               ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('RETEF', 'RETIFICAÇÃO DE ESCRITURAÇÃO FISCAL', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('RETSC', 'RETIFICAÇÃO - SCANC', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('REVBC', 'REVISÃO DA BASE DE CALCULO DE IPVA', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('REVBI', 'REVISÃO DA BASE DE CÁLCULO DO ICMS', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('REXL', 'REGISTRO EXTEMPORÂNEO DE LIVROS FISCAIS', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('RICMS', 'RESSARCIMENTO DE ICMS', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('RIPVA', 'RESTITUIÇÃO DE IPVA', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('RRDJU', 'RETIRADA DE RESTRIÇÃO DE IPVA(DECISÃO JUDICIAL)', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('RRELA', 'REQUERIMENTO DE RELATÓRIO DE NF', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('RRTFB', 'RETIRADA DE RESTRIÇÃO DE FROTA BAIXADA/DESATIVADA', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('RRTPI', 'RETIRA DE RESTRIÇÃO DE IPVA POR IMUNIDAE', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('RSAIE', 'ALTERAÇÕES CADASTRAIS I E - REDESIM', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('RSBIE', 'BAIXA INSCRIÇÃO ESTADUAL - REDESIM', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('RSIE', 'INSCRIÇÃO ESTADUAL - REDESIM', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('RSREA', 'REATIVAÇÃO DE I. E. - REDESIM', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('RSSUI', 'SUSPENSÃO DA INSCRIÇÃO ESTADUAL REDESIM', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('RSTDJ', 'RESTRIÇAÕ INDIVIDUALIZADA (DECISÃO JUDICIAL)', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('RSTFB', 'RESTRIÇÃO DE FROTA BAIXADA/DESATIVADA', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('RSTPI', 'RESTRIÇÃO DE IPVA DE IMUNIDADE', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('SCANC', 'RETIFICAÇÃO/ENTREGA DO SCANC', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('SCNOT', 'SOLICITAÇÃO DE CÓPIA DE NOTIFICAÇÃO', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('SIDCA', 'SINDICANCIA', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('SIOOE', 'SOLICITAÇÃO DE INFORMAÇÃO - OUTROS ÓRG E ENTIDADES', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('SOCPR', 'SOLICITAÇÃO DE CÓPIA DE PROCESSO', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('SOLLA', 'SOLICITAÇÃO DE LACRES', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('SOLMP', 'SOLICITAÇÃO DE INFORMAÇÕES PELO MINISTÉRIO PÚBLICO', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('SOLOJ', 'SOLICITAÇÃO DE INFORMAÇÕES PELO ÓRGÃO JUDICIAL', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('SOXML', 'SOLICITAÇÃO DE XML DE DF-E', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('SPED', 'ENTREGA DE SPED EM ATRASO', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('SRCTR', 'SOLICITAÇÃO DE REDIMENSIONAMENTO DE CARGA TRIBUTÁR', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('SREGE', 'SOLICITAÇÃO DE REGIME ESPECIAL', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('SUFRA', 'NOTAS PENDENTES DE BATIMENTO - SUFRAMA', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('SUPDB', 'SUSPENSÃO DE DEBITOS FISCAIS', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('SUSPI', 'SUSPENSÃO DA INSCRIÇÃO ESTADUAL', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('SVNES', '2º VIA DE NOTIFICAÇÃO ESPECIAL', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('TAXAS', 'RESTITUIÇAO DE TAXAS', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('TCONT', 'TERMO ADITIVO DE CONTRATO', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('TCRED', 'TRANSFERÊNCIA DE CREDITOS FISCAIS', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('TPFIP', 'TRANSFERÊNCIA DE PAGAMENTO DE IPVA', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('TRANS', 'SOLICITAÇÃO DE TRANSF. DE NF-E PARA OUTRO CNPJ', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('TSITA', 'TRANSFERÊNCIA PARA O SITAD', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('UCP', 'UCP - PROFISCO-II/AC - BID', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('UNPNE', 'UNIFICAÇÃO DE PARCELAS DA NOTIFICAÇÃO ESPECIAL', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('VEFIS', 'VERIFICAÇÃO FISCAL', true);
INSERT INTO assunto (sigla, descricao, ativo) VALUES ('VERFI', 'VERIFICAÇÃO FISCAL/PERECIMENTO DE MERCADORIAS     ',true);

INSERT INTO interessado (nome, cpf_cnpj) VALUES ('Empresa Alpha Ltda', '12345678000190');
INSERT INTO interessado (nome, cpf_cnpj) VALUES ('Beta Serviços S/A', '23456789000101');
INSERT INTO interessado (nome, cpf_cnpj) VALUES ('Gamma Consultoria EIRELI', '34567890000112');
INSERT INTO interessado (nome, cpf_cnpj) VALUES ('Delta Comércio de Produtos Ltda', '45678901000123');
INSERT INTO interessado (nome, cpf_cnpj) VALUES ('Epsilon Tecnologia S/A', '56789012000134');


INSERT INTO setor (codigo, nome, ativo) VALUES (1, 'POSTO FISCAL TUCANDEIRA', false);
INSERT INTO setor (codigo, nome, ativo) VALUES (2, 'POSTO FISCAL DOS CORREIOS (RBR)', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (3, 'POSTO FISCAL DA RODOVIARIA (RBR)', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (4, 'POSTO FISCAL AEROP. INTERNACIONAL (RBR)', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (5, 'POSTO FISCAL DO PORTO (RBR)', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (6, 'ATENDIMENTO (CZS)', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (7, 'SEFAZ/TUCANDEIRA', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (8, 'AGÊNCIA DE CRUZEIRO DO SUL', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (9, 'DIV. CONTROLE DAS OBRIG. ACESSÓRIAS', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (10, 'ATENDIMENTO (RBR)', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (11, 'CONTADORIA GERAL DO ESTADO - DICONGE', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (12, 'DIVISÃO DE ARRECADAÇÃO E COBRANÇA - DIAC', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (13, 'COORD. FINANCEIRA', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (14, 'DEPTO ASSESSORAMENTO TRIBUTÁRIO - DEAT', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (15, 'ADMINISTRAÇÃO', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (16, 'DIVISÃO DE ASSESSORIA TÉCNICA - DIASTE', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (17, 'DIRETORIA DE ADMINISTRAÇÃO TRIBUTÁRIA', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (18, 'DIVISÃO DE SUBSTITUIÇÃO TRIBUTÁRIA', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (19, 'UCE', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (20, 'DIVISÃO DE PESSOAS - DGI', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (21, 'GABINETE DO SECRETARIO (A) - GABIN', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (22, 'COPLAN', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (23, 'COORDENAÇÃO DE PATRIMONIO E MATERIAL', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (24, 'AUDIF', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (25, 'PROCURADORIA FISCAL', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (26, 'DIRETORIA DO TESOURO ESTADUAL - DTE', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (27, 'POSTO FISCAL DO DETRAN (IPVA)', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (28, 'UEE', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (29, 'DEPOSITO_ATENDIMENTO', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (30, 'CENTRO DE PROCESSAMENTO DE DADOS - CPD', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (31, 'ATENDIMENTO PREVIO (RBR)', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (32, 'DIVISÃO DE PLAN. DA AÇÃO FISCAL - DIPAF', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (33, 'DEPARTAMENTO DE TECNOLOGIA DA INFORMAÇÃO', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (34, 'DEPOSITO - PARCELAMENTO (CZS)', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (35, 'DIAC - PARCELAMENTOS/ACOMPANHAMENTO', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (36, 'DIAC - COBRANÇA ADMINISTRATIVA', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (37, 'DIAC - SIMPLES NACIONAL', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (44, 'CAORT', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (45, 'GERÊNCIA DE TRIBUTAÇÃO - GETRI', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (47, 'DEPARTAMENTO DE GESTÃO DA AÇÃO FISCAL', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (48, 'DIVISÃO DE CLASSIFICAÇÃO DE LANÇAMENTO', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (49, 'CORFI/SEFAZ (LANCMTO) EXT.', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (50, 'AGÊNCIA DE RIO BRANCO', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (51, 'GERENCIA POSTOS FISCAIS (CZS)', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (52, 'AGENCIA DE MÂNCIO LIMA', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (58, 'POSTO FISCAL DA CORRENTE (RBR)', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (60, 'AGÊNCIA DE TARAUACA', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (62, 'AGÊNCIA DE SENA MADUREIRA/OUTROS DOC', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (63, 'AGÊNCIA DE SENA MADUREIRA', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (64, 'AGÊNCIA DE PLACIDO DE CASTRO', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (65, 'POSTO FISCAL PICA-PAU', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (66, 'AGÊNCIA DE BRASILEIA', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (67, 'AGÊNCIA DE BRASILEIA/OUTROS DOC', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (68, 'AGÊNCIA DE FEIJÓ', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (70, 'AGÊNCIA DE XAPURI', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (72, 'TESTE - TARAUACA', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (73, 'UNIDADE DE TESTE', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (74, 'AGÊNCIA DE SENADOR GUIOMARD', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (75, 'ARQUIVO', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (76, 'DIVISÃO DE ADM. DE PROCESSOS TRIBUTÁRIOS', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (77, 'CONSELHO DE CONTRIBUINTES DO ESTADO DO ACRE', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (78, 'AGÊNCIA DE ASSIS BRASIL', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (79, 'POSTO FISCAL DE EPITACIOLÂNDIA', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (80, 'DEPÓSITO - PROCURADORIA FISCAL', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (81, 'DEPÓSITO - AUTO DE INFRAÇÃO', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (82, 'POSTO FISCAL DO AEROPORTO (CZS)', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (83, 'POSTO FISCAL DOS CORREIOS (CZS)', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (84, 'POSTO FISCAL STA TEREZINHA (CZS)', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (85, 'POSTO FISCAL DO PORTO (CZS)', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (86, 'POSTO FISCAL DO DERACRE (SM)', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (87, 'ARQUIVO (CRUZEIRO DO SUL)', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (88, 'FISCALIZAÇÃO VOLANTE', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (89, 'GERENCIA DE INTELIGÊNCIA FISCAL - GIF', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (90, 'DIVISÃO DE AÇÃO FISC. EM ESTABELECIMENTO', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (91, 'DIVISÃO DE FISC. DE MERC. EM TRÂNSITO', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (92, 'DIVISÃO DE ADMINISTRAÇAO DO SIAT', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (93, 'DEPARTAMENTO DE GESTÃO TRIBUTÁRIA', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (94, 'DIVISÃO DE ESTUDOS ECONÔMICOS FISCAIS', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (95, 'DEPARTAMENTO DE PLANEJAMENTO ESTRATÉGICO', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (96, 'CENTRAL DE ATENDIMENTO ÀS TRANSPORTADORA', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (97, 'SEFAZ - OCA', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (98, 'SECRETARIA ADJUNTA DA RECEITA ESTADUAL', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (99, 'POSTO DE ATENDIMENTO JUNTA COMERCIAL', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (101, 'POSTO ITCMD', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (102, 'DIVISÃO DE PROJETOS', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (103, 'DEPARTAMENTO DE ASSESSORIA TÉCNICA', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (104, 'DIVISÃO DO SIMPLES NACIONAL', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (105, 'DICOA', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (106, 'NÚCLEO DE COMÉRCIO EXTERIOR - NUCEX', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (107, 'MONITORAMENTO ELETRÔNICO', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (108, 'DIVISÃO DE INTELIGÊNCIA FISCAL - DINFISC', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (109, 'DEPARTAMENTO DE GOVERNANÇA ESTRATÉGICA', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (110, 'DIVISÃO DE PLANEJAMENTO ESTRATÉGICO TRIB', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (111, 'DIVISÃO DE GESTÃO DA ESCOLA FAZENDÁRIA', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (112, 'GESTÃO DO CAPITAL INTELECTUAL', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (113, 'DIVISÃO DE GESTÃO DO CONHECIMENTO E ESTUDOS', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (114, 'ASSESSORIA TÉCNICA TRIBUTÁRIA - ASTECT', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (115, 'DIVISÃO DE SISTEMAS TRIBUTÁRIOS INFORMATIZADOS', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (116, 'NÚCLEO DE ASSESSORIA TÉCNICA', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (117, 'DIVISÃO DE INFORMAÇÕES TRIBUTÁRIAS', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (118, 'NÚCLEO DE ITCMD/IPVA/TAXAS', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (119, 'NÚCLEO DE CADASTRO E OBRIGAÇÕES ACESSÓRIAS', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (120, 'NÚCLEO DE OPERAÇÕES ESPECIAIS - NUOP', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (122, 'DIVISÃO DE FISCALIZAÇÃO - DIFISC', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (123, 'NÚCLEO DE AUDITORIA - NUCAU', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (124, 'NÚCLEO DE SUBSTITUIÇÃO TRIBUTÁRIA - NUST', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (125, 'NÚCLEOS sETORIAIS DE FISCALIZAÇÃO', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (126, 'NÚCLEOS sETORIAIS DE FISC NOS MUNICÍPIOS', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (127, 'DIVISÃO DE TRIBUTAÇÃO - DITRIB', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (129, 'DIVISÃO DE MERCADORIAS EM TRÂNSITO - DIM', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (130, 'NUSEFI DE ACRELÂNDIA (TUCANDEIRA)', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (131, 'NUSEFI DE RIO BRANCO (CAT)', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (132, 'NUSEFI DE PLÁCIDO DE CASTRO (PICA-PAU)', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (133, 'NUSEFI REGIONAL DO JURUÁ', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (134, 'NUSEFI DOS CORREIOS', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (135, 'NUSEFI AEROPORTO', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (136, 'DIVISÃO REGIONAL DA FAZENDA ESTADUAL - DRFE', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (137, 'NURFE DE XAPURI', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (138, 'NURFE DE TARAUACÁ', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (139, 'NURFE DE SENADOR GUIOMARD', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (140, 'NURFE DE FEIJÓ', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (141, 'NURFE DE SENA MADUREIRA', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (142, 'NURFE DE BRASILEIA/EPITACIOLÂNDIA', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (143, 'NURFE DE PLÁCIDO DE CASTRO', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (144, 'NURFE DE CRUZEIRO DO SUL', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (145, 'NURFE DE RIO BRANCO', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (146, 'NÚCLEO DE CLASSIFICAÇÃO E LANÇAMENTO - NCL', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (147, 'NÚCLEO DE PROCESSOS TRIBUTÁRIOS - NUPROC', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (148, 'UNIDADE DE COORDENAÇÃO DA UNIDADE DE COO', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (149, 'COMISSÃO PERMANENTE DE SINDICÂNCIA - PAD', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (150, 'NUSEFI VOLANTE', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (151, 'NUSEFI DE SENADOR GUIOMARD (PICA-PAU)', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (152, 'DIVISÃO DE ITCMD/IPVA/TAXAS - DITCMD', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (153, 'NÚCLEO ESPECIALIZADO sETORIAL DE COMBUSTÍVEIS', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (154, 'NÚCLEO ESPECIALIZADO DE FISCALIZAÇÃO DE COMBUSTÍVEIS', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (155, 'NÚCLEO DE ENERGIA ELÉTRICA E COMUNICAÇÕES', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (156, 'NÚCLEO DO AGRONEGÓCIO - NAGRO', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (157, 'NÚCLEO DO SIMPLES NACIONAL - NUSN', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (158, 'NUSEFI DE BRASILEIA/EPITACIOLÂNDIA', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (159, 'NUSEFI DE FEIJÓ/TARAUACÁ', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (160, 'NUSEFI CENTRAL DE ATENDIMENTO ÀS TRANSPORTADORAS', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (161, 'NURFE REGIONAL DO JURUÁ', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (162, 'NÚCLEO DE RELAÇÕES FEDERATIVAS FISCAIS', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (163, 'NURFE DE ACRELÂNDIA', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (164, 'DIVISÃO DE LEGISLAÇÃO TRIBUTÁRIA - DILET', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (165, 'NURFE DE XAPURI - ARQUIVO', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (166, 'NURFE DE TARAUACÁ - ARQUIVO', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (167, 'NURFE DE FEIJÓ - ARQUIVO', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (168, 'NURFE DE PLÁCIDO DE CASTRO - ARQUIVO', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (169, 'NURFE DE SENA MADUREIRA - ARQUIVO', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (170, 'NURFE DE ACRELÂNDIA - ARQUIVO', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (171, 'NURFE DE ASSIS BRASIL', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (172, 'NURFE DE SENADOR GUIOMARD - ARQUIVO', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (173, 'DEPARTAMENTO DE SISTEMAS TRIBUTÁRIOS INFORMATIZADOS', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (174, 'DIVISÃO DE CONFORMIDADE FISCAL - DICONFI', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (175, 'DIVISÃO DE ESPECIFICAÇÃO TÉCNICA E NEGOCIAÇÃO', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (176, 'UNIDADE VIRTUAL - E-PROCESSO', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (177, 'NURFE DE MANCIO LIMA', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (179, 'DEFISC - DEPARTAMENTO DE FISCALIZAÇÃO', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (180, 'DIVAU - DIVISÃO DE AUDITORIA', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (181, 'DIST - DIVISÃO DE SUBSTITUIÇÃO TRIBUTÁRIA', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (182, 'DICOMB - DIVISÃO DE COMBUSTÍVEIS, BIOCOMBUSTÍVEIS', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (183, 'DITRANS - DIVISÃO DE FISCALIZAÇÃO DE TRANSPORTE', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (184, 'DIEEC - DIVISÃO DE ENERGIA ELÉTRICA E COMUNICAÇÃO', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (185, 'DIAGRO - DIVISÃO DE AGRONEGÓCIO', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (186, 'DISIN - DIVISÃO DO SIMPLES NACIONAL', true);
INSERT INTO setor (codigo, nome, ativo) VALUES (187, 'DICEIFI - DIVISÃO DE COMÉRCIO EXTERIOR E INCENTIVOS', true);


INSERT INTO usuario (nome_completo, login, senha, tipo_usuario) VALUES ('João Silva', 'jsilva', '$2b$12$gAJdSSo7jyI./Zq3w/U7Quazp8o/yl/2avcobE.VUPzoYLwDNFtY.', 'AUDITOR');
INSERT INTO usuario (nome_completo, login, senha, tipo_usuario) VALUES ('Maria Oliveira', 'moliveira', '$2b$12$gAJdSSo7jyI./Zq3w/U7Quazp8o/yl/2avcobE.VUPzoYLwDNFtY.', 'SECRETARIA');
INSERT INTO usuario (nome_completo, login, senha, tipo_usuario) VALUES ('Carlos Pereira', 'cpereira', 'senha123', 'ASSESSOR');
INSERT INTO usuario (nome_completo, login, senha, tipo_usuario) VALUES ('Ana Costa', 'acosta', 'senha123', 'ASSESSOR');
INSERT INTO usuario (nome_completo, login, senha, tipo_usuario) VALUES ('Roberto Souza', 'rsouza', 'senha123', 'AUDITOR');



-- Inserts para a tabela Processo

-- Exemplo corrigido dos inserts com valores válidos para o enum EConclusao
INSERT INTO processo (numero_processo, data_capa, situacao, conclusao, numero_parecer, interessado_id, assunto_id, responsavel_id, auditor_id, setor_destino_id) 
VALUES 
(20245832924, '2024-09-01', 'A_DISTRIBUIR', NULL, NULL, 1, 1, NULL, NULL, NULL),
(20247019634, '2024-09-02', 'A_DISTRIBUIR', 'DEFERIDO', 1001, 2, 2, NULL, NULL, NULL),
(20249517862, '2024-09-03', 'A_DISTRIBUIR', 'DEFERIDO', NULL,  3, 3, null, NULL, NULL),
(20246948275, '2024-09-04', 'A_DISTRIBUIR', NULL, 1002, 4, 4, NULL, NULL, NULL),
(20249372610, '2024-09-05', 'A_DISTRIBUIR', 'INDEFERIDO', NULL, 5, 5, 3, NULL, NULL),
(20249372611, '2024-09-02', 'A_DISTRIBUIR', 'INDEFERIDO', NULL, 5, 5, 3, NULL, NULL),
(20249372612, '2024-09-03', 'A_DISTRIBUIR', 'DEFERIDO', NULL, 5, 5, 3, NULL, NULL),
(20249372613, '2024-09-04', 'A_DISTRIBUIR', 'INDEFERIDO', NULL, 5, 5, 3, NULL, NULL),
(20249372614, '2024-09-05', 'A_DISTRIBUIR', 'DEFERIDO', NULL, 5, 5, 3, NULL, NULL),
(20249372615, '2024-09-06', 'A_DISTRIBUIR', 'INDEFERIDO', NULL, 5, 5, 3, NULL, NULL),
(20249372616, '2024-09-07', 'A_DISTRIBUIR', 'DEFERIDO', NULL, 5, 5, 3, NULL, NULL),
(20249372617, '2024-09-08', 'A_DISTRIBUIR', 'INDEFERIDO', NULL, 5, 5, 3, NULL, NULL),
(20249372618, '2024-09-09', 'A_DISTRIBUIR', 'DEFERIDO', NULL, 5, 5, 3, NULL, NULL),
(20249372619, '2024-09-10', 'A_DISTRIBUIR', 'INDEFERIDO', NULL, 5, 5, 3, NULL, NULL),
(20249372620, '2024-09-11', 'A_DISTRIBUIR', 'DEFERIDO', NULL, 5, 5, 3, NULL, NULL),
(20249372621, '2024-09-12', 'A_DISTRIBUIR', 'INDEFERIDO', NULL, 5, 5, 3, NULL, NULL),
(20249372622, '2024-09-13', 'A_DISTRIBUIR', 'DEFERIDO', NULL, 5, 5, 3, NULL, NULL),
(20249372623, '2024-09-14', 'A_DISTRIBUIR', 'INDEFERIDO', NULL, 5, 5, 3, NULL, NULL),
(20249372624, '2024-09-15', 'A_DISTRIBUIR', 'DEFERIDO', NULL, 5, 5, 3, NULL, NULL),
(20249372625, '2024-09-16', 'A_DISTRIBUIR', 'INDEFERIDO', NULL, 5, 5, 3, NULL, NULL),
(20249372626, '2024-09-17', 'A_DISTRIBUIR', 'DEFERIDO', NULL, 5, 5, 3, NULL, NULL),
(20249372627, '2024-09-18', 'A_DISTRIBUIR', 'INDEFERIDO', NULL, 5, 5, 3, NULL, NULL),
(20249372628, '2024-09-19', 'A_DISTRIBUIR', 'DEFERIDO', NULL, 5, 5, 3, NULL, NULL),
(20249372629, '2024-09-20', 'A_DISTRIBUIR', 'INDEFERIDO', NULL, 5, 5, 3, NULL, NULL),
(20249372630, '2024-09-21', 'A_DISTRIBUIR', 'DEFERIDO', NULL, 5, 5, 3, NULL, NULL),
(20249372631, '2024-09-22', 'A_DISTRIBUIR', 'INDEFERIDO', NULL, 5, 5, 3, NULL, NULL),
(20249372632, '2024-09-23', 'A_DISTRIBUIR', 'DEFERIDO', NULL, 5, 5, 3, NULL, NULL),
(20249372633, '2024-09-24', 'A_DISTRIBUIR', 'INDEFERIDO', NULL, 5, 5, 3, NULL, NULL),
(20249372634, '2024-09-25', 'A_DISTRIBUIR', 'DEFERIDO', NULL, 5, 5, 3, NULL, NULL),
(20249372635, '2024-09-26', 'A_DISTRIBUIR', 'INDEFERIDO', NULL, 5, 5, 3, NULL, NULL),
(20249372636, '2024-09-27', 'A_DISTRIBUIR', 'DEFERIDO', NULL, 5, 5, 3, NULL, NULL),
(20249372637, '2024-09-28', 'A_DISTRIBUIR', 'INDEFERIDO', NULL, 5, 5, 3, NULL, NULL),
(20249372638, '2024-09-29', 'A_DISTRIBUIR', 'DEFERIDO', NULL, 5, 5, 3, NULL, NULL),
(20249372639, '2024-09-30', 'A_DISTRIBUIR', 'INDEFERIDO', NULL, 5, 5, 3, NULL, NULL),
(20249372640, '2024-10-01', 'A_DISTRIBUIR', 'DEFERIDO', NULL, 5, 5, 3, NULL, NULL),
(20249372641, '2024-10-02', 'A_DISTRIBUIR', 'INDEFERIDO', NULL, 5, 5, 3, NULL, NULL),
(20249372642, '2024-10-03', 'A_DISTRIBUIR', 'DEFERIDO', NULL, 5, 5, 3, NULL, NULL),
(20249372643, '2024-10-04', 'A_DISTRIBUIR', 'INDEFERIDO', NULL, 5, 5, 3, NULL, NULL),
(20249372644, '2024-10-05', 'A_DISTRIBUIR', 'DEFERIDO', NULL, 5, 5, 3, NULL, NULL),
(20249372645, '2024-10-06', 'A_DISTRIBUIR', 'INDEFERIDO', NULL, 5, 5, 3, NULL, NULL),
(20249372646, '2024-10-07', 'A_DISTRIBUIR', 'DEFERIDO', NULL, 5, 5, 3, NULL, NULL),
(20249372647, '2024-10-08', 'A_DISTRIBUIR', 'INDEFERIDO', NULL, 5, 5, 3, NULL, NULL),
(20249372648, '2024-10-09', 'A_DISTRIBUIR', 'DEFERIDO', NULL, 5, 5, 3, NULL, NULL),
(20249372649, '2024-10-10', 'A_DISTRIBUIR', 'INDEFERIDO', NULL, 5, 5, 3, NULL, NULL),
(20249372650, '2024-10-11', 'A_DISTRIBUIR', 'DEFERIDO', NULL, 5, 5, 3, NULL, NULL),
(20249372651, '2024-10-12', 'A_DISTRIBUIR', 'INDEFERIDO', NULL, 5, 5, 3, NULL, NULL),
(20249372652, '2024-10-13', 'A_DISTRIBUIR', 'DEFERIDO', NULL, 5, 5, 3, NULL, NULL),
(20249372653, '2024-10-14', 'A_DISTRIBUIR', 'INDEFERIDO', NULL, 5, 5, 3, NULL, NULL),
(20249372654, '2024-10-15', 'A_DISTRIBUIR', 'DEFERIDO', NULL, 5, 5, 3, NULL, NULL),
(20249372655, '2024-10-16', 'A_DISTRIBUIR', 'INDEFERIDO', NULL, 5, 5, 3, NULL, NULL),
(20249372656, '2024-10-17', 'A_DISTRIBUIR', 'DEFERIDO', NULL, 5, 5, 3, NULL, NULL),
(20249372657, '2024-10-18', 'A_DISTRIBUIR', 'INDEFERIDO', NULL, 5, 5, 3, NULL, NULL),
(20249372658, '2024-10-19', 'A_DISTRIBUIR', 'DEFERIDO', NULL, 5, 5, 3, NULL, NULL),
(20249372659, '2024-10-20', 'A_DISTRIBUIR', 'INDEFERIDO', NULL, 5, 5, 3, NULL, NULL);


