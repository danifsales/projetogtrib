export const environment = {
    API_URL: 'https://gtribapi.onrender.com',
    // API_URL: '//localhost:9000',
    AUTH_TYPE: 'jwt'
};
