export const environment = {
    API_URL: '//localhost:9000',
    AUTH_TYPE: 'basic'
};
