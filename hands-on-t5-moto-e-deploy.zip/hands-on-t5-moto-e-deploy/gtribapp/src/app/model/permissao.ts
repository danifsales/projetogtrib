export type Permissao = {
    id: number;
    descricao: string;
    tipoCrud: boolean;
    nivelAcesso: string;
}