export enum EDificuldade {
    FACIL = 'FACIL',
    NORMAL = 'NORMAL',
    DIFICIL = 'DIFICIL',
    MUITO_DIFICIL = 'MUITO_DIFICIL'
  }