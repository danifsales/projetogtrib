export type Interessado = {
    id: number;
    nome: string;
    cpfCnpj: string;
}