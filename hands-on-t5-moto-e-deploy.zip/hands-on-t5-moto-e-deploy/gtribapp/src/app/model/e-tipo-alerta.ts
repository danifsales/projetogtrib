export enum ETipoAlerta {
    ERRO = 'erro',
    SUCESSO = 'sucesso'
}