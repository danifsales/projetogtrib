export type Movimentacao = {
    id: number;
    id_movimentacoes: number;
    data: string;
    movimentacao: string;
    id_usuario: number;
    id_processo: number;
    id_setor_destino: number;
    id_usuario_designado: number;
    id_parecer: number;
    usuarioId: number;
    codigo: number; //criado apenas no front
}