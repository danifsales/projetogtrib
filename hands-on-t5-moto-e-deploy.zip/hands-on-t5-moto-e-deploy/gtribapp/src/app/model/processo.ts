import { Movimentacao } from "./movimentacao";
import { Setor } from "./setor";
import { Usuario } from "./usuario";

export type Processo= {
    id: number;                        
    numeroProcesso: number;           
    dataCapa: string;                  
    situacao: string;                  
    conclusao: string | null;          
    numeroParecer: number | null;      
    numeroDespacho: number | null;     
    interessadoNome: string;           
    interessadoCpfCnpj: string;        
    assuntoSigla: string;              
    assuntoNome: string;               
    responsavel: Usuario;   
    responsavelId: number;             
    auditor: string | null;
    auditorId: number;
    acessorId: number;
    assuntoId: number;
    interessadoId:number; 
    dificuldade: string; //apenas no front
    codDificuldade: number; //apenas no front  
    movimentacoes: Movimentacao[];   //apenas no front        
    setorDestino: Setor;
    palavrasChave: string | null;
    observacoes: string | null;
};



  