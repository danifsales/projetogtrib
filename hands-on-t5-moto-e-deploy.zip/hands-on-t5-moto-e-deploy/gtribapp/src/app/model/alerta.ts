import { ETipoAlerta } from "./e-tipo-alerta"

export type Alerta = {
    tipo: ETipoAlerta;
    mensagem: string;
}