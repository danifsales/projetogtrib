export type Setor = {
    id: number;
    nome: string;
    codigo: string;
    ativo: boolean;
}