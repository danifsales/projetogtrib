export type Perfil_Permissao = {
    id: number;
    id_perfil: number;
    id_permissao: number;
    crud_permissao: string;
}