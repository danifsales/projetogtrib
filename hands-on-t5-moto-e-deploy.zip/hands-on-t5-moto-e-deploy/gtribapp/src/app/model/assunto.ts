export type Assunto = {
    id: number;
    sigla: string;
    descricao: string;
    ativo: boolean;
}