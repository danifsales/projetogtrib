import { Permissao } from "./permissao";

export type Perfil = {
    id: number;
    nome: string;
    permissoes: Permissao[]; 
}