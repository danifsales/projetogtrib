export enum EConclusao {
    DEFERIDO = 'DEFERIDO',
    INDEFERIDO = 'INDEFERIDO'
  }