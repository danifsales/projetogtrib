export type Cadastro = {
    id: number
    
}