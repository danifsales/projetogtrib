export type Analise = {
    id: number;
    conclusao: string;
    dificuldade: string;
    id_responsavel: number;
    id_processo: number;
}