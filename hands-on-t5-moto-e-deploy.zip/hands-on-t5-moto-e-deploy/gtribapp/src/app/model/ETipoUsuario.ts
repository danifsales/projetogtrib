export enum ETipoUsuario{
    SECRETARIA = 'SECRETARIA',
    ASSESSOR = 'ASSESSOR',
    AUDITOR = 'AUDITOR'
}