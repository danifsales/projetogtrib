export type Usuario = {
    id: number;
    nomeCompleto: string;
    login: string;
    senha: string;
    perfil: string;

}