import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'formatProcessNumProcessTable',
  standalone: true
})
export class FormatProcessTablePipe implements PipeTransform {
  //Essa classe foi criada para formatar a disposição do processo na tabela
  //Deve ser mostrado assim o processo 2024/81/89101
  transform(value: string | number): string {
    const stringValue = value.toString();
    if (stringValue.length !== 11) {
      return stringValue;  // Se o valor não tiver o tamanho esperado, retorna como está
    }

    // Formatação: 4 primeiros dígitos / 2 do meio / 5 últimos
    const ano = stringValue.substring(0, 4);      
    const unidade = stringValue.substring(4, 6);  
    const numero = stringValue.substring(6, 11);   

    return `${ano}/${unidade}/${numero}`;
  }

}
