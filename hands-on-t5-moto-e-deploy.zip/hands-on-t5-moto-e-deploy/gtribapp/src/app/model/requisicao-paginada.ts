export class RequisicaoPaginada {
    page: number = 0;
    size: number = 5;
    sort: string[] = [];
}
