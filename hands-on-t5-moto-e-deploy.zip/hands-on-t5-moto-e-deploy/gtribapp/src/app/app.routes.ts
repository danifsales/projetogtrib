import { Routes } from '@angular/router';
import { EntradaComponent } from './component/entrada/entrada.component';
import { CadastroComponent } from './component/cadastro/cadastro.component';
import { NovoProcessoFormComponent } from './component/novo-processo/novo-processo.form/novo-processo.form.component';
import { NovoProcessoListComponent } from './component/novo-processo/novo-processo.list/novo-processo.list.component';
import { ProcessoDetalhesComponent } from './component/processo/processo-detalhes/processo-detalhes.component';
import { ProcessoEditarComponent } from './component/processo/processo-editar/processo-editar.component';
import { NovoUsuarioFormComponent } from './component/novo-usuario/novo-usuario.form/novo-usuario.form.component';
import { NovaUnidadeFormComponent } from './component/nova-unidade/nova-unidade.form/nova-unidade.form.component';
import { NovoMotivoSaidaFormComponent } from './component/novo-motivo-saida/novo-motivo-saida.form/novo-motivo-saida.form.component';
import { NovoNivelDificuldadeFormComponent } from './component/novo-nivel-dificuldade/novo-nivel-dificuldade.form/novo-nivel-dificuldade.form.component';
import { LoginComponent } from './component/login/login.component';
import { PerfisComponent } from './component/perfis/perfis-list/perfis-list.component';
import { PerfisDetalhesComponent } from './component/perfis/perfis-detalhes/perfis-detalhes.component';

import { AssuntosFormComponent } from './component/assuntos/assuntos-form/assuntos-form.component';
import { AssuntosListComponent } from './component/assuntos/assuntos-list/assuntos-list.component';
import { SetorComponent } from './component/setor/setor.component';
import { UsuarioComponent } from './component/usuario/usuario.component';
import { authGuard } from './service/auth.guard';
import { RelatoriosComponent } from './component/relatorios/relatorios.component';

export const routes: Routes = [
    { path: '', canActivate: [authGuard], children: [
        { path:'entrada', component: EntradaComponent },
        { path:'cadastro', component: CadastroComponent },
        { path:'assuntos/form', component: AssuntosFormComponent},
        { path: 'assuntos/list' , component: AssuntosListComponent},
        { path: 'setor' , component: SetorComponent},
        { path:'novo-motivo-saida/form', component: NovoMotivoSaidaFormComponent },
        { path:'novo-nivel-dificuldade/form', component: NovoNivelDificuldadeFormComponent },
        { path:'nova-unidade/form', component: NovaUnidadeFormComponent },
        { path:'novo-usuario/form', component: NovoUsuarioFormComponent },
        { path:'novo-processo/form', component: NovoProcessoFormComponent },
        { path:'novo-processo/list', component: NovoProcessoListComponent },
        { path:'processos/detalhes/:id', component: ProcessoDetalhesComponent },
        { path:'processos/editar/:id', component: ProcessoEditarComponent },
        { path: 'perfil' , component: PerfisComponent},
        { path: 'relatorios' , component: RelatoriosComponent},
        { path:'perfil/detalhes/:id', component: PerfisDetalhesComponent },
        { path: 'setor' , component: SetorComponent},
        { path: 'usuarios' , component: UsuarioComponent},
    ]},
    { path: 'login' , component: LoginComponent},
    { path: '**', redirectTo: '' }
    
];
