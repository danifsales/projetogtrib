import { AbstractControl, ValidationErrors, ValidatorFn } from '@angular/forms';

// Validador para formatar a entrada de números como uma data (dd/mm/yyyy)
export function formatDateValidator(): ValidatorFn {
  return (control: AbstractControl): ValidationErrors | null => {
    const value = control.value;
    if (!value) {
      return null; // Retorna nulo se não houver valor
    }

    // Remove qualquer caractere que não seja número
    const cleaned = value.replace(/\D/g, '');

    // Formata para dd/mm/yyyy
    let formattedValue = cleaned;
    if (cleaned.length >= 2) {
      formattedValue = cleaned.slice(0, 2) + '/' + cleaned.slice(2);
    }
    if (cleaned.length >= 4) {
      formattedValue = formattedValue.slice(0, 5) + '/' + cleaned.slice(4, 8);
    }

    // Atualiza o valor no campo sem quebrar o ciclo de detecção de mudanças
    if (control.value !== formattedValue) {
      control.setValue(formattedValue, { emitEvent: false });
    }

    // Verifica se a data é válida (verificação simples)
    const [day, month, year] = formattedValue.split('/');
    if (cleaned.length === 8 && !isValidDate(parseInt(day), parseInt(month), parseInt(year))) {
      return { invalidDate: true };
    }

    return null;
  };
}

// Função auxiliar para verificar se a data é válida
function isValidDate(day: number, month: number, year: number): boolean {
  const date = new Date(year, month - 1, day);
  return date.getFullYear() === year && date.getMonth() === month - 1 && date.getDate() === day;
}
