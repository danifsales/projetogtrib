import { AbstractControl, ValidationErrors } from '@angular/forms';

export function cpfCnpjValidator(control: AbstractControl): ValidationErrors | null {

  const value = control.value; //replace(/\D/g, ''); // Remove all non-numeric characters

  if (!value) {
    return null; // Se o valor for nulo ou vazio, o validador não precisa fazer nada.
  }

  // Remove caracteres não numéricos (se necessário)
  const cpfCnpj = value.replace(/[^\d]/g, '');

  // Valide CPF ou CNPJ (adicione suas regras de validação aqui)
  if (cpfCnpj.length === 11) {
    // Validação de CPF
    return validateCPF(cpfCnpj) ? null : { cpfCnpjInvalid: true };
  } else if (cpfCnpj.length === 14) {
    // Validação de CNPJ
    return validateCNPJ(cpfCnpj) ? null : { cpfCnpjInvalid: true };
  }

  // Se não for CPF nem CNPJ, retorna erro
  return { cpfCnpjInvalid: true };
}

// Suas funções de validação para CPF e CNPJ
function validateCPF(cpf: string): boolean {
  // Lógica de validação de CPF
  return true; // ou false dependendo da validação
}

function validateCNPJ(cnpj: string): boolean {
  // Lógica de validação de CNPJ
  return true; // ou false dependendo da validação
}