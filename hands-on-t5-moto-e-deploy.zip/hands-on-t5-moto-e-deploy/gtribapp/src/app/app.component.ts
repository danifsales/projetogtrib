import { Component, Inject, OnInit } from '@angular/core';
import { NavigationEnd, Router, RouterLink, RouterOutlet } from '@angular/router';
import { SearchBarComponent } from './component/search-bar/search-bar.component';
import { NotificationIconComponent } from './component/notification-icon/notification-icon.component';
import { NavbarUserComponent } from './component/navbar-user/navbar-user.component';
import { CommonModule } from '@angular/common';
import { LoginComponent } from './component/login/login.component';
import { Usuario } from './model/usuario';
import { ILoginService, LoginService } from './service/login/i-login.service';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    RouterOutlet, 
    SearchBarComponent, 
    NotificationIconComponent, 
    NavbarUserComponent,
    RouterLink, 
    CommonModule, 
    LoginComponent
  ],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  title = 'gtribapp';
  currentUrl = '';
  isActive = false;
  usuario: Usuario = {
    id: 0,
    nomeCompleto: '',
    login: '',
    senha: '',
    perfil: 'User'
  };
  private usuarioStorageKey = 'usuario';

  constructor(
    private router: Router,
    @Inject(LoginService) private loginService: ILoginService
  ) {
    router.events.subscribe(evento => {
      if (evento instanceof NavigationEnd) {
        this.currentUrl = evento.url;
      }
    });

    this.loginService.usuarioAutenticado.subscribe({
      next: (usuario: Usuario) => {
        this.usuario = usuario;
        this.saveUsuarioToStorage(usuario);
      }
    });
  }

  ngOnInit(): void {
    this.loadUsuarioFromStorage();
  }

  loadUsuarioFromStorage(): void {
    if (typeof sessionStorage !== 'undefined') {
      const userData = sessionStorage.getItem(this.usuarioStorageKey);
      if (userData) {
        this.usuario = JSON.parse(userData);
        this.loginService.usuarioAutenticado.next(this.usuario);
      }
    }
  }

  saveUsuarioToStorage(usuario: Usuario): void {
    if (typeof sessionStorage !== 'undefined') {
      sessionStorage.setItem(this.usuarioStorageKey, JSON.stringify(usuario));
    }
  }

  reloadUsuario(): void {
    this.loadUsuarioFromStorage();
  }

  isLoggedIn(): boolean {
    return this.loginService.isLoggedIn();
  }

  logout(): void {
    this.loginService.logout();
  }

  isLoginRoute(): boolean {
    return this.router.url === '/login';
  }

  toggleNotification() {
    this.isActive = !this.isActive;
  }
}