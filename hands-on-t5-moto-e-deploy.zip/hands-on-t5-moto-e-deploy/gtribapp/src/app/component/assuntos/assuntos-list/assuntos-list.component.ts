import { Component, OnInit } from '@angular/core';
import { Assunto } from '../../../model/assunto';
import { RespostaPaginada } from '../../../model/resposta-paginada';
import { AssuntoService } from '../../../service/assunto.service';
import { RequisicaoPaginada } from '../../../model/requisicao-paginada';
import { CommonModule } from '@angular/common';
import { Router, RouterLink } from '@angular/router';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';

declare var bootstrap: any;

@Component({
  selector: 'app-assuntos-list',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterLink],
  templateUrl: './assuntos-list.component.html',
  styleUrls: ['./assuntos-list.component.scss']
})
export class AssuntosListComponent implements OnInit {
  respostaPaginada: RespostaPaginada<Assunto> = <RespostaPaginada<Assunto>>{};
  requisicaoPaginada: RequisicaoPaginada = new RequisicaoPaginada();
  termoBusca: string = '';
  assuntos: Assunto[] = Array<Assunto>();
  assuntosFiltrados: Assunto[] = this.assuntos;
  assuntoSelecionado: Assunto | null = null;
  editForm: FormGroup;
  addForm: FormGroup;

  constructor(
    private fb: FormBuilder,
    private servico: AssuntoService,
    private router: Router
  ) {
    this.editForm = this.fb.group({
      id: [''],
      sigla: ['', [Validators.required, Validators.minLength(2)]],
      descricao: ['', [Validators.required, Validators.minLength(5)]]
    });
    this.addForm = this.fb.group({
      id:[''],
      sigla: ['', [Validators.required, Validators.minLength(2)]],
      descricao: ['', [Validators.required, Validators.minLength(5)]]
    });
  }

  ngOnInit(): void {
    this.requisicaoPaginada.page = 0;
    this.requisicaoPaginada.size = 25;
    this.get();
  }

  get(event?: Event): void {
    const termoBusca = event ? (event.target as HTMLInputElement).value : '';
    this.termoBusca = termoBusca;

    this.servico.get(termoBusca, this.requisicaoPaginada).subscribe({
      next: (resposta: RespostaPaginada<Assunto>) => {
        this.assuntos = resposta.content;
        this.respostaPaginada = resposta;
        this.filtrarAssuntos();
      },
      error: (err) => {
        console.error('Erro ao buscar assuntos', err);
      }
    });
  }

  mudarPagina(pagina: number): void {
    if (pagina >= 0 && pagina < this.respostaPaginada.totalPages) {
      this.requisicaoPaginada.page = pagina;
      this.get();
    }
  }

  mudarTamanhoPagina(event: Event) {
    const target = event.target as HTMLSelectElement;
    this.requisicaoPaginada.size = +target.value;
    this.requisicaoPaginada.page = 0; // Reset para a primeira página
    this.get();
  }

  adicionar() {
    const modalElement = document.getElementById('addAssuntoModal');
    if (modalElement) {
      const addModal = new bootstrap.Modal(modalElement);
      addModal.show();
    } else {
      console.error('Elemento #addModal não encontrado no DOM.');
    }
  }

  adicionarAssunto() {
    const novoAssunto: Assunto = this.addForm.value;
    novoAssunto['ativo'] = true //Novos assuntos ativos por padrao
    if (this.addForm.valid) {    
    this.servico.save(novoAssunto).subscribe({
      next: (assunto) => {
        this.get();
        const addModal = bootstrap.Modal.getInstance(document.getElementById('addAssuntoModal'));
        addModal.hide();
      },
      error: (err) => console.error('Erro ao adicionar assunto', err)
    });} else {
      this.addForm.markAllAsTouched(); // Marca todos os campos para exibir erros
    }
  }

  excluirAssuntoConfirmado(): void {
    if (this.assuntoSelecionado) { // Verifique se 'assuntoSelecionado' não é undefined
      if (this.assuntoSelecionado.ativo) {
        // Se o assunto está ativo, desativá-lo
        this.servico.desativarAssunto(this.assuntoSelecionado.id).subscribe({
          next: (assunto: Assunto) => {
            console.log('Assunto desativado:', assunto);
            this.assuntoSelecionado = null;
            const deleteModal = bootstrap.Modal.getInstance(document.getElementById('deleteModal'));
            deleteModal.hide();
            this.get(); // Recarrega a lista de assuntos
          },
          error: (err) => {
            console.error('Erro ao desativar o assunto', err);
          }
        });
      } else {
        // Se o assunto está inativo, ativá-lo
        this.servico.ativarAssunto(this.assuntoSelecionado.id).subscribe({
          next: (assunto: Assunto) => {
            console.log('Assunto ativado:', assunto);
            this.assuntoSelecionado = null;
            const deleteModal = bootstrap.Modal.getInstance(document.getElementById('deleteModal'));
            deleteModal.hide();
            this.get(); // Recarrega a lista de assuntos
          },
          error: (err) => {
            console.error('Erro ao ativar o assunto', err);
          }
        });
      }
    } else {
      console.error('Nenhum assunto selecionado para desativar ou ativar.');
    }
  }

  abrirModalEditar(assunto: Assunto) {
    this.assuntoSelecionado = { ...assunto };
    this.editForm.patchValue(this.assuntoSelecionado);
    const editModal = new (window as any).bootstrap.Modal(document.getElementById('editModal'));
    editModal.show();
  }

  salvarEdicaoAssunto() {
    const novoAssunto: Assunto = this.editForm.value;
    novoAssunto['ativo'] = true //assuntos ativos por padrao
    if (this.editForm.valid) {    
    this.servico.save(novoAssunto).subscribe({
      next: (assunto) => {
        this.get();
        const addModal = bootstrap.Modal.getInstance(document.getElementById('editModal'));
        addModal.hide();
      },
      error: (err) => console.error('Erro ao editar assunto', err)
    });} else {
      this.addForm.markAllAsTouched(); // Marca todos os campos para exibir erros
    }
  }

  abrirModalExcluir(assunto: Assunto) {
    this.assuntoSelecionado = assunto;
    const deleteModal = new (window as any).bootstrap.Modal(document.getElementById('deleteModal'));
    deleteModal.show();
  }

  onSearch(termo: string) {
    this.termoBusca = termo;
    this.filtrarAssuntos();
  }

  filtrarAssuntos() {
    const termo = this.termoBusca.toLowerCase();
    this.assuntosFiltrados = this.assuntos.filter(assunto =>
      assunto.sigla.toLowerCase().includes(termo) ||
      assunto.descricao.toLowerCase().includes(termo)
    );
  }
}




  // salvarEdicaoAssunto() {
  //   if (this.editForm.valid && this.assuntoSelecionado) {
  //     const atualizado: Assunto = { ...this.assuntoSelecionado, ...this.editForm.value };
  //     this.servico.atualizarAssunto(atualizado).subscribe({
  //       next: () => {
  //         console.log('Assunto atualizado com sucesso');
  //         this.get(); // Recarrega a lista de assuntos
  //         const editModal = (window as any).bootstrap.Modal.getInstance(document.getElementById('editModal'));
  //         editModal.hide();
  //       },
  //       error: (err) => {
  //         console.error('Erro ao atualizar o assunto', err);
  //       }
  //     });
  //   }
  // }

