import { ComponentFixture, TestBed } from '@angular/core/testing';

<<<<<<<< HEAD:gtribapp/src/app/component/assuntos/assuntos-form/assuntos-form.component.spec.ts
import { AssuntosFormComponent } from './assuntos-form.component';

describe('AssuntosFormComponent', () => {
  let component: AssuntosFormComponent;
  let fixture: ComponentFixture<AssuntosFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AssuntosFormComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(AssuntosFormComponent);
========
import { UsuarioComponent } from './usuario.component';

describe('UsuarioComponent', () => {
  let component: UsuarioComponent;
  let fixture: ComponentFixture<UsuarioComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [UsuarioComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(UsuarioComponent);
>>>>>>>> f0a491e8fb306fa3dbfb0130ae6d024ae8c2dfd9:gtribapp/src/app/component/usuario/usuario.component.spec.ts
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
