import { Component } from '@angular/core';
import { CadastroComponent } from '../../cadastro/cadastro.component';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { RouterLink, Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import Swal from 'sweetalert2';
import { Assunto } from '../../../model/assunto';
import { RespostaPaginada } from '../../../model/resposta-paginada';
import { notBlankValidator } from '../../../validators/notBlank.validators';
import { AssuntoService } from '../../../service/assunto.service';

@Component({
  selector: 'app-assuntos-form',
  standalone: true,
  imports: [FormsModule, CommonModule, RouterLink, ReactiveFormsModule, CadastroComponent],
  templateUrl: './assuntos-form.component.html',
  styleUrl: './assuntos-form.component.scss'
})
export class AssuntosFormComponent {
  constructor(
    private servico: AssuntoService,
    private router: Router
  ) { }
 

  ngOnInit(): void {
    this.assuntos();
  }

  registro: Assunto = <Assunto>{};
  listAssuntos: Assunto [] = [];
  totalElements: number = 0;

  formNovoAssunto = new FormGroup({
    descricao: new FormControl<string | null>(null, Validators.required),
    sigla: new FormControl<string | null>(null, notBlankValidator(3))
  })

  get form() {
    return this.formNovoAssunto.controls;
  }

  assuntos(termoBusca?: string): void {
    // Pega o total de registros
    this.servico.get(termoBusca, { page: 0, size: 1, sort: [] }).subscribe({
      next: (resposta: RespostaPaginada<Assunto>) => {
        const totalRegistros = resposta.totalElements;

        //Passa o total de registros como parametro size para sempre puxar todos os assuntos.
        this.servico.get(termoBusca, { page: 0, size: totalRegistros, sort: [] }).subscribe({
          next: (assunto: RespostaPaginada<Assunto>) => {
            this.listAssuntos = assunto.content;
            this.totalElements = assunto.totalElements;
          }
        });
      }
    });
  }

  save(): void {
    const formValue = { ...this.formNovoAssunto.value };

    this.registro = Object.assign(this.registro, formValue); //mandamos a cópia do formNovoAssunto e não o form verdadeiro.
    console.log(this.registro);
    this.servico.save(this.registro).subscribe({
      complete: () => {
        this.router.navigate(['/assuntos/list']);
        // Usando SweetAlert2 para exibir uma mensagem de sucesso
        Swal.fire({
          icon: 'success',
          title: 'Assunto cadastrado com sucesso!',
          showConfirmButton: false,
          position: 'top-end',
          timer: 3000,
          toast: true,
        });
      },
      error: (err) => {
        // Exibindo uma mensagem de erro com SweetAlert2
        Swal.fire({
          icon: 'error',
          title: 'Erro ao cadastrar assunto',
          showConfirmButton: false,
          position: 'top-end',
          timer: 3000,
          toast: true,
        });
      }
    });
  }
}
