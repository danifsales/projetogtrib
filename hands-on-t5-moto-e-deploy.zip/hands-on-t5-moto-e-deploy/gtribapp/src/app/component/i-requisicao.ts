export interface RequisicaoPaginada{
    size: number;  //Define o tamanho de elementos por página
    number: number; //Número da pagina
    sort: string[]; //Parametro de ordenação
}

export interface RespostaPaginada<T> {
    content: T[];           // Lista de registros da base de dados
    totalElements: number;  // Total de elementos
    size: number;           // Tamanho da página
    number: number;         // Número da página atual
  }
