import { CommonModule } from '@angular/common';
import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { EChartsOption } from 'echarts';
import { NgxEchartsDirective, provideEcharts } from 'ngx-echarts';
import { ProcessoService } from '../../service/processo.service';
import { UsuarioService } from '../../service/usuario.service';
import { MovimentacaoService } from '../../service/movimentacao.service'; 
import { Processo } from '../../model/processo';
import { Usuario } from '../../model/usuario'; // Importing Usuario model
import { FormsModule } from '@angular/forms';
import { forkJoin } from 'rxjs';
import { Movimentacao } from '../../model/movimentacao';
import { SetorService } from '../../service/setor.service';

@Component({
  selector: 'app-relatorios',
  standalone: true,
  imports: [CommonModule, NgxEchartsDirective, FormsModule],
  templateUrl: './relatorios.component.html',
  styleUrl: './relatorios.component.scss',
  providers: [
    provideEcharts()
  ]
})
export class RelatoriosComponent implements OnInit {
  auditores: {id: number, nome: string, processosDistribuidos: number, produtividade: number,processosConcluidos: number }[] = [];
  acessores: {id: number, nome: string, processosDistribuidos: number, produtividade: number,processosConcluidos: number }[] = [];
  chartOption: EChartsOption = {
    title: {
      text: '', 
      left: 'center',
      top: '20px',
      textStyle: {
        fontSize: 18,
        fontWeight: 'bold',
      }
    },
    xAxis: {
      type: 'category',
      data: [] as string[],
      axisLabel: {
        rotate: 45,
        interval: 0
      }
    },
    yAxis: {
      type: 'value'
    },
    series: [
      {
        name: 'Processos Abertos',
        type: 'bar',
        data: [] as number[],
        label: {
          show: true,
          position: 'top',
          formatter: '{c} processos'
        }
      }
    ]
  };

  pieChartOption: EChartsOption = {
    title: {
      text: 'Distribuição de Processos',
      left: 'center',
      top: '20px',
      textStyle: {
        fontSize: 18,
        fontWeight: 'bold',
      }
    },
    series: [
      {
        name: 'Processos',
        type: 'pie',
        radius: '50%',
        data: [],
        label: {
          formatter: '{b}: {d}%'
        }
      }
    ]
  };

  anos: number[] = [];
  selectedAno: number = new Date().getFullYear();
  processos: Processo[] = [];
  contagemPorMes: { [key: string]: number } = {};

  // KPI Variables
  totalProcessos: number = 0;
  processosConcluidos: number = 0;
  processosEmProgresso: number = 0;
  percentualConclusao: number = 0;
  movimentacoes: any[] = [];

  constructor(
    private processoService: ProcessoService,
    private usuarioService: UsuarioService, // Injecting UsuarioService
    private movimentacaoService: MovimentacaoService,
    private setorService: SetorService,
    private cdr: ChangeDetectorRef 

  ) {}
  ngOnInit(): void {
    this.anosProcessos();
    this.obterProcessosPorAno(this.selectedAno);
    this.obterPerfis();
    this.carregarMovimentacoes();
  }

  anosProcessos() {
    this.processoService.get().subscribe((resposta) => {
      this.processos = resposta.content;
      this.anos = Array.from(new Set(this.processos.map(p => new Date(p.dataCapa).getFullYear())));
    });
  }

  obterProcessosPorAno(ano: number): void {
    this.processoService.get().subscribe((resposta) => {
      this.processos = resposta.content;

      // Filtrar processos para o ano selecionado
      const processosDoAno = this.processos.filter(processo => new Date(processo.dataCapa).getFullYear() === ano);

      // Atualizar contagem por mês e gráfico
      this.contagemPorMes = this.contarProcessosPorMes(processosDoAno);
      const meses = Object.keys(this.contagemPorMes);
      const contagem = meses.map(mes => this.contagemPorMes[mes]);

      // Atualiza o gráfico de barras com os dados corretos
      this.atualizarGrafico(meses, contagem);

      // Atualiza o gráfico de pizza com os dados de distribuição de processos
      this.atualizarGraficoPizza(processosDoAno);

      // Atualiza os KPIs para o ano selecionado
      this.calcularKPIs(processosDoAno);

      // Força a atualização dos gráficos criando uma nova referência
      this.chartOption = { ...this.chartOption };
      this.pieChartOption = { ...this.pieChartOption };
  });
  }

  contarProcessosPorMes(processos: Processo[]): { [key: string]: number } {
    const contagemPorMes: { [key: string]: number } = {};

    processos.forEach((processo: Processo) => {
      const data = new Date(processo.dataCapa);
      const mesAno = `${data.getMonth() + 1}-${data.getFullYear()}`;
      contagemPorMes[mesAno] = (contagemPorMes[mesAno] || 0) + 1;
    });

    return contagemPorMes;
  }

  atualizarGrafico(meses: string[], contagem: number[]): void {
    if (Array.isArray(this.chartOption.title)) {
      this.chartOption.title[0].text = `Processos de ${this.selectedAno}`;
    } else {
      this.chartOption.title!.text = `Processos de ${this.selectedAno}`;
    }

    if (this.chartOption.xAxis) {
      (this.chartOption.xAxis as { data: string[] }).data = meses;
    }

    if (this.chartOption.series && Array.isArray(this.chartOption.series)) {
      (this.chartOption.series[0] as { data: number[] }).data = contagem;
    }
  }

  atualizarGraficoPizza(processos: Processo[]): void {
    const situacaoContagem = {
      'A DISTRIBUIR': 0,
      'A FAZER': 0,
      'EM PROGRESSO': 0,
      'DILIGENCIA': 0,
      'CONCLUIDO': 0,
      'A_FINALIZAR': 0

    };

    processos.forEach(processo => {
      switch (processo.situacao) {
        case 'A_DISTRIBUIR':
          situacaoContagem['A DISTRIBUIR']++;
          break;
        case 'A_FAZER':
          situacaoContagem['A FAZER']++;
          break;
        case 'EM_PROGRESSO':
          situacaoContagem['EM PROGRESSO']++;
          break;
        case 'DILIGENCIA':
          situacaoContagem['DILIGENCIA']++;
          break;
        case 'A_FINALIZAR':
          situacaoContagem['A_FINALIZAR']++;
          break;
        case 'CONCLUIDO':
          situacaoContagem['CONCLUIDO']++;
          break;
      }
    });
  
    if (Array.isArray(this.pieChartOption.title)) {
      this.pieChartOption.title[0].text = `Distribuição de Processos de ${this.selectedAno}`;
    } else {
      this.pieChartOption.title!.text = `Distribuição de Processos de ${this.selectedAno}`;
    }
  
    this.pieChartOption.series = [
      {
        name: 'Processos',
        type: 'pie',
        radius: '50%',
        data: Object.keys(situacaoContagem).map(key => ({
          name: key,
          value: situacaoContagem[key as keyof typeof situacaoContagem]
        })),
        label: {
          formatter: '{b}: {d}%'
        }
      }
    ];
  }

  calcularKPIs(processos: Processo[]): void {
    this.totalProcessos = processos.length;
    this.processosConcluidos = processos.filter(processo => processo.situacao === 'CONCLUIDO').length;
    this.processosEmProgresso = processos.filter(processo => processo.situacao === 'EM_PROGRESSO').length;
    this.percentualConclusao = this.totalProcessos > 0 
    ? parseFloat(((this.processosConcluidos / this.totalProcessos) * 100).toFixed(2)) 
    : 0;
  
  }

  onAnoChange(): void {
    this.obterProcessosPorAno(Number(this.selectedAno));
    setTimeout(() => {
      this.chartOption = { ...this.chartOption };
      this.pieChartOption = { ...this.pieChartOption };
      this.cdr.detectChanges();
    });
  }


    // Method to fetch auditors from UsuarioService
    obterPerfis(): void {
      this.usuarioService.get().subscribe(resposta => {
        const usuarios = resposta.content;

        // Filter only users with perfil 'Auditor'
        const auditores = usuarios.filter(usuario => usuario.perfil === 'AUDITOR');
        const acessores = usuarios.filter(usuario => usuario.perfil === 'ASSESSOR');
        
        this.auditores = auditores.map(auditor => ({
          nome: auditor.nomeCompleto,
          id: auditor.id,
          processosDistribuidos: 0,
          processosConcluidos: 0,
          produtividade: 0
        }));

        this.acessores = acessores.map(acessor => ({
          nome: acessor.nomeCompleto,
          id: acessor.id,
          processosDistribuidos: 0,
          processosConcluidos: 0,
          produtividade: 0
        }));
  
        // Now, associate processes with each auditor
        this.obterProcessosParaPerfis();
      });
    }
  
    // Method to calculate the process counts for each auditor
    obterProcessosParaPerfis(): void {
      // Define the weights for different difficulty levels
      const weights: { [key: string]: number } = {
        FACIL: 1,
        NORMAL: 2,
        DIFICIL: 3,
        MUITO_DIFICIL: 4
      };
    
      // Use forkJoin to wait for both service responses before proceeding
      forkJoin({
        processos: this.processoService.get(),
        movimentacoes: this.movimentacaoService.get()
      }).subscribe(({ processos, movimentacoes }) => {
        const processosData = processos.content;
        const movimentacoesData = movimentacoes.content;

        this.auditores = this.auditores.map(auditor => {
          const processosConcluidos = processosData.filter(processo =>
            processo.auditorId === auditor.id && processo.situacao === 'CONCLUIDO'
          );
    
          const processosDistribuidos = movimentacoesData.filter(movimentacao =>
            movimentacao.usuarioId === auditor.id && movimentacao.movimentacao === 'DESIGNACAO'
          ).length;
    
          // Calculate weighted average productivity based on all auditor's processes
          const auditorProcessos = processosData.filter(processo =>
            processo.auditorId === auditor.id
          );
          const totalWeightedDificuldade = auditorProcessos.reduce((sum, processo) => {
            const weight = weights[processo.dificuldade as keyof typeof weights] || 0;
            return sum + weight;
          }, 0);
    
          // Sum the weights of closed (CONCLUIDO) processes
          const totalWeightedConcluidos = processosConcluidos.reduce((sum, processo) => {
            const weight = weights[processo.dificuldade as keyof typeof weights] || 0;
            return sum + weight;
          }, 0);
    
          const totalProcesses = auditorProcessos.length;
          // Weighted average productivity considering all processes and closed processes
          // const produtividade = totalProcesses > 0 
          //   ? (totalWeightedDificuldade + totalWeightedConcluidos) / (totalProcesses + processosConcluidos.length)
          //   : 0;
          const produtividade = totalProcesses > 0 ? (processosConcluidos.length / totalProcesses) * 100 : 0;
    
          return {
            nome: auditor.nome,
            id: auditor.id,
            processosDistribuidos,
            processosConcluidos: processosConcluidos.length,
            produtividade
          };
        });

        this.acessores = this.acessores.map(acessor => {
          const processosConcluidos = processosData.filter(processo =>
            processo.acessorId === acessor.id && processo.situacao === 'CONCLUIDO'
          );
    
          const processosDistribuidos = movimentacoesData.filter(movimentacao =>
            movimentacao.usuarioId === acessor.id && movimentacao.movimentacao === 'DESIGNACAO'
          ).length;
    
          const auditorProcessos = processosData.filter(processo =>
            processo.acessorId === acessor.id
          );acessor
    
          const totalProcesses = auditorProcessos.length;

          const produtividade = totalProcesses > 0 ? (processosConcluidos.length / totalProcesses) * 100 : 0;
    
          return {
            nome: acessor.nome,
            id: acessor.id,
            processosDistribuidos,
            processosConcluidos: processosConcluidos.length,
            produtividade
          };
        });
      });
    }
    
    exportarAuditoresCSV(): void {
      const headers = ['Nome', 'Processos Distribuídos', 'Processos Concluídos', 'Produtividade'];
      const auditoresData = this.auditores.map(auditor => ({
        Nome: auditor.nome,
        'Processos Distribuídos': auditor.processosDistribuidos,
        'Processos Concluídos': auditor.processosConcluidos,
        Produtividade: auditor.produtividade
      }));
    
      this.gerarCSV(auditoresData, headers, 'auditores.csv');
    }
    
    exportarAcessoresCSV(): void {
      const headers = ['Nome', 'Processos Distribuídos', 'Processos Concluídos', 'Produtividade'];
      const acessoresData = this.acessores.map(acessor => ({
        Nome: acessor.nome,
        'Processos Distribuídos': acessor.processosDistribuidos,
        'Processos Concluídos': acessor.processosConcluidos,
        Produtividade: acessor.produtividade
      }));
    
      this.gerarCSV(acessoresData, headers, 'acessores.csv');
    }


    carregarMovimentacoes(): void {
      this.movimentacaoService.get().subscribe({
        next: (resposta) => {
          this.movimentacoes = resposta.content; // Ajuste conforme a estrutura da resposta da sua API
        },
        error: (erro) => {
          console.error('Erro ao carregar movimentações:', erro);
        }
      });
    }
  
    exportarMovimentacoesCSV(): void {
      if (!this.movimentacoes || this.movimentacoes.length === 0) {
        console.warn('Nenhuma movimentação disponível para exportar.');
        return;
      }
  
      const headers = ['Data', 'Movimentação', 'Usuário', 'Nº Processo', 'Setor Destino', 'Usuário Designado'];
      
    console.log(this.movimentacoes)
      const movimentacoesData = this.movimentacoes.map(movimentacao => ({
        Data: movimentacao.data,
        Movimentação: movimentacao.movimentacao,
        'Usuário': movimentacao.usuarioNome,
        'Nº Processo': movimentacao.processo,
        'Setor Destino': movimentacao?.setorNome || "DETRIB",
        'Usuário Designado': movimentacao.usuarioNome,
        
      }));
      console.log(movimentacoesData);
  
      this.gerarCSV(movimentacoesData, headers, 'movimentacoes.csv');
    }
    private gerarCSV(data: any[], headers: string[], filename: string): void {
      console.log('gerando')
      let csvContent = headers.join(',') + '\n';
      data.forEach(row => {
        csvContent += Object.values(row).join(',') + '\n';
      });
    
      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const link = document.createElement('a');
      const url = URL.createObjectURL(blob);
      link.setAttribute('href', url);
      link.setAttribute('download', filename);
      link.style.visibility = 'hidden';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
    
}
