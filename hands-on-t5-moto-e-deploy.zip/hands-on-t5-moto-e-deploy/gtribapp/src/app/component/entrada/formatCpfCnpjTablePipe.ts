import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'formatCpfCnpj',
  standalone: true  // Torna o pipe standalone
})
export class FormatCpfCnpjTablePipe implements PipeTransform {

  transform(value: string): string {
    if (!value) return value;

    const cleanedValue = value.replace(/\D/g, ''); // Remove qualquer caractere não numérico

    // Verifica se é CPF (11 dígitos)
    if (cleanedValue.length === 11) {
      return cleanedValue.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4');
    }

    // Verifica se é CNPJ (14 dígitos)
    if (cleanedValue.length === 14) {
      return cleanedValue.replace(/(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})/, '$1.$2.$3/$4-$5');
    }

    return value; // Se não for nem CPF nem CNPJ, retorna o valor original
  }
}