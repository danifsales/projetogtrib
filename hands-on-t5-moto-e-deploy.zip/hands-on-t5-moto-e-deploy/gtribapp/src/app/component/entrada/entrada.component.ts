import { Component } from '@angular/core';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { NgbPaginationModule } from '@ng-bootstrap/ng-bootstrap';
import { TheadOrdenacaoComponent } from '../thead-ordenacao/thead-ordenacao.component';
import { CommonModule } from '@angular/common';
import { ProcessoService } from '../../service/processo.service';
import { Processo } from '../../model/processo';
import { IList } from '../i-list';
import { RespostaPaginada } from '../../model/resposta-paginada';
import { RouterLink } from '@angular/router';
import { SpinnerComponent } from '../spinner/spinner.component'; 
import { InteressadoService } from '../../service/interessado.service';
import { Interessado } from '../../model/interessado'; 
import { Assunto } from '../../model/assunto';
import { AssuntoService } from '../../service/assunto.service'; 
import { UsuarioService } from '../../service/usuario.service';
import { Usuario } from '../../model/usuario';
import { TheadOrdenacao } from '../thead-ordenacao/thead-ordenacao';
import { RequisicaoPaginada } from '../../model/requisicao-paginada';
import { FormatProcessTablePipe } from '../../model/format-process-table.pipe';
import { Setor } from '../../model/setor';
import { SetorService } from '../../service/setor.service';
import { EMotivoDiligencia } from '../../model/EMotivoDiligencia';
import Swal from 'sweetalert2';
import {  FormatCpfCnpjTablePipe } from './formatCpfCnpjTablePipe';
import { JwtLoginService } from '../../service/login/jwt-login.service';
import { EDificuldade } from '../../model/EDificuldade';
import { EConclusao } from '../../model/EConclusao';


declare var bootstrap: any; 

@Component({
  selector: 'app-entrada',
  standalone: true,
  imports: [NgbPaginationModule, 
    FormsModule, 
    TheadOrdenacaoComponent, 
    CommonModule, 
    RouterLink, 
    SpinnerComponent,FormatProcessTablePipe,FormatCpfCnpjTablePipe, ReactiveFormsModule],
  templateUrl: './entrada.component.html',
  styleUrl: './entrada.component.scss'
})

//Desabafo pessoal: esse código está horrível. Tanto no HTML quanto aqui, deveriamos ter componentizado mais as coisas, mas agora vai dar muito trabalho.
export class EntradaComponent implements IList<Processo>{
  usuario!: Usuario | null; // Armazena o usuário autenticado
  finalizarProcessoForm: FormGroup;
  constructor(
    private processoService: ProcessoService,    
    private interessadoService: InteressadoService,
    private assuntosService: AssuntoService,
    private usuarioService: UsuarioService,
    private setorService: SetorService,
    private loginService: JwtLoginService,
    private fb: FormBuilder
  ) {
    this.finalizarProcessoForm = this.fb.group({
      parecerNumero: ['', Validators.required], // Número do Parecer
      nivelDificuldade: [EDificuldade.NORMAL, Validators.required], // Nível de Dificuldade
      palavraChave: ['', Validators.required], // Palavra-Chave
      observacao: [''] // Observação (opcional)
    });
  }
 

  ngOnInit():void{ //ngOnInit é uma função do angular que toda vez que a página for carregada, ele executa o que esta dentro dele
    this.get();
    this.getInteressados();
    this.getAssuntos(); 
    this.getUsuarios(); 
    this.requisicaoPaginada.page = 0;


    // Subscrição para receber atualizações do usuário logado
    const userData = sessionStorage.getItem('usuario');
    if (userData != null) {
      this.usuario = Object.assign({}, JSON.parse(userData));
    }
    }
    
    // registros: Profissional[] = Array<Profissional>();


    registros: Processo[] = Array<Processo>();
    interessados: Interessado[] = []; 
    assuntos: Assunto[] = []; 
    setores: Setor[] = [];
    usuarios: Usuario[] = [];
    processos: Processo[] = [] 
    processosUserLogado:Processo[] = [];
    processosFiltrados: Processo[] = []; 
    respostaPaginada: RespostaPaginada<Processo> = <RespostaPaginada<Processo>>{};
    requisicaoPaginada: RequisicaoPaginada = new RequisicaoPaginada();
    conclusaoOptions = Object.values(EConclusao);
    conclusaoSelecionada: EConclusao = EConclusao.DEFERIDO;
    totalElements: number = 0;
    loading: boolean = false;
    termoBusca: string = '';
    debounceTimeout: any; 
    showDistribuirModal: boolean = false;  // Controla o modal "Distribuir"
    showEncaminharDiligenciaModal: boolean = false;  // Controla o modal "Encaminhar para Diligência"
    showRetornarDiligenciaModal: boolean = false; // Controle do retorno da diligência
    showIniciarModal: boolean = false;
    showFinalizarModal: boolean = false;
    showConcluirModal: boolean = false;
    //variaveis para filtragem do menu lateral
    filterAtribuidos: boolean = false;
    filterNaoAtribuidos: boolean = false;
    filterRecebidos: boolean = false;
    todosProcessos: Processo[] = [];
    dificuldadeLabels = {
      [EDificuldade.FACIL]: 'Fácil',
      [EDificuldade.NORMAL]: 'Normal',
      [EDificuldade.DIFICIL]: 'Difícil',
      [EDificuldade.MUITO_DIFICIL]: 'Muito Difícil'
    };

    niveisDificuldade = Object.values(EDificuldade);
    //variaveis para contadores do menu lateral
    processosAtribuidos: number = 0;
    processosNaoAtribuidos: number = 0;
    selectedAssessor: number | null = null;
    selectedUser: number | null = null;
    idProcesso: number = 1; // Defina um valor estático para o idProcesso
    selectedInteressado: string = ''; 
    selectedAssunto: string = '';
    selectedSituacao: string = '';
    processoSelecionado: Processo = <Processo>{};
    motivosDiligencia = [
      { label: 'Falta documentação', value: EMotivoDiligencia.PENDENTE_DE_DOCUMENTACAO }
    ];
    motivoDiligenciaSelecionado!: EMotivoDiligencia;
    setorSelecionado!: Setor;
    palavrasChave: string[] = [];

    // Ordena as colunas :)
    colunas: TheadOrdenacao = [
      { campo: 'dataCapa', descricao: 'Data Entrada' },
      { campo: 'numeroProcesso', descricao: 'N° Processo' },
      { campo: 'interessado.nome', descricao: 'Interessado' },
      { campo: 'interessado.cpfCnpj', descricao: 'CNPJ/CPF' },
      { campo: 'assunto', descricao: 'Assunto' },
      { campo: 'responsavel', descricao: 'Responsável' },
      { campo: 'auditor', descricao: 'Auditor(a)' },
      { campo: 'situacao', descricao: 'Situação' },
      { campo: '', descricao: 'Ações' },
    ];

    onPalavraChaveInput(event: KeyboardEvent): void {
      const input = event.target as HTMLInputElement;
      if (event.key === '.') {
        event.preventDefault(); // Previne o comportamento padrão de inserir o ponto no input
        const palavra = input.value.trim();
        if (palavra) {
          this.palavrasChave.push(palavra);
          input.value = '';
        }
      }
    }
  
    removePalavraChave(index: number): void {
      this.palavrasChave.splice(index, 1);
    }

    ordenar(ordenacao: string[]): void {
      this.requisicaoPaginada.sort = ordenacao;
      this.requisicaoPaginada.page = 0;
      this.get(this.termoBusca);
    }

    mudarPagina(pagina: number): void {
      if (pagina >= 0 && pagina < this.respostaPaginada.totalPages) {
        this.requisicaoPaginada.page = pagina;
        this.get();
      }
    }
  
    mudarTamanhoPagina(event: Event) {
      console.log(this.usuario)
      const target = event.target as HTMLSelectElement;
      this.requisicaoPaginada.size = +target.value;
      this.requisicaoPaginada.page = 0; // Reset para a primeira página
      this.get();
    }
  
    // Método para buscar todos os processos (sem afetar a paginação)
  getTodosProcessosSemPaginacao(): void {
    // Define uma requisição com um tamanho grande para obter todos os processos
    const requisicaoSemPaginacao = { ...this.requisicaoPaginada, page: 0, size: 1000 };

    this.processoService.get('', requisicaoSemPaginacao).subscribe({
      next: (processo: RespostaPaginada<Processo>) => {
        // Armazena todos os processos para contagens e filtragens
        this.todosProcessos = processo.content;
        
        // Recalcular as variáveis de contagem, sem afetar a exibição paginada
        const processosDoUsuarioLogado = this.todosProcessos.filter(p => p.responsavelId === this.usuario?.id);
        this.processosUserLogado = [...processosDoUsuarioLogado];
        this.processosAtribuidos = this.todosProcessos.filter(p => p.responsavelId).length;
        this.processosNaoAtribuidos = this.todosProcessos.filter(p => p.responsavelId === null).length;
      },
      error: (error) => {
        console.error('Erro ao carregar todos os processos:', error);
      }
    });
  }
    // Método para buscar processos
  get(termoBusca?: string): void {
    this.processoService.get(termoBusca, this.requisicaoPaginada).subscribe({
      next: (processo: RespostaPaginada<Processo>) => {
        // Atualiza o total de processos diretamente do objeto paginado
        this.totalElements = processo.totalElements;
  
        // Limitar a lista de processos à página atual sem acumular páginas
        this.processos = processo.content;
        this.respostaPaginada = processo;
  
        // Atualizar a lista filtrada de processos
        this.processosFiltrados = [...this.processos];
        
        // Inicializar a lista de dropdowns (se necessário para o controle da interface)
        this.showDropdown = new Array(this.processos.length).fill(false);
        this.getTodosProcessosSemPaginacao();
        // Finaliza o estado de carregamento
        this.loading = false;
      },
      error: (error) => {
        this.loading = false; // Finaliza o estado de carregamento em caso de erro
        console.log(error);
      }
    });
  }

    // Método chamado a cada digitação no campo de busca
    onSearch(term: string): void {
      clearTimeout(this.debounceTimeout); // Limpa o timeout anterior (se houver)
    
      // Remove caracteres especiais
      const sanitizedTerm = term.replace(/[\/.*]/g, '');
    
      if (sanitizedTerm.length >= 3 || sanitizedTerm.length === 0) { // Apenas faz a requisição se tiver pelo menos 3 caracteres ou se for vazio
        this.debounceTimeout = setTimeout(() => {
          this.get(sanitizedTerm); // Chama o método get() com o termo de busca sanitizado
        }, 300); // Debounce de 300ms
      }
    }
    

  delete(id: number): void {
    throw new Error('Method not implemented.');
  }

  getInteressados(termoBusca?: string): void {
    this.interessadoService.getInteressados(termoBusca, { page: 0, size: 20, sort: [] }).subscribe({
      next: (interessado: RespostaPaginada<Interessado>) => {
        this.interessados =  Object.values(interessado.content);

      },
      error: () => {
        console.error('erro ao carregar interessados');
      }
    });
  }

  getUsuarios(termoBusca?: string): void {
    this.usuarioService.get(termoBusca, { page: 0, size: 20, sort: [] }).subscribe({
      next: (usuario: RespostaPaginada<Usuario>) => {
        this.usuarios =  Object.values(usuario.content);
        console.log(usuario.content)
      },
      error: () => {
        console.error('erro ao carregar usuarios');
      }
    });
  }
  
  iniciarProcesso(){
      this.processoService.iniciarProcesso(this.processoSelecionado.id)
        .subscribe({
          next: (response) => {
            console.log('Processo iniciado com sucesso', response);
            this.closeIniciarModal();  // Fechar o modal após sucesso
            Swal.fire({
              icon: 'success',
              title: 'Processo iniciado com sucesso!',
              showConfirmButton: false,
              position: 'top-end', 
              timer: 3000,
              toast: true, 
            });
            this.get();
            this.closeIniciarModal();
          },
          error: (error) => {
            Swal.fire({
              icon: 'error',
              title: 'Erro ao iniciar processo.',
              showConfirmButton: false,
              position: 'top-end', 
              timer: 3000,
              toast: true, 
            });
            console.log(error)
            console.error('Erro ao iniciar o processo', error);
          }
        });
  
  }
  //LUCAS PUSH

  getAssuntos(termoBusca?: string): void {
    this.assuntosService.get(termoBusca, { page: 0, size: 20, sort: [] }).subscribe({
      next: (assunto: RespostaPaginada<Assunto>) => {
        this.assuntos =  Object.values(assunto.content);

      },
      error: () => {
        console.error('erro ao carregar assuntos');
      }
    });
  }

  // Atualiza o filtro quando um interessado é selecionado
onInteressadoChange(event: Event): void {
  const target = event.target as HTMLSelectElement;
  const interessadoId = target.value;
  this.selectedInteressado = interessadoId; // Não precisa de um valor vazio, "Todos" será a string vazia
  this.filtrarProcessos(); // Chama a função de filtragem
}
onSituacaoChange(event: Event): void {
  const target = event.target as HTMLSelectElement;
  const situacaoProcesso = target.value;
  this.selectedSituacao = situacaoProcesso; // Não precisa de um valor vazio, "Todos" será a string vazia
  console.log(this.selectedSituacao)

  this.filtrarProcessos(); // Chama a função de filtragem
}
// Atualiza o filtro quando um assunto é selecionado
onAssuntoChange(event: Event): void {
  const target = event.target as HTMLSelectElement;
  const assuntoId = target.value;
  this.selectedAssunto = assuntoId; // Não precisa de um valor vazio, "Todos" será a string vazia
  this.filtrarProcessos(); // Chama a função de filtragem
}

onFilterChange(event: Event, filterType: 'recebidos' | 'atribuidos' | 'naoAtribuidos'): void {
  event.preventDefault(); // Previne a navegação padrão do link
  
  // Mantém os filtros selecionados
  this.selectedInteressado = this.selectedInteressado;
  this.selectedAssunto = this.selectedAssunto;
  this.selectedSituacao = this.selectedSituacao;

  // Define o filtro ativo com base no tipo
  this.filterRecebidos = filterType === 'recebidos';
  this.filterAtribuidos = filterType === 'atribuidos';
  this.filterNaoAtribuidos = filterType === 'naoAtribuidos';

  this.filtrarProcessos(); // Chama a função de filtragem
}


// Filtra os processos de acordo com os selecionados nos selects
filtrarProcessos(): void {
  this.processosFiltrados = this.todosProcessos.filter(processo => {
    const matchInteressado = this.selectedInteressado 
      ? processo.interessadoCpfCnpj === this.selectedInteressado 
      : true; // Se "Todos" (string vazia), não filtra

    const matchAssunto = this.selectedAssunto 
      ? processo.assuntoSigla === this.selectedAssunto 
      : true; // Se "Todos" (string vazia), não filtra

      const matchSituacao = this.selectedSituacao 
      ? processo.situacao === this.selectedSituacao 
      : true; // Se "Todos" (string vazia), não filtra
      const matchAtribuidos = this.filterAtribuidos ? processo.responsavelId : true;
      const matchNaoAtribuidos = this.filterNaoAtribuidos ? !processo.responsavelId : true;

    return matchInteressado && matchAssunto && matchSituacao && matchAtribuidos && matchNaoAtribuidos; // Retorna processos que correspondem aos filtros
  });
}

  showDropdown: boolean[] = [];

  toggleDropdown(index: number, processo: Processo) {
    // Alterna a visibilidade do dropdown para a linha clicada
    this.showDropdown[index] = !this.showDropdown[index];
    this.processoSelecionado = processo;
  }

  isProcessoInUserLogado(processo: any): boolean {
    return this.processosUserLogado.some(p => p.id === processo.id);
  }
  // Abre o modal "Distribuir"
  openDistribuirModal(processoId: number): void {
    this.showDistribuirModal = true;
   
    this.processoService.getById(processoId).subscribe(
      (registro: Processo) => {
        this.processoSelecionado = registro; 
      },
      (error) => {
        console.error('Erro ao buscar o processo:', error);
      }
    );
  }

  openFinalizarModal(id: number): void{
    this.showFinalizarModal = true;

    this.processoService.getById(id).subscribe(
      (registro: Processo) => {
        this.processoSelecionado = registro; 
      },
      (error) => {
        console.error('Erro ao buscar o processo:', error);
      }
    );
  }

  openRetornarDiligenciaModal(processoId: number): void{
    this.showRetornarDiligenciaModal = true;
    this.processoService.getById(processoId).subscribe(
      (registro: Processo) => {
        this.processoSelecionado = registro; 
      },
      (error) => {
        console.error('Erro ao buscar o processo:', error);
      }
    );
  }


  concluirProcesso() {
    this.processoService.concluirProcesso(this.processoSelecionado.id, this.conclusaoSelecionada).subscribe({
      next: (response) => {
        const modalElement = document.getElementById('concluirModal');
        const modal = bootstrap.Modal.getInstance(modalElement);  // Obtenha a instância da modal
        modal.hide(); 
        
        Swal.fire({
          icon: 'success',
          title: 'Processo concluido com sucesso!',
          showConfirmButton: false,
          position: 'top-end', 
          timer: 3000,
          toast: true, 
        });
        this.get();
       
      },
      error: (error) => {
        Swal.fire({
          icon: 'error',
          title: 'Erro ao concluir processo',
          showConfirmButton: false,
          position: 'top-end', 
          timer: 3000,
          toast: true, 
        });
      }
    });
  }
  // Fecha o modal "Distribuir"
  closeDistribuirModal(): void {
    this.showDistribuirModal = false;
  }

  closeIniciarModal(): void{
    this.showIniciarModal = false;
  }

  openIniciarModal(): void{
    this.showIniciarModal = true;
  }
  closeRetornarDiligenciaModal(): void {
    this.showRetornarDiligenciaModal = false;
  }

  // Abre o modal "Encaminhar para Diligência"
  openEncaminharDiligenciaModal(processoId: number): void {
    this.getSetores();
    // this.showEncaminharDiligenciaModal = true;
    this.processoService.getById(processoId).subscribe(
      (registro: Processo) => {
        this.processoSelecionado = registro; 
      },
      (error) => {
        console.error('Erro ao buscar o processo:', error);
      }
    );

  }
 openConcluirProcessoModal(processoId: number){
    this.showConcluirModal = true;
    this.processoService.getById(processoId).subscribe(
    (registro: Processo) => {
      this.processoSelecionado = registro; 
    },
    (error) => {
      console.error('Erro ao buscar o processo:', error);
    }
  );
 }

   // Fecha o modal "Encaminhar para Diligência"
   closeEncaminharDiligenciaModal(): void {
    this.showEncaminharDiligenciaModal = false;
  }
  distribuir(): void {
    if (this.selectedUser && !this.selectedAssessor) {
      this.processoService.designarProcesso(this.processoSelecionado.id, this.selectedUser)
        .subscribe({
          next: (response) => {
            console.log('Processo distribuído com sucesso', response);
  
            // Atualize o processo específico na lista
            const index = this.processos.findIndex(p => p.id === this.processoSelecionado.id);
            if (index !== -1 && typeof this.selectedUser === 'number') {
              this.processos[index].responsavelId = this.selectedUser; // Atualize o responsável ou qualquer outro campo necessário
            }
  
            this.closeDistribuirModal();  // Fecha o modal após sucesso
  
            // Exibe o alerta de sucesso
            Swal.fire({
              icon: 'success',
              title: 'Processo distribuído com sucesso!',
              showConfirmButton: false,
              position: 'top-end',
              timer: 3000,
              toast: true,
            });
            this.get()
          },
          error: (error) => {
            Swal.fire({
              icon: 'error',
              title: 'Erro ao distribuir processo.',
              showConfirmButton: false,
              position: 'top-end',
              timer: 3000,
              toast: true,
            });
            console.error('Erro ao distribuir o processo', error);
          }
        });
    } else {
      if (this.selectedUser && this.selectedAssessor){
        this.processoService.designarProcesso(this.processoSelecionado.id, this.selectedUser,this.selectedAssessor)
          .subscribe({
            next: (response) => {
              console.log('Processo distribuído com sucesso', response);
    
              // Atualize o processo específico na lista
              const index = this.processos.findIndex(p => p.id === this.processoSelecionado.id);
              if (index !== -1 && typeof this.selectedUser === 'number') {
                this.processos[index].responsavelId = this.selectedUser; // Atualize o responsável ou qualquer outro campo necessário
              }
    
              this.closeDistribuirModal();  // Fecha o modal após sucesso
              this.selectedAssessor = null;
              // Exibe o alerta de sucesso
              Swal.fire({
                icon: 'success',
                title: 'Processo distribuído com sucesso!',
                showConfirmButton: false,
                position: 'top-end',
                timer: 3000,
                toast: true,
              });
              this.get()
            },
            error: (error) => {
              Swal.fire({
                icon: 'error',
                title: 'Erro ao distribuir processo.',
                showConfirmButton: false,
                position: 'top-end',
                timer: 3000,
                toast: true,
              });
              console.error('Erro ao distribuir o processo', error);
            }
          });
      }
  }}

  diligencia(): void{
    this.processoService.encaminharDiligencia(
    this.processoSelecionado.id, 
    true,                                 // Caminhamento: true (ida)        
    this.setorSelecionado.id,             
    this.motivoDiligenciaSelecionado      
  ).subscribe({
    next: (response) => {
      const modalElement = document.getElementById('encaminharDiligenciaModal');
      const modal = bootstrap.Modal.getInstance(modalElement);  // Obtenha a instância da modal
      modal.hide(); 
      
      Swal.fire({
        icon: 'success',
        title: 'Processo encaminhado para diligência com sucesso!',
        showConfirmButton: false,
        position: 'top-end', 
        timer: 3000,
        toast: true, 
      });
      this.get();
     
    },
    error: (error) => {
      Swal.fire({
        icon: 'error',
        title: 'Erro ao encaminhar processo para diligência.',
        showConfirmButton: false,
        position: 'top-end', 
        timer: 3000,
        toast: true, 
      });
    }
  });
  }

  retornoDiligencia(): void{

    this.processoService.encaminharDiligencia(
    this.processoSelecionado.id,  
    false,         
    null,                   
    null      
  ).subscribe({
    next: (response) => {
      const modalElement = document.getElementById('retornarDiligenciaModal');
      const modal = bootstrap.Modal.getInstance(modalElement);  // Obtenha a instância da modal
      modal.hide(); 
      
      Swal.fire({
        icon: 'success',
        title: 'Processo retornado da diligência com sucesso!',
        showConfirmButton: false,
        position: 'top-end', 
        timer: 3000,
        toast: true, 
      });
      this.get();
     
    },
    error: (error) => {
      Swal.fire({
        icon: 'error',
        title: 'Erro ao retornar processo da diligência.',
        showConfirmButton: false,
        position: 'top-end', 
        timer: 3000,
        toast: true, 
      });
    }
  });
  }
  
  getSetores(termoBusca?: string): void {
    this.setorService.get(termoBusca, { page: 0, size: 1000, sort: [] }).subscribe({
      next: (setor: RespostaPaginada<Setor>) => {
        this.setores =  Object.values(setor.content);

      },
      error: () => {
        console.error('erro ao carregar setores');
      }
    });
  }

  onSubmit() {
      if (this.finalizarProcessoForm.valid) {
        const dados = this.finalizarProcessoForm.value;
        console.log(dados); // `nivelDificuldade` será um valor do enum (ex: 'BAIXO', 'MEDIO', ou 'ALTO')
        this.processoService.finalizarProcesso(this.processoSelecionado.id, dados).subscribe({
        next: (response) => {
          const modalElement = document.getElementById('finalizarProcessoModal');
          const modal = bootstrap.Modal.getInstance(modalElement);
          modal.hide();
    
          Swal.fire({
            icon: 'success',
            title: 'Processo finalizado com sucesso!',
            showConfirmButton: false,
            position: 'top-end',
            timer: 3000,
            toast: true,
          });
          this.get(); // Atualize a lista ou a exibição dos processos
        },
        error: (error) => {
          Swal.fire({
            icon: 'error',
            title: 'Erro ao finalizar o processo.',
            showConfirmButton: false,
            position: 'top-end',
            timer: 3000,
            toast: true,
          });
        }
      });
    
    }
  }
}
