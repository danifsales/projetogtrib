import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NovoNivelDificuldadeFormComponent } from './novo-nivel-dificuldade.form.component';

describe('NovoNivelDificuldadeFormComponent', () => {
  let component: NovoNivelDificuldadeFormComponent;
  let fixture: ComponentFixture<NovoNivelDificuldadeFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [NovoNivelDificuldadeFormComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(NovoNivelDificuldadeFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
