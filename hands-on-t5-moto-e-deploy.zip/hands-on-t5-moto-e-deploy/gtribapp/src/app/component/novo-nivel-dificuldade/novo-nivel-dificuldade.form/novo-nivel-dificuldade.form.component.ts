import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { TheadOrdenacaoComponent } from '../../thead-ordenacao/thead-ordenacao.component';
import { RouterLink, Router } from '@angular/router';
import { CadastroComponent } from '../../cadastro/cadastro.component';
import { IForm } from '../../i-form';
import Swal from 'sweetalert2';
import { RespostaPaginada } from '../../../model/resposta-paginada';
import { Processo } from '../../../model/processo';
import { ProcessoService } from '../../../service/processo.service';
import { notBlankValidator } from '../../../validators/notBlank.validators';

@Component({
  selector: 'app-novo-nivel-dificuldade.form',
  standalone: true,
  imports: [FormsModule, TheadOrdenacaoComponent, CommonModule, RouterLink, ReactiveFormsModule, CadastroComponent],
  templateUrl: './novo-nivel-dificuldade.form.component.html',
  styleUrl: './novo-nivel-dificuldade.form.component.scss'
})
export class NovoNivelDificuldadeFormComponent implements IForm<Processo> {

  constructor(
    private servico: ProcessoService,
    private processoService: ProcessoService,
    private router: Router
  ) { }


  ngOnInit(): void {
    this.processos();
  }

  registro: Processo = <Processo>{};
  listProcessos: Processo[] = [];
  totalElements: number = 0;

  formNovoNivelDificuldade = new FormGroup({
    dificuldade: new FormControl<string | null>(null, Validators.required),
    codDificuldade: new FormControl<number | null>(null, notBlankValidator(3))
  });

  get form() {
    return this.formNovoNivelDificuldade.controls;
  }

  processos(termoBusca?: string): void {
    // Pega o total de registros
    this.processoService.get(termoBusca, { page: 0, size: 1, sort: [] }).subscribe({
      next: (resposta: RespostaPaginada<Processo>) => {
        const totalRegistros = resposta.totalElements;

        //Passa o total de registros como parametro size para sempre puxar todos os processos.
        this.processoService.get(termoBusca, { page: 0, size: totalRegistros, sort: [] }).subscribe({
          next: (processo: RespostaPaginada<Processo>) => {
            this.listProcessos = processo.content;
            this.totalElements = processo.totalElements;
          }
        });
      }
    });
  }
  
  save(): void {
    const formValue = { ...this.formNovoNivelDificuldade.value };

    this.registro = Object.assign(this.registro, formValue); //mandamos a cópia do formNovoNivelDificuldade e não o form verdadeiro.
    console.log(this.registro);
    this.servico.save(this.registro).subscribe({
      complete: () => {
        this.router.navigate(['/processos']);
        // Usando SweetAlert2 para exibir uma mensagem de sucesso
        Swal.fire({
          icon: 'success',
          title: 'Nível de dificuldade cadastrado com sucesso!',
          showConfirmButton: false,
          position: 'top-end',
          timer: 3000,
          toast: true,
        });
      },
      error: (err) => {
        // Exibindo uma mensagem de erro com SweetAlert2
        Swal.fire({
          icon: 'error',
          title: 'Erro ao cadastrar nível de dificuldade',
          showConfirmButton: false,
          position: 'top-end',
          timer: 3000,
          toast: true,
        });
      }
    });
  }



}
