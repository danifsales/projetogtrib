export type TheadOrdenacao = {
    campo: string;
    descricao: string;
}[]
