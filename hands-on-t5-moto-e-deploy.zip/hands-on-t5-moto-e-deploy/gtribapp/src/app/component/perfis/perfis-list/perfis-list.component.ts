import { Component, OnInit } from '@angular/core';
import { Router, RouterModule } from '@angular/router'; 
import { PerfilService } from '../../../service/perfil.service';
import { Perfil } from '../../../model/perfil';
import { RespostaPaginada } from '../../../model/resposta-paginada';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-perfis',
  standalone: true,
  imports: [CommonModule,RouterModule],
  templateUrl: './perfis-list.component.html',
  styleUrls: ['./perfis-list.component.scss']
})
export class PerfisComponent implements OnInit {

  perfis: Perfil[] = [];

  constructor(private PerfilService: PerfilService, private router: Router) { } 

  ngOnInit(): void {
    this.listarPerfis();
  }

  listarPerfis(): void {
    this.PerfilService.get().subscribe(
      (resposta: RespostaPaginada<Perfil>) => {
        this.perfis = resposta.content; 
      },
      (error) => {
        console.error('Erro ao buscar perfis:', error);
      }
    );
  }

  irParaDetalhes(idPerfil: number): void {
    this.router.navigate(['/perfil/detalhes', idPerfil]);
  }
}
