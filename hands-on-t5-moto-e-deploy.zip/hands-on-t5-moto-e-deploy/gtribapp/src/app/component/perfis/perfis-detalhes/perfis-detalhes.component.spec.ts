import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PerfisDetalhesComponent } from './perfis-detalhes.component';

describe('PerfisComponent', () => {
  let component: PerfisDetalhesComponent;
  let fixture: ComponentFixture<PerfisDetalhesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PerfisDetalhesComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(PerfisDetalhesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
