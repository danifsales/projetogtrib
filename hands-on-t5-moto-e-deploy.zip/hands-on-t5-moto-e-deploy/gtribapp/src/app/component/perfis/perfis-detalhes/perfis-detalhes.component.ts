import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router'; // Para obter o ID da rota
import { PerfilService } from '../../../service/perfil.service';
import { Perfil } from '../../../model/perfil';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { PermissaoService } from '../../../service/permissao.service';
import { Permissao } from '../../../model/permissao';

@Component({
  selector: 'app-perfis',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './perfis-detalhes.component.html',
  styleUrls: ['./perfis-detalhes.component.scss']
})
export class PerfisDetalhesComponent implements OnInit {
  perfil!: Perfil; // Objeto do perfil
  id!: number; // ID do perfil
  permissoesDisponiveis: Permissao[] = []; // Lista de permissões disponíveis
  novaPermissao: Permissao | undefined;
  novaPermissaoDisponivel = false;
  
  constructor(
    private perfilService: PerfilService, 
    private permissaoService: PermissaoService, 
    private route: ActivatedRoute // Para acessar o parâmetro da rota
  ) {}

  ngOnInit(): void {
    // Pegando o ID da rota
    this.route.params.subscribe(params => {
      this.id = +params['id']; // Convertendo para número
      this.loadPerfil(this.id); // Chamando o método para carregar o perfil
    });
    this.carregarPermissoesDisponiveis();
  }

  // Método para buscar o perfil pelo ID
  loadPerfil(id: number): void {
    this.perfilService.getById(id).subscribe(perfil => {
      this.perfil = perfil; // Definindo o perfil carregado
      this.filtrarPermissoesDisponiveis();
    });
  }

  carregarPermissoesDisponiveis() {
    // Lógica para carregar permissões disponíveis
    this.permissaoService.get().subscribe((permissoes) => {
      this.permissoesDisponiveis = permissoes.content;
      this.filtrarPermissoesDisponiveis(); // Filtrar após carregar permissões disponíveis
    });
  }

  filtrarPermissoesDisponiveis() {
    if (this.perfil && this.perfil.permissoes) {
      this.permissoesDisponiveis = this.permissoesDisponiveis.filter(permissaoDisponivel =>
        !this.perfil.permissoes.some(permissaoAdicionada => permissaoAdicionada.id === permissaoDisponivel.id)
      );
    }
  }

  adicionarPermissao() {
    this.novaPermissaoDisponivel = true; // Exibe o select para adicionar permissão
  }

  confirmarAdicionarPermissao() {
    if (this.novaPermissao && this.perfil) {
      this.perfil.permissoes.push(this.novaPermissao);
      this.filtrarPermissoesDisponiveis(); // Atualiza a lista de permissões disponíveis
      this.novaPermissaoDisponivel = false;
      this.novaPermissao = undefined; // Reseta o select após adição
    }
  }

  removePermissao(index: number) {
    const permissaoRemovida = this.perfil.permissoes.splice(index, 1)[0]; // Remove a permissão da lista
    if (permissaoRemovida) {
      this.permissoesDisponiveis.push(permissaoRemovida); // Adiciona a permissão removida de volta às disponíveis
    }
    this.filtrarPermissoesDisponiveis(); // Atualiza a lista de permissões disponíveis
  }

  onSubmit() {
    if (this.perfil) {
      this.perfilService.save(this.perfil).subscribe(() => {
        console.log('Perfil salvo com sucesso');
      });
    }
  }
}
