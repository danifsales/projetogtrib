import { Component } from '@angular/core';

@Component({
  selector: 'app-notification-icon',
  standalone: true,
  imports: [],
  templateUrl: './notification-icon.component.html',
  styleUrl: './notification-icon.component.scss'
})
export class NotificationIconComponent {
  notificationCount: number = 999; // ajustar numero de notificações
}
