import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { TheadOrdenacaoComponent } from '../../thead-ordenacao/thead-ordenacao.component';
import { RouterLink, Router } from '@angular/router';
import { CadastroComponent } from '../../cadastro/cadastro.component';
import { IForm } from '../../i-form';
import Swal from 'sweetalert2';
import { RespostaPaginada } from '../../../model/resposta-paginada';
import { Setor } from '../../../model/setor';
import { SetorService } from '../../../service/setor.service';
import { notBlankValidator } from '../../../validators/notBlank.validators';

@Component({
  selector: 'app-nova-unidade.form',
  standalone: true,
  imports: [FormsModule, TheadOrdenacaoComponent, CommonModule, RouterLink, ReactiveFormsModule, CadastroComponent],
  templateUrl: './nova-unidade.form.component.html',
  styleUrl: './nova-unidade.form.component.scss'
})
export class NovaUnidadeFormComponent implements IForm<Setor> {

  constructor(
    private servico: SetorService,
    private setorService: SetorService,
    private router: Router
  ) { }

  ngOnInit(): void {
    this.setores();
  }

  registro: Setor = <Setor>{};
  listSetores: Setor[] = [];
  totalElements: number = 0;

  formNovaUnidade = new FormGroup({
    nome: new FormControl<string | null>(null, Validators.required),
    codigo: new FormControl<string | null>(null,  [Validators.required, 
                                                   Validators.pattern(/^\d{1,3}$/)])  // Apenas 3 dígitos numéricos)
  });

  validateInput(event: any) {
    const input = event.target;
    input.value = input.value.replace(/[^0-9]/g, '');  // Remove qualquer coisa que não seja número
  }

  get form() {
    return this.formNovaUnidade.controls;
  }

  setores(termoBusca?: string): void {
    // Pega o total de registros
    this.setorService.get(termoBusca, { page: 0, size: 1, sort: [] }).subscribe({
      next: (resposta: RespostaPaginada<Setor>) => {
        const totalRegistros = resposta.totalElements;

        //Passa o total de registros como parametro size para sempre puxar todos os setores.
        this.setorService.get(termoBusca, { page: 0, size: totalRegistros, sort: [] }).subscribe({
          next: (setor: RespostaPaginada<Setor>) => {
            this.listSetores = setor.content;
            this.totalElements = setor.totalElements;
          }
        });
      }
    });
  }

  save(): void {
    const formValue = { ...this.formNovaUnidade.value };
    
    this.registro = Object.assign(this.registro, formValue); 
    if (formValue.codigo){ //Essa verificação é só por causa do typescript...
      this.registro.codigo = formValue.codigo,"10";
    }
    console.log(this.registro)
    this.servico.save(this.registro).subscribe({
      complete: () => {
        this.router.navigate(['/setor']);
        // Usando SweetAlert2 para exibir uma mensagem de sucesso
        Swal.fire({
          icon: 'success',
          title: 'Unidade cadastrada com sucesso!',
          showConfirmButton: false,
          position: 'top-end',
          timer: 3000,
          toast: true,
        });
      },
      error: (err) => {
        // Exibindo uma mensagem de erro com SweetAlert2
        Swal.fire({
          icon: 'error',
          title: 'Erro ao cadastrar unidade',
          showConfirmButton: false,
          position: 'top-end',
          timer: 3000,
          toast: true,
        });
      }
    });
  }

};