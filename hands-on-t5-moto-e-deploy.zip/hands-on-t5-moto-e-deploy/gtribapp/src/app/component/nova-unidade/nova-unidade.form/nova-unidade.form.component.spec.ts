import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NovaUnidadeFormComponent } from './nova-unidade.form.component';

describe('NovaUnidadeFormComponent', () => {
  let component: NovaUnidadeFormComponent;
  let fixture: ComponentFixture<NovaUnidadeFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [NovaUnidadeFormComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(NovaUnidadeFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
