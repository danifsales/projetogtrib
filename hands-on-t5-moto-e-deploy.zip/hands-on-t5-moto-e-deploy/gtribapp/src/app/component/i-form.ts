export interface IForm<T> {
    registro: T;
    save(): void;
}