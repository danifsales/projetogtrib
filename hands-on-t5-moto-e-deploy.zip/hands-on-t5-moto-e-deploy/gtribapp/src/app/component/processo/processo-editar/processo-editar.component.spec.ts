import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProcessoEditarComponent } from './processo-editar.component';

describe('ProcessosListComponent', () => {
  let component: ProcessoEditarComponent;
  let fixture: ComponentFixture<ProcessoEditarComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ProcessoEditarComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(ProcessoEditarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
