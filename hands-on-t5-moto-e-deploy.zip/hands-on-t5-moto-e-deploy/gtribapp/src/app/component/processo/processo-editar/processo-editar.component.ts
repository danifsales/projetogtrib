import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { ProcessoService } from '../../../service/processo.service';
import { Processo } from '../../../model/processo';
import { BarraComandosComponent } from '../../barra-comandos/barra-comandos.component';
import { CommonModule } from '@angular/common';
import { SpinnerComponent } from '../../spinner/spinner.component';
import { FormsModule } from '@angular/forms';
import { SetorService } from '../../../service/setor.service';
import { Setor } from '../../../model/setor';
import { RequisicaoPaginada } from '../../../model/requisicao-paginada';
import { RespostaPaginada } from '../../../model/resposta-paginada';
import { MovimentacaoService } from '../../../service/movimentacao.service';
import { Movimentacao } from '../../../model/movimentacao';

@Component({
  selector: 'app-processo-editar',
  standalone: true,
  imports: [
    BarraComandosComponent,
    CommonModule,
    SpinnerComponent,
    FormsModule,
    RouterModule
  ],
  templateUrl: './processo-editar.component.html',
  styleUrls: ['./processo-editar.component.scss']
})
export class ProcessoEditarComponent implements OnInit {

  processo: Processo | undefined;
  loading: boolean = true;
  inicioAnalise: string | undefined;
  finalAnalise: string | undefined;
  isSecretaria: boolean = false;
  palavrasChave: string[] = [];

  constructor(
    private route: ActivatedRoute,
    private servico: ProcessoService,
    private router: Router,
    private setorService: SetorService,
    private movimentacaoService: MovimentacaoService
  ) {}

  ngOnInit(): void {
    this.getSetores();
    const id = this.route.snapshot.paramMap.get('id');
    if (id) {
      this.servico.getById(+id).subscribe({
        next: (processo: Processo) => {
          this.processo = processo;
          this.loading = false;
          this.checkUserType();
          this.getMovimentacoes(processo.id);
        },
        error: err => {
          console.error('Erro ao buscar processo', err);
          this.loading = false;
        }
      });
    } else {
      this.loading = false;
    }
  }

  checkUserType(): void {
    if (this.processo && this.processo.responsavel && this.processo.responsavel.perfil === 'SECRETARIA') {
      this.isSecretaria = true;
    }
  }

  getMovimentacoes(processoId: number): void {
    this.movimentacaoService.getById(processoId).subscribe({
      next: (movimentacao: Movimentacao) => {
        if (movimentacao.movimentacao === 'INICIO_ANALISE') {
          this.inicioAnalise = movimentacao.data;
        } else if (movimentacao.movimentacao === 'FINALIZAR_ANALISE') {
          this.finalAnalise = movimentacao.data;
        }
      },
      error: err => {
        console.error('Erro ao buscar movimentações', err);
      }
    });
  }

  onSubmit(): void {
    if (this.processo) {
      if (typeof this.processo.responsavel === 'string') {
        this.processo.responsavel = {
          nomeCompleto: this.processo.responsavel,
          id: this.processo.responsavel,
          login: this.processo.responsavel,
          senha: this.processo.responsavel,
          perfil: this.processo.responsavel
        };
      }

      console.log('Processo a ser atualizado:', this.processo);

      this.servico.update(this.processo).subscribe({
        next: () => {
          alert('Processo atualizado com sucesso!');
          this.router.navigate(['/entrada']);
        },
        error: err => {
          console.error('Erro ao atualizar processo', err);
        }
      });
    } else {
      console.warn('Processo não está definido');
    }
  }

  onPalavraChaveInput(event: KeyboardEvent): void {
    const input = event.target as HTMLInputElement;
    if (event.key === '.') {
      event.preventDefault(); // Previne o comportamento padrão de inserir o ponto no input
      const palavra = input.value.trim();
      if (palavra) {
        this.palavrasChave.push(palavra);
        input.value = '';
      }
    }
  }

  removePalavraChave(index: number): void {
    this.palavrasChave.splice(index, 1);
  }

  setores: Setor[] = [];
  setorSelecionado: Setor | undefined;
  respostaPaginada: RespostaPaginada<Processo> = <RespostaPaginada<Processo>>{};
  requisicaoPaginada: RequisicaoPaginada = new RequisicaoPaginada();

  getSetores(termoBusca?: string): void {
    this.setorService.get(termoBusca, { page: 0, size: 1000, sort: [] }).subscribe({
      next: (setor: RespostaPaginada<Setor>) => {
        this.setores = Object.values(setor.content);
      },
      error: () => {
        console.error('erro ao carregar setores');
      }
    });
  }
}