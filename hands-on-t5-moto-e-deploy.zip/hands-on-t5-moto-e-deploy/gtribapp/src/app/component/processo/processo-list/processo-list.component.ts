import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { IList } from '../../i-list';
import { Processo } from '../../../model/processo';
import { ProcessoService } from '../../../service/processo.service';
import { AlertaService } from '../../../service/alerta.service';
import { RespostaPaginada } from '../../../model/resposta-paginada';
import { RequisicaoPaginada } from '../../../model/requisicao-paginada';
import { NgbPaginationModule } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-processos-list',
  standalone: true,
  imports: [CommonModule, RouterLink, NgbPaginationModule, FormsModule],
  templateUrl: './processo-list.component.html',
  styles: ``
})
export class ProcessosListComponent implements IList<Processo>{

  constructor(
    private servico: ProcessoService,
    private servicoAlerta: AlertaService
  ) { }

  ngOnInit(): void {
    this.requisicaoPaginada.size = parseInt(localStorage.getItem('tamanhoPagina') || '5');
    this.get();
  }


  registros: Processo[] = Array<Processo>();
  respostaPaginada: RespostaPaginada<Processo> = <RespostaPaginada<Processo>>{};
  requisicaoPaginada: RequisicaoPaginada = new RequisicaoPaginada();
  termoBusca: string | undefined = '';


  mudarPagina(pagina: number): void {
    this.requisicaoPaginada.page = pagina - 1;
    this.get(this.termoBusca);
  }

  ordenar(ordenacao: string[]): void {
    this.requisicaoPaginada.sort = ordenacao;
    this.requisicaoPaginada.page = 0;
    this.get(this.termoBusca);
  }

  mudarTamanhoPagina() {
    localStorage.setItem('tamanhoPagina', this.requisicaoPaginada.size.toString());
    this.get(this.termoBusca);
  }

  get(termoBusca?: string): void {
    this.termoBusca = termoBusca;
    this.servico.get(termoBusca, this.requisicaoPaginada).subscribe({
      next: (resposta: RespostaPaginada<Processo>) => {
        this.registros = resposta.content;
        this.respostaPaginada = resposta;
      }
    });
  }

  // delete(id: number): void {
  //   if (confirm('Confirma a exclusão do paciente?')) {
  //     this.servico.delete(id).subscribe({
  //       complete: () => {
  //         this.get();
  //         this.servicoAlerta.enviarAlerta({
  //           tipo: ETipoAlerta.SUCESSO,
  //           mensagem: "Paciente excluído com sucesso!"
  //         });
  //       }
  //     });
  //   }
  // }

  delete(id: number): void {
    throw new Error('Method not implemented.');
  }

}
