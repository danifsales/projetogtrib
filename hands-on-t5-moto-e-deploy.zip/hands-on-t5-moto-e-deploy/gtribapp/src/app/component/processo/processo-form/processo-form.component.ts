import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Processo } from '../../../model/processo';
import { ETipoAlerta } from '../../../model/e-tipo-alerta';
import { IForm } from '../../i-form';
import { ProcessoService } from '../../../service/processo.service';
import { AlertaService } from '../../../service/alerta.service';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { CadastroComponent } from '../../cadastro/cadastro.component';

@Component({
  selector: 'app-processos-form',
  standalone: true,
  imports: [FormsModule, CommonModule, RouterLink, ReactiveFormsModule, CadastroComponent],
  templateUrl: './processo-form.component.html',
  styles: `/src/teste2_style.scss`
})
export class ProcessosFormComponent implements IForm<Processo> {

  constructor(
    private servico: ProcessoService,
    private servicoAlerta: AlertaService,
    private router: Router,
    private route: ActivatedRoute) {}

    ngOnInit(): void {
      //Isso daqui é para fazer edição do registro na tabela. Basicmaente pega os dados do registro que você selecionou na tabela para a edição e preenche no form.
    const id = this.route.snapshot.queryParamMap.get('id');
    if (id) {
      this.servico.getById(+id).subscribe({
        next: (resposta: Processo) => {
          this.registro = resposta;
          this.formProcesso.patchValue(this.registro);
        }
      });
    }
}
  
    registro: Processo = <Processo>{};


    //Os nomes devem ser exatamente igual os da classe model.
    formProcesso = new FormGroup({
      numeroProcesso: new FormControl<number | null>(null),
      dataCapa: new FormControl<string | null>(null),
      cpfCnpj: new FormControl<string | null>(null),
      assunto: new FormControl<number | null>(null),
      interessadoNome: new FormControl<string | null>(null),
      
    });

    get form() {
      return this.formProcesso.controls;
    }
    
    save(): void {
      this.registro = Object.assign(this.registro, this.formProcesso.value); 
      this.servico.save(this.registro).subscribe({
        complete: () => {
          this.router.navigate(['/entrada']); //Aqui é a aba que você vai depois do item ser salvo com sucesso.
          this.servicoAlerta.enviarAlerta({
            tipo: ETipoAlerta.SUCESSO,
            mensagem: "Operação realizada com sucesso!"
          });
        }
      });
    }
}


