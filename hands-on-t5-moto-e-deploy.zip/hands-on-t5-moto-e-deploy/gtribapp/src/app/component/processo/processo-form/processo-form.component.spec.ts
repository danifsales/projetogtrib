import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProcessosFormComponent } from './processo-form.component';

describe('ProcessosFormComponent', () => {
  let component: ProcessosFormComponent;
  let fixture: ComponentFixture<ProcessosFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ProcessosFormComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(ProcessosFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
