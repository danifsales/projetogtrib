import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ProcessoService } from '../../../service/processo.service';
import { Processo } from '../../../model/processo';
import { BarraComandosComponent } from '../../barra-comandos/barra-comandos.component';
import { CommonModule } from '@angular/common';
import { SpinnerComponent } from '../../spinner/spinner.component'; 
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-processo-detalhes',
  standalone: true,
  imports: [
    BarraComandosComponent,
    CommonModule,
    SpinnerComponent,
    FormsModule  
  ],
  templateUrl: './processo-detalhes.component.html',
  styleUrls: ['./processo-detalhes.component.scss']
})
export class ProcessoDetalhesComponent implements OnInit {

  processo: Processo | undefined;
  loading: boolean = true; 
  ultimoInicioAnalise: Date | null = null;
  ultimaFinalizacaoAnalise: Date | null = null;
  constructor(
    private route: ActivatedRoute,
    private servico: ProcessoService
  ) { }

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('id');
    if (id) {
      this.servico.getById(+id).subscribe({
        next: (processo: Processo) => {
          console.log(processo)
          this.processo = processo;
          this.processo.movimentacoes = processo.movimentacoes.sort((a, b) => new Date(b.data).getTime() - new Date(a.data).getTime());
          this.loading = false;  
          // Filtra e encontra o último `INICIO_ANALISE`
          const ultimoInicioAnaliseObj = this.processo.movimentacoes
            .filter(item => item.movimentacao === "INICIO_ANALISE")
            .sort((a, b) => new Date(b.data).getTime() - new Date(a.data).getTime())[0];

          // Filtra e encontra o último `FINALIZACAO_ANALISE`
          const ultimaFinalizacaoAnaliseObj = this.processo.movimentacoes
            .filter(item => item.movimentacao === "FINALIZACAO_ANALISE")
            .sort((a, b) => new Date(b.data).getTime() - new Date(a.data).getTime())[0];

          // Atribui a data dos objetos filtrados, se existirem
          this.ultimoInicioAnalise = ultimoInicioAnaliseObj ? new Date(ultimoInicioAnaliseObj.data) : null;
          this.ultimaFinalizacaoAnalise = ultimaFinalizacaoAnaliseObj ? new Date(ultimaFinalizacaoAnaliseObj.data) : null;
          },
        error: err => {
          console.error('Erro ao buscar processo', err);
          this.loading = false;  
        }
      });
    } else {
      this.loading = false;
    }
  }
}
