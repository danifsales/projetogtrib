import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NovoProcessoFormComponent } from './novo-processo.form.component';

describe('NovoProcessoFormComponent', () => {
  let component: NovoProcessoFormComponent;
  let fixture: ComponentFixture<NovoProcessoFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [NovoProcessoFormComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(NovoProcessoFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
