import { Component, OnInit, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { IForm } from '../../i-form';
import { Processo } from '../../../model/processo';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { notBlankValidator } from '../../../validators/notBlank.validators';
import { ProcessoService } from '../../../service/processo.service';
import { Assunto } from '../../../model/assunto';
import { AssuntoService } from '../../../service/assunto.service';
import { RespostaPaginada } from '../../../model/resposta-paginada';
import { CadastroComponent } from '../../cadastro/cadastro.component';
import Swal from 'sweetalert2'; 
import { InputAutocompleteComponent } from '../../input-autocomplete/input-autocomplete.component';
import { cpfCnpjValidator } from '../../../validators/cpfCnpj.validators';
import { InputCpfCnpjComponent } from '../../input-cpf-cnpj/input-cpf-cnpj.component';
import { formatDateValidator } from '../../../validators/formatDateValidator';



@Component({
  selector: 'app-novo-processo.form',
  standalone: true,
  imports: [FormsModule, CommonModule, RouterLink, ReactiveFormsModule, CadastroComponent, InputAutocompleteComponent, InputCpfCnpjComponent],
  templateUrl: './novo-processo.form.component.html',
  styleUrl: './novo-processo.form.component.scss',
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class NovoProcessoFormComponent implements IForm<Processo> {

  constructor(
    private servico: ProcessoService,
    private assuntoService: AssuntoService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.assuntos();
  }

  registro: Processo = <Processo>{};
  listAssuntos: Assunto[]= [];
  totalElements:number = 0;

  formNovoProcesso = new FormGroup({
    numeroProcesso: new FormControl<string | null>(null,
      Validators.required),
    dataCapa: new FormControl<string | null>(null, [
      Validators.required,
      formatDateValidator() // Adiciona o validador de formatação de data
    ]),
    interessado: new FormGroup({
      cpfCnpj: new FormControl<string | null>(null, [Validators.required, cpfCnpjValidator]),
      nome: new FormControl<string | null>(null, Validators.required)
    }),
    assunto: new FormGroup({
      id: new FormControl<number | null>(null, Validators.required)
    })
  });
  
  get form() {
    return this.formNovoProcesso.controls;
  }

  assuntos(termoBusca?: string): void{
  // Pega o total de registros
  this.assuntoService.getAtivo(termoBusca, { page: 0, size: 1, sort: [] }).subscribe({
    next: (resposta: RespostaPaginada<Assunto>) => {
      const totalRegistros = resposta.totalElements;

      //Passa o total de registros como parametro size para sempre puxar todos os assuntos.
      this.assuntoService.getAtivo(termoBusca, { page: 0, size: totalRegistros, sort: [] }).subscribe({
        next: (assunto: RespostaPaginada<Assunto>) => {
          this.listAssuntos = assunto.content;
          this.totalElements = assunto.totalElements;
        }
      });
    }
  });
}

  save(): void {
    //Foi necessário fazer essa conversão para que o back-end aceite nossa data. DD-MM-YYYY
    const formValue = { ...this.formNovoProcesso.value }; // Essa medida é para que essa conversão não reflita visualmente para o usuário.
    const dataCapa = formValue.dataCapa;
   
    // Se a data estiver preenchida, converte para o formato YYYY-MM-DD
    if (dataCapa) {
      const [day, month, year] = dataCapa.split('/');
      formValue.dataCapa= `${year}-${month}-${day}`; // Converte para o formato YYYY-MM-DD
    }
    
    if (formValue.numeroProcesso) {
      formValue.numeroProcesso = formValue.numeroProcesso.replace(/\D/g, '');
    }

    if (formValue.interessado?.cpfCnpj) {
      formValue.interessado.cpfCnpj = formValue.interessado.cpfCnpj.replace(/\D/g, '');
    }
    this.registro = Object.assign(this.registro, formValue); //mandamos a cópia do formNovoProcesso e não o form verdadeiro.
      console.log(this.registro);
      this.servico.save(this.registro).subscribe({
        complete: () => {
          this.router.navigate(['/entrada']);
        // Usando SweetAlert2 para exibir uma mensagem de sucesso
        Swal.fire({
          icon: 'success',
          title: 'Processo cadastrado com sucesso!',
          showConfirmButton: false,
          position: 'top-end', 
          timer: 3000,
          toast: true, 
        });
      },
        error: (err) => {
          // Exibindo uma mensagem de erro com SweetAlert2
          Swal.fire({
            icon: 'error',
            title: 'Erro ao cadastrar processo',
            showConfirmButton: false,
            position: 'top-end', 
            timer: 3000,
            toast: true, 
          });
        }
    });
  } 
}


