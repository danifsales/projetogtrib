import { CommonModule } from '@angular/common';
import { IList } from '../../i-list';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { Processo } from '../../../model/processo';
import { RespostaPaginada } from '../../../model/resposta-paginada';
import { ProcessoService } from '../../../service/processo.service';
import { RequisicaoPaginada } from '../../../model/requisicao-paginada';
import { NgbPaginationModule } from '@ng-bootstrap/ng-bootstrap';
import { BarraComandosComponent } from '../../barra-comandos/barra-comandos.component';
import { TheadOrdenacaoComponent } from '../../thead-ordenacao/thead-ordenacao.component';
import { TheadOrdenacao } from '../../thead-ordenacao/thead-ordenacao';

@Component({
  selector: 'app-novo-processo.list',
  standalone: true,
  imports: [CommonModule, RouterLink, NgbPaginationModule, FormsModule, BarraComandosComponent, TheadOrdenacaoComponent],
  templateUrl: './novo-processo.list.component.html',
  styleUrl: './novo-processo.list.component.scss'
})
export class NovoProcessoListComponent implements IList<Processo> {

  constructor(
    private servico: ProcessoService) { }

  ngOnInit(): void{
    this.get();
  };

  registros: Processo[] = Array<Processo>();
  respostaPaginada: RespostaPaginada<Processo> = <RespostaPaginada<Processo>>{};
  requisicaoPaginada: RequisicaoPaginada = new RequisicaoPaginada();
  termoBusca: string | undefined = '';

  colunas: TheadOrdenacao = [
    { campo: 'id', descricao: 'ID' },
    { campo: 'numeroProcesso', descricao: 'Número Processo' },
    { campo: 'idInteressado', descricao: 'Interessado' },
    { campo: 'idAssunto', descricao: 'Assunto' },
    { campo: 'interessadoCpfCnpj', descricao: 'CPF/CNPJ' },
    { campo: 'dataCapa ', descricao: 'Entrada no Siat' },
  ];

  mudarPagina(pagina: number): void {
    this.requisicaoPaginada.page = pagina - 1;
    this.get(this.termoBusca);
  }

  ordenar(ordenacao: string[]): void {
    this.requisicaoPaginada.sort = ordenacao;
    this.requisicaoPaginada.page = 0;
    this.get(this.termoBusca);
  }

  mudarTamanhoPagina() {
    localStorage.setItem('tamanhoPagina', this.requisicaoPaginada.size.toString());
    this.get(this.termoBusca);
  }

  get(termoBusca?: string): void {
    this.termoBusca = termoBusca;
    this.servico.get(termoBusca, this.requisicaoPaginada).subscribe({
      next: (resposta: RespostaPaginada<Processo>) => {
        this.registros = resposta.content;
        this.respostaPaginada = resposta;
      }
    });
  }

  delete(id: number): void {
    throw new Error('Method not implemented.');
  }

}


