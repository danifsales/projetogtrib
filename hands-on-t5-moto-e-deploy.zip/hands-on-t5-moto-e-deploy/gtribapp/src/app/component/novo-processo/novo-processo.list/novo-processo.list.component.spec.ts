import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NovoProcessoListComponent } from './novo-processo.list.component';

describe('NovoProcessoListComponent', () => {
  let component: NovoProcessoListComponent;
  let fixture: ComponentFixture<NovoProcessoListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [NovoProcessoListComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(NovoProcessoListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  
});
