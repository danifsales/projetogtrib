import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NovoUsuarioFormComponent } from './novo-usuario.form.component';

describe('NovoUsuarioFormComponent', () => {
  let component: NovoUsuarioFormComponent;
  let fixture: ComponentFixture<NovoUsuarioFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [NovoUsuarioFormComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(NovoUsuarioFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
function beforeEach(arg0: () => Promise<void>) {
  throw new Error('Function not implemented.');
}

