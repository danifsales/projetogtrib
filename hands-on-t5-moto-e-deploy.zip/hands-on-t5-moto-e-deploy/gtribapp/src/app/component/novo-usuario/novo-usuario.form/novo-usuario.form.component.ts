import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { TheadOrdenacaoComponent } from '../../thead-ordenacao/thead-ordenacao.component';
import { RouterLink, Router } from '@angular/router';
import { CadastroComponent } from '../../cadastro/cadastro.component';
import { IForm } from '../../i-form';
import { Usuario } from '../../../model/usuario';
import { UsuarioService } from '../../../service/usuario.service';
import Swal from 'sweetalert2';
import { RespostaPaginada } from '../../../model/resposta-paginada';
import { ETipoUsuario } from '../../../model/ETipoUsuario';

@Component({
  selector: 'app-novo-usuario.form',
  standalone: true,
  imports: [FormsModule, TheadOrdenacaoComponent, CommonModule, RouterLink, ReactiveFormsModule, CadastroComponent],
  templateUrl: './novo-usuario.form.component.html',
  styleUrl: './novo-usuario.form.component.scss'
})
export class NovoUsuarioFormComponent implements IForm<Usuario> {

  constructor(
    private servico: UsuarioService,
    private usuarioService: UsuarioService,
    private router: Router
  ) { }

  ngOnInit(): void {
    this.usuarios();
  }

  registro: Usuario = <Usuario>{};
 // Converte os valores do enum em uma array de strings
  tiposUsuarios = Object.values(ETipoUsuario);
  totalElements: number = 0;

  formNovoUsuario = new FormGroup({
    nomeCompleto: new FormControl<string | null>(null, Validators.required),
    tipoUsuario: new FormControl<ETipoUsuario | null>(null, Validators.required),
    login: new FormControl<string | null>(null, Validators.required),
    senha: new FormControl('', Validators.required)
  });
  
  get form() {
    return this.formNovoUsuario.controls;
  }

  usuarios(termoBusca?: string): void {
    // Pega o total de registros
    this.usuarioService.get(termoBusca, { page: 0, size: 1, sort: [] }).subscribe({
      next: (resposta: RespostaPaginada<Usuario>) => {
        const totalRegistros = resposta.totalElements;

        //Passa o total de registros como parametro size para sempre puxar todos os usuarios.
        this.usuarioService.get(termoBusca, { page: 0, size: totalRegistros, sort: [] }).subscribe({
          next: (usuario: RespostaPaginada<Usuario>) => {
            
            this.totalElements = usuario.totalElements;
          }
        });
      }
    });
  }

  save(): void {
    // //Foi necessário fazer essa conversão para que o back-end aceite nossa data. DD-MM-YYYY
    // const formValue = { ...this.formNovoUsuario.value }; // Essa medida é para que essa conversão não reflita visualmente para o usuário.
    // const dataCapa = formValue.dataCapa;

    // // Se a data estiver preenchida, converte para o formato YYYY-MM-DD
    // if (dataCapa) {
    //   const [day, month, year] = dataCapa.split('/');
    //   formValue.dataCapa= `${year}-${month}-${day}`; // Converte para o formato YYYY-MM-DD
    // }
    const formValue = { ...this.formNovoUsuario.value };

    this.registro = Object.assign(this.registro, formValue); //mandamos a cópia do formNovoUsuario e não o form verdadeiro.
    console.log(this.registro);
    this.servico.save(this.registro).subscribe({
      complete: () => {
        this.router.navigate(['/usuarios']);
        // Usando SweetAlert2 para exibir uma mensagem de sucesso
        Swal.fire({
          icon: 'success',
          title: 'Usuário cadastrado com sucesso!',
          showConfirmButton: false,
          position: 'top-end',
          timer: 3000,
          toast: true,
        });
      },
        error: (err) => {
          // Exibindo uma mensagem de erro com SweetAlert2
          Swal.fire({
            icon: 'error',
            title: 'Erro ao cadastrar usuário',
            showConfirmButton: false,
            position: 'top-end',
            timer: 3000,
            toast: true,
          });
        }
    });
  }
}

