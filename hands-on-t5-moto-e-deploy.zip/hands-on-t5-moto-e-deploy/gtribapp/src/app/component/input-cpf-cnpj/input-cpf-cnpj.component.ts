import { Component, Input, forwardRef } from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';

@Component({
  selector: 'app-input-cpf-cnpj',
  standalone: true,  // Adicione standalone aqui
  templateUrl: './input-cpf-cnpj.component.html',
  styleUrls: ['./input-cpf-cnpj.component.scss'],
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => InputCpfCnpjComponent),
      multi: true
    }
  ]
})


export class InputCpfCnpjComponent implements ControlValueAccessor {
  
  @Input() inputId!: string;   // ID do input
  @Input() placeholder!: string; // O operador "!" assegura que a propriedade será inicializada posteriormente
  
  value: string = '';

  formatCpfCnpj(value: string): string {
    const cleanedValue = value.replace(/\D/g, '');
    if (cleanedValue.length <= 11) {
      return cleanedValue.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4');
    } else {
      return cleanedValue.replace(/(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})/, '$1.$2.$3/$4-$5');
    }
  }

  onInputChange(event: Event): void {
    const inputValue = (event.target as HTMLInputElement).value;
    this.value = this.formatCpfCnpj(inputValue);
    this.onChange(this.value);
  }

  onChange = (value: string) => {};
  onTouched = () => {};
  isDisabled = false;
  writeValue(value: string): void {
    this.value = value ? this.formatCpfCnpj(value) : '';
  }

  registerOnChange(fn: (value: string) => void): void {
    this.onChange = fn;
  }

  registerOnTouched(fn: () => void): void {
    this.onTouched = fn;
  }

  setDisabledState?(isDisabled: boolean): void {
    this.isDisabled = isDisabled;
  }
}
