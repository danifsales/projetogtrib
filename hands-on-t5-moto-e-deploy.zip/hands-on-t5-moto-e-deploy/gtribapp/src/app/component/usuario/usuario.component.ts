import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { UsuarioService } from '../../service/usuario.service';
import { Usuario } from '../../model/usuario';
import { RespostaPaginada } from '../../model/resposta-paginada';
import { RequisicaoPaginada } from '../../model/requisicao-paginada';
import { RouterLink } from '@angular/router';

declare var bootstrap: any;

@Component({
  selector: 'app-usuario',
  standalone: true,
  imports: [FormsModule, CommonModule, ReactiveFormsModule, RouterLink],
  templateUrl: './usuario.component.html',
  styleUrls: ['./usuario.component.scss'],
  providers: [UsuarioService]
})
export class UsuarioComponent implements OnInit {
  respostaPaginada: RespostaPaginada<Usuario> = <RespostaPaginada<Usuario>>{};
  requisicaoPaginada: RequisicaoPaginada = new RequisicaoPaginada();
  usuariosFiltrados: Usuario[] = [];
  termoBusca: string = '';
  usuarioSelecionado: Usuario | null = null;
  novoUsuario: Usuario = { id: 0, nomeCompleto: '', login: '', senha: '', perfil: 'User' };

  addForm: FormGroup;
  editForm: FormGroup;
  perfis: string[] = ['Admin', 'User', 'Guest'];

  constructor(
    private fb: FormBuilder,
    private usuarioService: UsuarioService
  ) {
    this.addForm = this.fb.group({
      nomeCompleto: ['', Validators.required],
      login: ['', Validators.required],
      senha: ['', Validators.required],
      perfil: ['User', Validators.required]
    });

    this.editForm = this.fb.group({
      id: [''],
      nomeCompleto: ['', Validators.required],
      login: ['', Validators.required],
      senha: ['', Validators.required],
      perfil: ['User', Validators.required]
    });
  }

  ngOnInit(): void {
    this.requisicaoPaginada.page = 0;
    this.requisicaoPaginada.size = 25;
    this.carregarUsuarios();
  }

  carregarUsuarios() {
    this.usuarioService.get(this.termoBusca, this.requisicaoPaginada).subscribe({
      next: (resposta: RespostaPaginada<Usuario>) => {
        console.log("Lista de usuarios: ",resposta);
        this.usuariosFiltrados = resposta.content;
        this.respostaPaginada = resposta;
      },
      error: (err) => console.error('Erro ao carregar usuários', err)
    });
  }

  abrirModalAdicionar() {
    this.addForm.reset({ perfil: 'User' });
    const addModal = new bootstrap.Modal(document.getElementById('addModal'));
    addModal.show();
  }

  adicionarUsuario() {
    const novoUsuario: Usuario = this.addForm.value;
    this.usuarioService.save(novoUsuario).subscribe({
      next: (usuario) => {
        this.carregarUsuarios();
        const addModal = bootstrap.Modal.getInstance(document.getElementById('addModal'));
        addModal.hide();
      },
      error: (err) => console.error('Erro ao adicionar usuário', err)
    });
  }

  abrirModalEditar(usuario: Usuario) {
    this.usuarioSelecionado = { ...usuario };
    this.editForm.patchValue(this.usuarioSelecionado);
    const editModal = new bootstrap.Modal(document.getElementById('editModal'));
    editModal.show();
  }

  salvarEdicaoUsuario() {
    if (this.usuarioSelecionado) {
      const usuarioEditado = { ...this.usuarioSelecionado, ...this.editForm.value };
      this.usuarioService.save(usuarioEditado).subscribe({
        next: (usuario) => {
          this.carregarUsuarios();
          const editModal = bootstrap.Modal.getInstance(document.getElementById('editModal'));
          editModal.hide();
        },
        error: (err) => console.error('Erro ao editar usuário', err)
      });
    }
  }

  abrirModalExcluir(usuario: Usuario) {
    this.usuarioSelecionado = usuario;
    const deleteModal = new bootstrap.Modal(document.getElementById('deleteModal'));
    deleteModal.show();
  }

  excluirUsuarioConfirmado() {
    if (this.usuarioSelecionado) {
      this.usuarioService.delete(this.usuarioSelecionado.id).subscribe({
        next: () => {
          this.carregarUsuarios();
          const deleteModal = bootstrap.Modal.getInstance(document.getElementById('deleteModal'));
          deleteModal.hide();
        },
        error: (err) => console.error('Erro ao excluir usuário', err)
      });
    }
  }

  onSearch(termo: string) {
    this.termoBusca = termo;
    this.carregarUsuarios();
  }

  mudarPagina(pagina: number): void {
    if (pagina >= 0 && pagina < this.respostaPaginada.totalPages) {
      this.requisicaoPaginada.page = pagina;
      this.carregarUsuarios();
    }
  }

  mudarTamanhoPagina(event: Event) {
    const target = event.target as HTMLSelectElement;
    this.requisicaoPaginada.size = +target.value;
    this.requisicaoPaginada.page = 0; // Reset para a primeira página
    this.carregarUsuarios();
  }
}