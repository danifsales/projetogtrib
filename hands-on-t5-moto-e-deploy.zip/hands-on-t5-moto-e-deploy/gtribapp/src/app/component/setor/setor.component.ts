import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { SetorService } from '../../service/setor.service';
import { Setor } from '../../model/setor';
import { RespostaPaginada } from "../../model/resposta-paginada";
import { RequisicaoPaginada } from '../../model/requisicao-paginada';

declare var bootstrap: any;

@Component({
  selector: 'app-setor',
  standalone: true,
  imports: [FormsModule, CommonModule, ReactiveFormsModule, RouterLink],
  templateUrl: './setor.component.html',
  styleUrls: ['./setor.component.scss'],
  providers: [SetorService]
})
export class SetorComponent implements OnInit {
  respostaPaginada: RespostaPaginada<Setor> = <RespostaPaginada<Setor>>{};
  requisicaoPaginada: RequisicaoPaginada = new RequisicaoPaginada();
  setorsFiltradas: Setor[] = [];
  termoBusca: string = '';
  setores: Setor[] = Array<Setor>();
  setoresFiltrados: Setor[] = this.setores;
  setorSelecionado: Setor | null = null;
  novoSetor: Setor = { id: 0, codigo: '', nome: '', ativo: true };
  addForm: FormGroup;
  editForm: FormGroup;
  totalGeral: number = 0;
  
  constructor(
    private fb: FormBuilder,
    private setorService: SetorService,
    private servico: SetorService
  ) {
    this.addForm = this.fb.group({
      codigo: [''],
      nome: [''],
      ativo: ['']
    });

    this.editForm = this.fb.group({
      codigo: [''],
      nome: [''],
      ativo: ['']
    });
  }

  ngOnInit(): void {
    this.requisicaoPaginada.page = 0;
    this.requisicaoPaginada.size = 25;
    this.carregarSetores();
  }

  carregarSetores() {
    const paginacao: RequisicaoPaginada = { 
      page: this.requisicaoPaginada.page, 
      size: this.requisicaoPaginada.size, 
      sort: this.requisicaoPaginada.sort || [] 
    };
    this.setorService.get(this.termoBusca, paginacao).subscribe({
      next: (resposta: RespostaPaginada<Setor>) => {
        this.setorsFiltradas = resposta.content;
        this.respostaPaginada = resposta;
        this.totalGeral = resposta.totalElements;
      },
      error: (err) => console.error('Erro ao carregar setores', err)
    });
  }

  abrirModalAdicionar() {
    this.addForm.reset({ situacao: 'Ativo' });
    const addModal = new bootstrap.Modal(document.getElementById('addModal'));
    addModal.show();
  }

  adicionarSetor() {
    const novoSetor: Setor = this.addForm.value;
    this.setorService.save(novoSetor).subscribe({
      next: (setor) => {
        this.carregarSetores();
        const addModal = bootstrap.Modal.getInstance(document.getElementById('addModal'));
        addModal.hide();
      },
      error: (err) => console.error('Erro ao adicionar setor', err)
    });
  }

  abrirModalEditar(setor: Setor) {
    this.setorSelecionado = { ...setor };
    this.editForm.patchValue(this.setorSelecionado);
    const editModal = new bootstrap.Modal(document.getElementById('editModal'));
    editModal.show();
  }

  salvarEdicaoSetor() {
    if (this.setorSelecionado) {
      const setorEditado = { ...this.setorSelecionado, ...this.editForm.value };
      this.setorService.save(setorEditado).subscribe({
        next: (setor) => {
          this.carregarSetores();
          const editModal = bootstrap.Modal.getInstance(document.getElementById('editModal'));
          editModal.hide();
          alert(`Setor editado com exito`);
        },
        error: (err) => {
          const errorMessage = err.error.message || 'Erro interno no servidor. Tente novamente mais tarde.';
          
          if (errorMessage.includes("Esse código já existe")) {
            alert("Esse código já existe");
          } else {
            alert(`Erro ao editar setor: codigo ou nome ja existente`);
          }
        }
      });
    }
  }

  abrirModalExcluir(setor: Setor) {
    this.setorSelecionado = setor;
    const deleteModal = new bootstrap.Modal(document.getElementById('deleteModal'));
    deleteModal.show();
  }

  excluirSetorConfirmado() {
    if (this.setorSelecionado) {
      this.setorService.delete(this.setorSelecionado.id, !this.setorSelecionado.ativo).subscribe({
        next: () => {
          this.carregarSetores();
          const deleteModal = bootstrap.Modal.getInstance(document.getElementById('deleteModal'));
          deleteModal.hide();
        },
        error: (err) => console.error('Erro ao excluir setor', err)
      });
    }
  }

  onSearch(termo: string) {
    this.termoBusca = termo;
    this.carregarSetores();
  }

  mudarPagina(pagina: number): void {
    if (pagina >= 0 && pagina < this.respostaPaginada.totalPages) {
      this.requisicaoPaginada.page = pagina;
      this.carregarSetores();
    }
  }

  mudarTamanhoPagina(event: Event) {
    const target = event.target as HTMLSelectElement;
    this.requisicaoPaginada.size = +target.value;
    this.requisicaoPaginada.page = 0;
    this.carregarSetores();
  }
  get(event?: Event): void {
    const termoBusca = event ? (event.target as HTMLInputElement).value : '';
    this.termoBusca = termoBusca;

    this.servico.get(termoBusca, this.requisicaoPaginada).subscribe({
      next: (resposta: RespostaPaginada<Setor>) => {
        this.setores = resposta.content;
        this.respostaPaginada = resposta;
        this.filtrarSetores();
      },
      error: (err) => {
        console.error('Erro ao buscar assuntos', err);
      }
    });
  }

  filtrarSetores() {
    const termo = this.termoBusca.toLowerCase();
    //console.log(this.setores);
    this.setorsFiltradas = this.setores.filter(setor =>
      typeof setor.codigo === 'number'||
      typeof setor.nome === 'string' && setor.nome.toLowerCase().includes(termo)
    );
  }
}
