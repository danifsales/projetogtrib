import { Component, forwardRef, Input } from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';
@Component({
  selector: 'app-input-autocomplete',
  standalone: true,
  imports: [],
  templateUrl: './input-autocomplete.component.html',
  styleUrl: './input-autocomplete.component.scss',
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => InputAutocompleteComponent),
      multi: true
    }
  ]
})
export class InputAutocompleteComponent implements ControlValueAccessor {
  @Input() inputId: string = '';   // ID do input
  @Input() placeholder: string = '';  // Placeholder do input

  inputValue: string = '';
  private onChange: (value: string) => void = () => {};
  private onTouched: () => void = () => {};
  isDisabled = false;
  onInput(event: Event): void {
    const value = (event.target as HTMLInputElement).value.replace(/\D/g, '');
    let formattedValue = '';

    for (let i = 0; i < value.length; i++) {
      formattedValue += value[i];
      if(i === 3|| i === 5){
        formattedValue += '/';
      }
    }

    this.inputValue = formattedValue;
    
    this.onChange(this.inputValue);  // Atualiza o valor no form control
  }

  writeValue(value: string): void {
    this.inputValue = value || '';
  }

  registerOnChange(fn: (value: string) => void): void {
    this.onChange = fn;
  }

  registerOnTouched(fn: () => void): void {
    this.onTouched = fn;
  }

  setDisabledState?(isDisabled: boolean): void {
    this.isDisabled = isDisabled;
  }


}

// @Component({
//   selector: 'app-input-autocomplete',
//   standalone: true,
//   imports: [],
//   templateUrl: './input-autocomplete.component.html',
//   styleUrl: './input-autocomplete.component.scss',
//   template: `
//     <input
//       [id]="inputId"
//       [placeholder]="placeholder"
//       [value]="formattedValue"
//       (input)="onInput($event)">
//   `,
//   providers: [{
//     provide: NG_VALUE_ACCESSOR,
//     useExisting: forwardRef(() => InputAutocompleteComponent),
//     multi: true
//   }]

// })
// export class InputAutocompleteComponent {

//   @Input() inputId!: string; // Valor padrão
//   @Input() placeholder!: string; // Valor padrão
//   @Input() formatMask!: number[]; // Posições onde o '/' será adicionado // Array representing format, e.g., [3, 3, 3, 2, 4] for CPF/CNPJ

//   inputValue: string = '';
//   formattedValue: string = '';

//   private onChange: any = () => {};
//   private onTouched: any = () => {};

//   // Responsável por lidar com a entrada de texto
//   onInput(event: any) {
//     this.inputValue = event.target.value.replace(/\D/g, '');  // Remove caracteres não numéricos
//     this.formattedValue = this.applyMask(this.inputValue, this.formatMask);
//     this.onChange(this.inputValue); // Notifica o Angular Forms da alteração
//   }

//    // Função de aplicação de máscara
//    applyMask(value: string, mask: number[]): string {
//     let masked = '';
//     let position = 0;

//     mask.forEach((length, index) => {
//       const part = value.slice(position, position + length);
//       masked += part;

//       if (index < mask.length - 1 && part.length === length) {
//         masked += index === 2 ? '/' : '.';  // Exemplo de separador
//       }

//       position += length;
//     });

//     return masked;
//   }

//   // Implementação do ControlValueAccessor
//   writeValue(value: any): void {
//     if (value) {
//       this.inputValue = value;
//       this.formattedValue = this.applyMask(this.inputValue, this.formatMask);
//     }
//   }

//   registerOnChange(fn: any): void {
//     this.onChange = fn;
//   }

//   registerOnTouched(fn: any): void {
//     this.onTouched = fn;
//   }

//   setDisabledState?(isDisabled: boolean): void {
//     // Implementação de lógica de desabilitação, se necessário
//   }
// }


//   //   onInput(event: Event): void {
//   //     const value = (event.target as HTMLInputElement).value.replace(/\D/g, '');
//   //     let formattedValue = '';

//   //     for (let i = 0; i < value.length; i++) {
//   //       formattedValue += value[i];
//   //       if (this.formatMask.includes(i)) {
//   //         formattedValue += '/';
//   //       }

//   //     this.inputValue = formattedValue;
//   //   }

//   // }



