import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NovoMotivoSaidaFormComponent } from './novo-motivo-saida.form.component';

describe('NovoMotivoSaidaFormComponent', () => {
  let component: NovoMotivoSaidaFormComponent;
  let fixture: ComponentFixture<NovoMotivoSaidaFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [NovoMotivoSaidaFormComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(NovoMotivoSaidaFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
