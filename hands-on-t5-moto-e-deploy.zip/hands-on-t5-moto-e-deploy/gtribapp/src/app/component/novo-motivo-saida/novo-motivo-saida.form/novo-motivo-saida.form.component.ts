import { Component } from '@angular/core';
import { IForm } from '../../i-form';
import { Movimentacao } from '../../../model/movimentacao';
import { MovimentacaoService } from '../../../service/movimentacao.service';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { TheadOrdenacaoComponent } from '../../thead-ordenacao/thead-ordenacao.component';
import { CommonModule } from '@angular/common';
import { RouterLink, Router } from '@angular/router';
import { CadastroComponent } from '../../cadastro/cadastro.component';
import { notBlankValidator } from '../../../validators/notBlank.validators';
import { RespostaPaginada } from '../../../model/resposta-paginada';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-novo-motivo-saida.form',
  standalone: true,
  imports: [FormsModule, TheadOrdenacaoComponent, CommonModule, RouterLink, ReactiveFormsModule, CadastroComponent],
  templateUrl: './novo-motivo-saida.form.component.html',
  styleUrl: './novo-motivo-saida.form.component.scss'
})
export class NovoMotivoSaidaFormComponent implements IForm<Movimentacao> {
  
  constructor(
    private servico: MovimentacaoService,
    private movimentacaoService: MovimentacaoService,
    private router: Router
  ) { }

  ngOnInit(): void {
    this.movimentacoes();
  }
  
  registro: Movimentacao = <Movimentacao>{};
  listMovimentacoes: Movimentacao[] = [];
  totalElements: number = 0;

  formNovoMotivoSaida = new FormGroup({
    movimentacao: new FormControl<string | null>(null, Validators.required),
    codigo: new FormControl<number | null>(null, notBlankValidator(3))
  });
  
  get form() {
    return this.formNovoMotivoSaida.controls;
  }

  movimentacoes(termoBusca?: string): void {
    // Pega o total de registros
    this.movimentacaoService.get(termoBusca, { page: 0, size: 1, sort: [] }).subscribe({
      next: (resposta: RespostaPaginada<Movimentacao>) => {
        const totalRegistros = resposta.totalElements;

        //Passa o total de registros como parametro size para sempre puxar todos os movimentacoes.
        this.movimentacaoService.get(termoBusca, { page: 0, size: totalRegistros, sort: [] }).subscribe({
          next: (movimentacao: RespostaPaginada<Movimentacao>) => {
            this.listMovimentacoes = movimentacao.content;
            this.totalElements = movimentacao.totalElements;
          }
        });
      }
    });
  }

  save(): void {
    const formValue = { ...this.formNovoMotivoSaida.value };

    this.registro = Object.assign(this.registro, formValue); //mandamos a cópia do formNovaUnidade e não o form verdadeiro.
    console.log(this.registro);
    this.servico.save(this.registro).subscribe({
      complete: () => {
        this.router.navigate(['/movimentacoes']);
        // Usando SweetAlert2 para exibir uma mensagem de sucesso
        Swal.fire({
          icon: 'success',
          title: 'Motivo de saída cadastrado com sucesso!',
          showConfirmButton: false,
          position: 'top-end',
          timer: 3000,
          toast: true,
        });
      },
      error: (err) => {
        // Exibindo uma mensagem de erro com SweetAlert2
        Swal.fire({
          icon: 'error',
          title: 'Erro ao cadastrar motivo de saída',
          showConfirmButton: false,
          position: 'top-end',
          timer: 3000,
          toast: true,
        });
      }
    });
  }


}
