import { HttpClient } from "@angular/common/http";
import { Assunto } from "../model/assunto";
import { IService } from "./i-service";
import { Injectable } from '@angular/core';
import { environment } from "../../environments/environments";
import { RequisicaoPaginada } from "../model/requisicao-paginada";
import { Observable } from 'rxjs';
import { RespostaPaginada } from "../model/resposta-paginada";
@Injectable({
    providedIn: 'root'
  })
export class AssuntoService implements IService<Assunto>{

    constructor(
        private http:HttpClient
    ){}

    apiUrl: string = environment.API_URL + '/assuntos/';
    apiUrl2: string = environment.API_URL + '/assuntos/ativos';

    get(termoBusca?: string | undefined, paginacao?: RequisicaoPaginada | undefined): Observable<RespostaPaginada<Assunto>> {
        let url = this.apiUrl + "?";
        if (termoBusca) {
          url += "termoBusca=" + termoBusca;
        }
        if (paginacao) {
          url += "&page=" + paginacao.page;
          url += "&size=" + paginacao.size;
          paginacao.sort.forEach(campo => {
            url += "&sort=" + campo;
          });
        } else {
          url += "&unpaged=true";
        }
        return this.http.get<RespostaPaginada<Assunto>>(url);
      }

    
      getAtivo(termoBusca?: string | undefined, paginacao?: RequisicaoPaginada | undefined): Observable<RespostaPaginada<Assunto>> {
        let url = this.apiUrl2 + "?";
        if (termoBusca) {
          url += "termoBusca=" + termoBusca;
        }
        if (paginacao) {
          url += "&page=" + paginacao.page;
          url += "&size=" + paginacao.size;
          paginacao.sort.forEach(campo => {
            url += "&sort=" + campo;
          });
        } else {
          url += "&unpaged=true";
        }
        return this.http.get<RespostaPaginada<Assunto>>(url);
      }

    getById(id: number): Observable<Assunto> {
      let url = this.apiUrl + id;
      return this.http.get<Assunto>(url);
    }
  
    save(objeto: Assunto): Observable<Assunto> {
      let url = this.apiUrl;
      if (objeto.id) {
        return this.http.put<Assunto>(url, objeto);
      } else {
        return this.http.post<Assunto>(url, objeto);
      }
    }

    desativarAssunto(id: number): Observable<Assunto> {
      return this.http.post<Assunto>(`${this.apiUrl}${id}/desativar`, {});
    }

    ativarAssunto(id: number): Observable<Assunto> {
      return this.http.post<Assunto>(`${this.apiUrl}${id}/ativar`, {});
    }    

    atualizarAssunto(assunto: Assunto): Observable<Assunto> {
      return this.http.put<Assunto>(`${this.apiUrl}/assuntos/${assunto.id}`, assunto);
    }
}