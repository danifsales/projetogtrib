import { Observable } from "rxjs";

export interface IService<T> {
    apiUrl: string;
    getById(id: number): Observable<T>;
    save(objeto: T): Observable<T>;
}
