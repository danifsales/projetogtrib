import { HttpClient } from "@angular/common/http";
import { IService } from "./i-service";
import { Injectable } from '@angular/core';
import { environment } from "../../environments/environments";
import { RequisicaoPaginada } from "../model/requisicao-paginada";
import { Observable } from 'rxjs';
import { RespostaPaginada } from "../model/resposta-paginada";
import { Permissao } from "../model/permissao";
@Injectable({
    providedIn: 'root'
  })
export class PermissaoService implements IService<Permissao>{

    constructor(
        private http:HttpClient
    ){}

    apiUrl: string = environment.API_URL + '/permissao/';

    get(termoBusca?: string | undefined, paginacao?: RequisicaoPaginada | undefined): Observable<RespostaPaginada<Permissao>> {
        let url = this.apiUrl + "?";
        if (termoBusca) {
          url += "termoBusca=" + termoBusca;
        }
        if (paginacao) {
          url += "&page=" + paginacao.page;
          url += "&size=" + paginacao.size;
          paginacao.sort.forEach(campo => {
            url += "&sort=" + campo;
          });
        } else {
          url += "&unpaged=true";
        }
        return this.http.get<RespostaPaginada<Permissao>>(url);
      }

      getById(id: number): Observable<Permissao> {
        let url = this.apiUrl + id;
        return this.http.get<Permissao>(url);
      }
    
      save(objeto: Permissao): Observable<Permissao> {
        let url = this.apiUrl;
        if (objeto.id) {
          return this.http.put<Permissao>(url, objeto);
        } else {
          return this.http.post<Permissao>(url, objeto);
        }
      }
}