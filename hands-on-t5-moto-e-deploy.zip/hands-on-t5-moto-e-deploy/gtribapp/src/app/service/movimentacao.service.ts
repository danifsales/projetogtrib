import { Injectable } from '@angular/core';
import { IService } from './i-service';
import { Movimentacao } from '../model/movimentacao';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../environments/environments';
import { RespostaPaginada } from "../model/resposta-paginada";
import { RequisicaoPaginada } from '../model/requisicao-paginada';

@Injectable({
  providedIn: 'root'
})
export class MovimentacaoService implements IService<Movimentacao> {

  constructor(
    private http:HttpClient
  ) { }

  apiUrl: string = environment.API_URL + '/movimentacoes/';

  get(termoBusca?: string | undefined, paginacao?: RequisicaoPaginada | undefined): Observable<RespostaPaginada<Movimentacao>> {
    let url = this.apiUrl + "?";
    if (termoBusca) {
      url += "termoBusca=" + termoBusca;
    }
    if (paginacao) {
      url += "&page=" + paginacao.page;
      url += "&size=" + paginacao.size;
      paginacao.sort.forEach(campo => {
        url += "&sort=" + campo;
      });
    } else {
      url += "&unpaged=true";
    }
    return this.http.get<RespostaPaginada<Movimentacao>>(url);
  }

  getById(id: number): Observable<Movimentacao> {
    let url = this.apiUrl + id;
        return this.http.get<Movimentacao>(url);
      }

  save(objeto: Movimentacao): Observable<Movimentacao> {
    let url = this.apiUrl;
    if (objeto.id_movimentacoes) {
      return this.http.put<Movimentacao>(url, objeto);
    } else {
      return this.http.post<Movimentacao>(url, objeto);
    }
  }
  update(processo: Movimentacao): Observable<Movimentacao> {
      return this.http.put<Movimentacao>(`${this.apiUrl}editar/${MovimentacaoService}`, processo);
    }
}
