import { HttpClient, HttpRequest } from '@angular/common/http';
import { afterRender, inject, Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { BehaviorSubject } from 'rxjs';
import { Usuario } from '../../model/usuario';
import { ILoginService } from './i-login.service';
import { environment } from '../../../environments/environments';

@Injectable({
  providedIn: 'root'
})
export class JwtLoginService implements ILoginService {

  private usuarioStorageKey = 'usuario';

  constructor() {
    if (typeof window !== 'undefined' && window.sessionStorage) {
      const userData = sessionStorage.getItem('usuario');
      if (userData && userData !== '{}') {
        const usuario = JSON.parse(userData);
        this.usuarioAutenticado.next(usuario);
      }
    }
  }

  usuarioAutenticado: BehaviorSubject<Usuario> = new BehaviorSubject<Usuario>(<Usuario>{});
  private http: HttpClient = inject(HttpClient);
  private router: Router = inject(Router);
  private fezRequisicao: boolean = false;
  private intervaloRenovacao: any;

  private renovarToken(): void {
    const url = environment.API_URL + '/refresh';
    this.http.get(url, { responseType: 'text' }).subscribe({
      next: (token: string) => {
        this.configurarSessaoUsuario(token);
      }
    })
  }

  login(username: string, password: string): void {
    const url = environment.API_URL + '/auth/login';
    this.http.post<{ token: string }>(url, { username, password }).subscribe({
      next: (response: { token: string }) => {
        console.log("Token de login:", response.token);
        this.configurarSessaoUsuario(response.token);
        // Redireciona para a tela de entrada após login bem-sucedido
        this.router.navigate(['/entrada']).then(navigated => {
          if (navigated) {
            console.log("Redirecionamento bem-sucedido!");
          } else {
            console.error("Falha ao redirecionar.");
          }
        });
      },
      error: (err) => {
        console.error("Erro no login:", err);
      }
    });
  }

  private configurarSessaoUsuario(token: string) {
    const payload = token.split('.')[1];
    // Ajustamos o payload para Base64 padrão
    const base64Payload = payload.replace(/-/g, '+').replace(/_/g, '/');
    const payloadDecodificado = atob(base64Payload);
    const conteudoToken = JSON.parse(decodeURIComponent(escape(payloadDecodificado)));
    
    const usuario: Usuario = {
      id: conteudoToken.id,
      login: conteudoToken.login,
      perfil: conteudoToken.tipoUsuario,
      nomeCompleto: conteudoToken.nome,
      senha: conteudoToken.senha
    };
    console.log("Conteúdo do token:", conteudoToken);
    console.log("Usuário autenticado:", usuario);
  
    if (typeof sessionStorage !== 'undefined') {
      sessionStorage.setItem('token', token);
      sessionStorage.setItem(this.usuarioStorageKey, JSON.stringify(usuario));
    }
    this.usuarioAutenticado.next(usuario);
  }

  logout(): void {
    if (typeof sessionStorage !== 'undefined') {
      sessionStorage.removeItem('token');
      sessionStorage.removeItem(this.usuarioStorageKey);
      sessionStorage.removeItem('tokenExp');
    }
    if (typeof document !== 'undefined') {
      document.cookie = 'XSRF-TOKEN=; Max-Age=0; path=/';
    }
    clearInterval(this.intervaloRenovacao);
    this.router.navigate(['/login']);
  }

  isLoggedIn(): boolean {
    if (typeof sessionStorage === 'undefined') {
      return false;
    }
    const usuario = sessionStorage.getItem('usuario');
    return usuario != null && usuario !== '{}'; // Verifica se o usuário não está vazio
  }

  getHeaders(request: HttpRequest<any>): HttpRequest<any> {
    if (this.isLoggedIn()) {
      this.fezRequisicao = true;
      const token = sessionStorage.getItem('token');
      return request.clone({
        withCredentials: true,
        headers: request.headers.set('Authorization', 'Bearer ' + token)
      });
    }
    return request;
  }
}

  // private agendarRenovacaoToken(): void {
  //   const intervalo = 1000 * 10;
  //   this.intervaloRenovacao = setInterval(() => {
  //     if (this.fezRequisicao) {
  //       this.renovarToken();
  //       this.fezRequisicao = false;
  //     }
  //   }, intervalo);
  // }
