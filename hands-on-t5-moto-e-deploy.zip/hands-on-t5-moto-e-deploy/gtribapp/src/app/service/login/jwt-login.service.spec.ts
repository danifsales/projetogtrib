import { TestBed } from '@angular/core/testing';
import { JwtLoginService } from './jwt-login.service';

describe('JwtLoginService', () => {
  let service: JwtLoginService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(JwtLoginService);

    // Mock sessionStorage
    const mockSessionStorage = (() => {
      let store: { [key: string]: string } = {};
      return {
        getItem: (key: string) => store[key] || null,
        setItem: (key: string, value: string) => store[key] = value,
        removeItem: (key: string) => delete store[key],
        clear: () => store = {}
      };
    })();

    Object.defineProperty(window, 'sessionStorage', { value: mockSessionStorage });

    // Mock document
    const mockDocument = {
      _cookie: '',
      get cookie() {
        return this._cookie;
      },
      set cookie(value: string) {
        this._cookie = value;
      }
    };

    Object.defineProperty(global, 'document', { value: mockDocument });
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  // Adicione mais testes conforme necessário
});