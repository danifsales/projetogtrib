import { Injectable } from '@angular/core';
import { IService } from './i-service';
import { Setor } from '../model/setor';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environments';
import { RespostaPaginada } from "../model/resposta-paginada";
import { RequisicaoPaginada } from '../model/requisicao-paginada';
import { HttpClient, HttpParams } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class SetorService implements IService<Setor> {

  constructor(
    private http:HttpClient
  ) { }

  apiUrl: string = environment.API_URL + '/setores/';

  get(termoBusca?: string | undefined, paginacao?: RequisicaoPaginada | undefined): Observable<RespostaPaginada<Setor>> {
    let url = this.apiUrl + "?";
    if (termoBusca) {
      url += "termoBusca=" + termoBusca;
    }
    if (paginacao) {
      url += "&page=" + paginacao.page;
      url += "&size=" + paginacao.size;
      paginacao.sort.forEach(campo => {
        url += "&sort=" + campo;
      });
    } else {
      url += "&unpaged=true";
    }
    return this.http.get<RespostaPaginada<Setor>>(url);
  }


  getById(id: number): Observable<Setor> {
    let url = this.apiUrl + id;
        return this.http.get<Setor>(url);
      }

  save(objeto: Setor): Observable<Setor> {
    let url = this.apiUrl;
        if (objeto.id) {
          let url = this.apiUrl + objeto.id;
          return this.http.put<Setor>(url, objeto);
        } else {
          return this.http.post<Setor>(url, objeto);
        }
      }

      delete(id: number, ativo: boolean): Observable<void> {
        const params = new HttpParams().set('ativo', ativo.toString());
        return this.http.delete<void>(`${this.apiUrl}${id}`, { params });
      }
      
}
