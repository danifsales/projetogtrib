import { Injectable } from '@angular/core';
import { IService } from './i-service';
import { Processo } from '../model/processo';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environments';
import { RequisicaoPaginada } from '../model/requisicao-paginada';
import { RespostaPaginada } from '../model/resposta-paginada';
import { EMotivoDiligencia } from '../model/EMotivoDiligencia';
import { EConclusao } from '../model/EConclusao';

@Injectable({
  providedIn: 'root'
})
export class ProcessoService implements IService<Processo> {
  update(processo: Processo): Observable<Processo> {
    return this.http.put<Processo>(`${this.apiUrl}editar/${processo.id}`, processo);
  }

  constructor(
    private http: HttpClient
  ) { }

  apiUrl: string = environment.API_URL + '/processos/';
 

  get(termoBusca?: string | undefined, paginacao?: RequisicaoPaginada | undefined): Observable<RespostaPaginada<Processo>> {
    let url = this.apiUrl + "?";
    if (termoBusca) {
      url += "termoBusca=" + termoBusca;
    }
    if (paginacao) {
      url += "&page=" + paginacao.page;
      url += "&size=" + paginacao.size;
      paginacao.sort.forEach(campo => {
        url += "&sort=" + campo;
      });
    } else {
      url += "&unpaged=true";
    }
    return this.http.get<RespostaPaginada<Processo>>(url);
  }

  getById(id: number): Observable<Processo> {
    let url = this.apiUrl + id;
    return this.http.get<Processo>(url);
  }

  save(objeto: Processo): Observable<Processo> {
    let url = this.apiUrl;
    if (objeto.id) {
      return this.http.put<Processo>(url, objeto);
    } else {
      return this.http.post<Processo>(url, objeto);
    }
  }
  
  designarProcesso(idProcesso: number, idUsuario: number, idAssessor?: number): Observable<any> {
    if (!idAssessor){
      const url = `${this.apiUrl}designar/${idProcesso}/${idUsuario}`
      return this.http.patch(url, {}); 
    }else{
      const url = `${this.apiUrl}designar/${idProcesso}/${idUsuario}?idAssessor=${idAssessor}`;
      return this.http.patch(url, {}); 
    }
    
  }

  iniciarProcesso(idProcesso: number) : Observable<any>{
    const url = `${this.apiUrl}iniciar-processo/${idProcesso}`;
    return this.http.patch(url, {});
  }
  encaminharDiligencia(idProcesso: number, idaOuVinda: boolean, idSetorDestino?:number | null,  motivo?: EMotivoDiligencia| null): Observable<any> {
    
    let params = new HttpParams()
      .set('caminhamento', idaOuVinda.toString());

    if (motivo) {
      params = params.set('motivo', motivo);
    }

    // Adiciona o idSetorDestino apenas se ele não for nulo
    if (idSetorDestino != null) {
      params = params.set('idSetorDestino', idSetorDestino.toString());
    }

    return this.http.patch(
      `${this.apiUrl}diligencia/${idProcesso}/`,
      null, // corpo vazio, já que os parâmetros são enviados via query string
      { params }
    );
  }


  finalizarProcesso(
    id: number,
    dados: { parecerNumero?: number; nivelDificuldade?: string; palavraChave?: string; observacao?: string }
  ): Observable<any> {
    return this.http.patch(`${this.apiUrl}finalizar-processo/${id}`, dados);
  }

  concluirProcesso(id: number, conclusao: EConclusao): Observable<any> {
    const params = new HttpParams().set('conclusao', conclusao);
    return this.http.patch(`${this.apiUrl}concluir-processo/${id}`, null, { params });
  }

}
