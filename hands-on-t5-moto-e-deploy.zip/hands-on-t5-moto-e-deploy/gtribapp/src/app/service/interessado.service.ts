import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environments';
import { RespostaPaginada } from '../model/resposta-paginada';
import { Interessado } from '../model/interessado';
import { RequisicaoPaginada } from '../model/requisicao-paginada';

@Injectable({
  providedIn: 'root'
})
export class InteressadoService {
  private apiUrl: string = environment.API_URL + '/interessados/';

  constructor(private http: HttpClient) { }

  // Método para buscar todos os interessados
  getInteressados(termoBusca?: string | undefined, paginacao?: RequisicaoPaginada | undefined): Observable<RespostaPaginada<Interessado>> {
    let url = this.apiUrl + "?";
    if (termoBusca) {
      url += "termoBusca=" + termoBusca;
    }
    if (paginacao) {
      url += "&page=" + paginacao.page;
      url += "&size=" + paginacao.size;
      paginacao.sort.forEach(campo => {
        url += "&sort=" + campo;
      });
    } else {
      url += "&unpaged=true";
    }
    return this.http.get<RespostaPaginada<Interessado>>(url);
  }

  // Demais métodos
  getById(id: number): Observable<Interessado> {
    let url = this.apiUrl + id;
    return this.http.get<Interessado>(url);
  }

  save(objeto: Interessado): Observable<Interessado> {
    let url = this.apiUrl;
    if (objeto.id) {
      return this.http.put<Interessado>(url, objeto);
    } else {
      return this.http.post<Interessado>(url, objeto);
    }
  }

  delete(id: number): Observable<void> {
    let url = this.apiUrl + id;
    return this.http.delete<void>(url);
  }
}