
# Sobre a Branch Dev

Essa `branch` foi criada para podermos desenvolver nossa aplicação. Qualquer informação ou documento que nos ajude no desenvolvimento, pode ser colocado aqui.
Ao final de cada _sprint_, seria interessante que o `merge` dessa `branch` fosse realizado para a `branch main`, com o intuito de ter uma entrega contínua.

## Antes de começar a desenvolver

Lembre-se dos seguintes comandos git:
1. `git checkout dev`-> Muda para a branch `dev`;
  
2. `git pull`-> Atualiza o seu respositório local com os arquivos mais recentes da branch dev.
   

Antes de **realizar o commit**, lembre-se:
1. `git branch`-> Verifica em qual `branch` você se encontra 

![image](https://github.com/user-attachments/assets/2ea6e413-049b-4cd0-99ea-f1a6c217f660)

Em verde, indica qual `branch` você está no momento, caso esteja na `branch dev`, prossiga:

2. `git pull`-> Caso ocorra conflito de merge, resolva manualmente;
 
3. `git add .`-> Adiciona tudo que você fez de novo para o commit;
   
4. `git commit -m "ex[tipo semântico]: nova funcionalidade[breve descrição do que fez] | Ref: #1[nº issue]"`-> Realize o commit semântico;
  
5. `git push` -> Envia o que esta no `commit` para o respositório principal.

### Sobre o commit semântico

Sempre tente fazer o commit semântico: "[tipo]: comentário | Ref: [número da issue].
Sobre os tipos, existem diversos, como:
![image](https://github.com/user-attachments/assets/4086c5ab-43ed-4f76-b1e8-afc9ffcaa54e)


Caso tenha interesse em saber mais sobre o assunto, pode estar acessando esse link: https://blog.geekhunter.com.br/o-que-e-commit-e-como-usar-commits-semanticos/

### Importante

Extremamente **proibido** fazer `git push --force`.

Tente sempre deixar o repositório do git atualizado com as suas alterações locais, mesmo que não tenha algo funcionando ainda. Então terminou de produzir, ou tem que dar uma pausa, faça o `commit` para evitar problemas de integrção com o código dos demais.

<<<<<<< HEAD
Aqui deve ser feito o merge da branch `dev` para podermos realizar testes de integração.
=======
>>>>>>> 0d754c1b3fac5c3fd244a5b4c36ca31798a473fc
